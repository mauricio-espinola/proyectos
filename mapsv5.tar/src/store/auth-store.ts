import { create } from "zustand";

interface AuthState {
  isLoginMode: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setLoginMode: (mode: boolean) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  reset: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  isLoginMode: false, // Default to register mode for new users
  isLoading: false,
  error: null,
  
  setLoginMode: (mode) => set({ isLoginMode: mode, error: null }),
  setLoading: (loading) => set({ isLoading: loading }),
  setError: (error) => set({ error }),
  reset: () => set({ isLoginMode: false, isLoading: false, error: null }),
}));
