import { create } from "zustand";

// Types
export interface NodeData {
  id: string;
  title: string;
  description?: string;
  type: "MAIN" | "COMPLEMENT";
  positionX: number;
  positionY: number;
  width: number;
  height: number;
  color?: string;
  mainNodeId?: string;
  // For complement nodes
  bullets?: string;  // Bullet points text (one per line)
  linkType?: "URL" | "VIDEO";
  linkUrl?: string;
  linkType2?: "URL" | "VIDEO";
  linkUrl2?: string;
  attachments?: AttachmentData[];
  complements?: NodeData[];
}

export interface ConnectionData {
  id: string;
  sourceNodeId: string;
  targetNodeId: string;
  label?: string;
  color: string;
  sourcePoint: "TOP" | "RIGHT" | "BOTTOM" | "LEFT" | "CENTER";
  targetPoint: "TOP" | "RIGHT" | "BOTTOM" | "LEFT" | "CENTER";
  lineStyle: string;
  lineWidth: number;
  curvature: number;
}

export interface AttachmentData {
  id: string;
  name: string;
  type: "IMAGE" | "AUDIO" | "VIDEO" | "DOCUMENT" | "LINK";
  url: string;
  thumbnail?: string;
  description?: string;
}

export interface MapData {
  id: string;
  title: string;
  description?: string;
  isPublic: boolean;
  nodes: NodeData[];
  connections: ConnectionData[];
}

interface CanvasState {
  // Current map
  currentMap: MapData | null;
  
  // Selected elements
  selectedNodeId: string | null;
  selectedConnectionId: string | null;
  hoveredNodeId: string | null;
  
  // Canvas state
  zoom: number;
  panOffset: { x: number; y: number };
  
  // Interaction state
  isDragging: boolean;
  isConnecting: boolean;
  connectingFrom: { nodeId: string; point: string } | null;
  
  // UI state
  showNodePanel: boolean;
  showConnectionPanel: boolean;
  showMapList: boolean;
  
  // Actions
  setCurrentMap: (map: MapData | null) => void;
  selectNode: (nodeId: string | null) => void;
  selectConnection: (connectionId: string | null) => void;
  hoverNode: (nodeId: string | null) => void;
  setZoom: (zoom: number) => void;
  setPanOffset: (offset: { x: number; y: number }) => void;
  setIsDragging: (dragging: boolean) => void;
  startConnecting: (nodeId: string, point: string) => void;
  stopConnecting: () => void;
  toggleNodePanel: () => void;
  toggleConnectionPanel: () => void;
  toggleMapList: () => void;
  
  // Node operations
  addNode: (node: NodeData) => void;
  updateNode: (nodeId: string, data: Partial<NodeData>) => void;
  removeNode: (nodeId: string) => void;
  
  // Connection operations
  addConnection: (connection: ConnectionData) => void;
  updateConnection: (connectionId: string, data: Partial<ConnectionData>) => void;
  removeConnection: (connectionId: string) => void;
}

export const useCanvasStore = create<CanvasState>((set) => ({
  // Initial state
  currentMap: null,
  selectedNodeId: null,
  selectedConnectionId: null,
  hoveredNodeId: null,
  zoom: 1,
  panOffset: { x: 0, y: 0 },
  isDragging: false,
  isConnecting: false,
  connectingFrom: null,
  showNodePanel: false,
  showConnectionPanel: false,
  showMapList: false,
  
  // Actions
  setCurrentMap: (map) => set({ currentMap: map, selectedNodeId: null, selectedConnectionId: null }),
  selectNode: (nodeId) => set({ selectedNodeId: nodeId, showNodePanel: !!nodeId }),
  selectConnection: (connectionId) => set({ selectedConnectionId: connectionId, showConnectionPanel: !!connectionId }),
  hoverNode: (nodeId) => set({ hoveredNodeId: nodeId }),
  setZoom: (zoom) => set({ zoom: Math.max(0.25, Math.min(2, zoom)) }),
  setPanOffset: (offset) => set({ panOffset: offset }),
  setIsDragging: (dragging) => set({ isDragging: dragging }),
  startConnecting: (nodeId, point) => set({ isConnecting: true, connectingFrom: { nodeId, point } }),
  stopConnecting: () => set({ isConnecting: false, connectingFrom: null }),
  toggleNodePanel: () => set((state) => ({ showNodePanel: !state.showNodePanel })),
  toggleConnectionPanel: () => set((state) => ({ showConnectionPanel: !state.showConnectionPanel })),
  toggleMapList: () => set((state) => ({ showMapList: !state.showMapList })),
  
  // Node operations
  addNode: (node) => set((state) => {
    if (!state.currentMap) return state;
    return {
      currentMap: {
        ...state.currentMap,
        nodes: [...state.currentMap.nodes, node],
      },
    };
  }),
  updateNode: (nodeId, data) => set((state) => {
    if (!state.currentMap) return state;
    return {
      currentMap: {
        ...state.currentMap,
        nodes: state.currentMap.nodes.map((n) =>
          n.id === nodeId ? { ...n, ...data } : n
        ),
      },
    };
  }),
  removeNode: (nodeId) => set((state) => {
    if (!state.currentMap) return state;
    return {
      currentMap: {
        ...state.currentMap,
        nodes: state.currentMap.nodes.filter((n) => n.id !== nodeId),
        connections: state.currentMap.connections.filter(
          (c) => c.sourceNodeId !== nodeId && c.targetNodeId !== nodeId
        ),
      },
    };
  }),
  
  // Connection operations
  addConnection: (connection) => set((state) => {
    if (!state.currentMap) return state;
    return {
      currentMap: {
        ...state.currentMap,
        connections: [...state.currentMap.connections, connection],
      },
    };
  }),
  updateConnection: (connectionId, data) => set((state) => {
    if (!state.currentMap) return state;
    return {
      currentMap: {
        ...state.currentMap,
        connections: state.currentMap.connections.map((c) =>
          c.id === connectionId ? { ...c, ...data } : c
        ),
      },
    };
  }),
  removeConnection: (connectionId) => set((state) => {
    if (!state.currentMap) return state;
    return {
      currentMap: {
        ...state.currentMap,
        connections: state.currentMap.connections.filter((c) => c.id !== connectionId),
      },
    };
  }),
}));
