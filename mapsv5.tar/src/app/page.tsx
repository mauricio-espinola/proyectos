import { ConceptMapApp } from "@/components/concept-map-app";

export default function Home() {
  return <ConceptMapApp />;
}
