import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ConceptMap - Mapas Conceptuales Interactivos",
  description: "Crea mapas conceptuales interactivos con una interfaz minimalista y elegante. Organiza tus ideas visualmente.",
  keywords: ["mapas conceptuales", "diagramas", "ideas", "brainstorming", "visualización"],
  authors: [{ name: "ConceptMap Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "ConceptMap",
    description: "Mapas conceptuales interactivos",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
