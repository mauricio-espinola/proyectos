import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

// Schema for creating a concept map
const createMapSchema = z.object({
  title: z.string().min(1, "Title is required").max(100),
  description: z.string().max(500).optional(),
  isPublic: z.boolean().optional().default(false),
});

// GET /api/maps - Get all maps for the authenticated user
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const maps = await db.conceptMap.findMany({
      where: { authorId: session.user.id },
      include: {
        _count: {
          select: { nodes: true, connections: true },
        },
      },
      orderBy: { updatedAt: "desc" },
    });

    return NextResponse.json({ maps });
  } catch (error) {
    console.error("Error fetching maps:", error);
    return NextResponse.json(
      { error: "Failed to fetch maps" },
      { status: 500 }
    );
  }
}

// POST /api/maps - Create a new concept map
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validationResult = createMapSchema.safeParse(body);
    
    if (!validationResult.success) {
      return NextResponse.json(
        { error: "Validation failed", details: validationResult.error.flatten() },
        { status: 400 }
      );
    }

    const { title, description, isPublic } = validationResult.data;

    const map = await db.conceptMap.create({
      data: {
        title,
        description,
        isPublic,
        authorId: session.user.id,
      },
      include: {
        nodes: true,
        connections: true,
      },
    });

    return NextResponse.json({ map }, { status: 201 });
  } catch (error) {
    console.error("Error creating map:", error);
    return NextResponse.json(
      { error: "Failed to create map" },
      { status: 500 }
    );
  }
}
