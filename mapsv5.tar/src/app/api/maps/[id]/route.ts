import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

// Schema for updating a concept map
const updateMapSchema = z.object({
  title: z.string().min(1).max(100).optional(),
  description: z.string().max(500).optional(),
  isPublic: z.boolean().optional(),
});

// GET /api/maps/[id] - Get a specific map with all nodes and connections
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const map = await db.conceptMap.findFirst({
      where: {
        id,
        OR: [
          { authorId: session.user.id },
          { isPublic: true },
        ],
      },
      include: {
        nodes: {
          include: {
            attachments: true,
            complements: {
              include: {
                attachments: true,
              },
            },
          },
          orderBy: { order: "asc" },
        },
        connections: true,
        author: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    });

    if (!map) {
      return NextResponse.json({ error: "Map not found" }, { status: 404 });
    }

    return NextResponse.json({ map });
  } catch (error) {
    console.error("Error fetching map:", error);
    return NextResponse.json(
      { error: "Failed to fetch map" },
      { status: 500 }
    );
  }
}

// PUT /api/maps/[id] - Update a concept map
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validationResult = updateMapSchema.safeParse(body);
    
    if (!validationResult.success) {
      return NextResponse.json(
        { error: "Validation failed", details: validationResult.error.flatten() },
        { status: 400 }
      );
    }

    // Check ownership
    const existingMap = await db.conceptMap.findFirst({
      where: { id, authorId: session.user.id },
    });

    if (!existingMap) {
      return NextResponse.json({ error: "Map not found" }, { status: 404 });
    }

    const map = await db.conceptMap.update({
      where: { id },
      data: validationResult.data,
    });

    return NextResponse.json({ map });
  } catch (error) {
    console.error("Error updating map:", error);
    return NextResponse.json(
      { error: "Failed to update map" },
      { status: 500 }
    );
  }
}

// DELETE /api/maps/[id] - Delete a concept map
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check ownership
    const existingMap = await db.conceptMap.findFirst({
      where: { id, authorId: session.user.id },
    });

    if (!existingMap) {
      return NextResponse.json({ error: "Map not found" }, { status: 404 });
    }

    await db.conceptMap.delete({
      where: { id },
    });

    return NextResponse.json({ message: "Map deleted successfully" });
  } catch (error) {
    console.error("Error deleting map:", error);
    return NextResponse.json(
      { error: "Failed to delete map" },
      { status: 500 }
    );
  }
}
