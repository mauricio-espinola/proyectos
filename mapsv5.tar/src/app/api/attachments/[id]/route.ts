import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { unlink } from "fs/promises";
import path from "path";

// DELETE /api/attachments/[id] - Delete an attachment
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get attachment with node info
    const attachment = await db.nodeAttachment.findUnique({
      where: { id },
      include: {
        node: {
          include: {
            conceptMap: { select: { authorId: true } },
          },
        },
      },
    });

    if (!attachment) {
      return NextResponse.json({ error: "Attachment not found" }, { status: 404 });
    }

    // Check ownership
    if (attachment.node.conceptMap.authorId !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    // Delete file from disk
    try {
      const filepath = path.join(process.cwd(), "public", attachment.url);
      await unlink(filepath);
    } catch {
      // File might not exist, continue with database deletion
    }

    // Delete from database
    await db.nodeAttachment.delete({
      where: { id },
    });

    return NextResponse.json({ message: "Attachment deleted successfully" });
  } catch (error) {
    console.error("Error deleting attachment:", error);
    return NextResponse.json(
      { error: "Failed to delete attachment" },
      { status: 500 }
    );
  }
}
