import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";

// POST /api/attachments - Upload a file attachment
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get("file") as File;
    const nodeId = formData.get("nodeId") as string;

    if (!file || !nodeId) {
      return NextResponse.json({ error: "Missing file or nodeId" }, { status: 400 });
    }

    // Check node ownership via concept map
    const node = await db.node.findUnique({
      where: { id: nodeId },
      include: { conceptMap: { select: { authorId: true } } },
    });

    if (!node) {
      return NextResponse.json({ error: "Node not found" }, { status: 404 });
    }

    if (node.conceptMap.authorId !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    // Determine attachment type
    let attachmentType: "IMAGE" | "AUDIO" | "VIDEO" | "DOCUMENT" = "DOCUMENT";
    if (file.type.startsWith("image/")) attachmentType = "IMAGE";
    else if (file.type.startsWith("audio/")) attachmentType = "AUDIO";
    else if (file.type.startsWith("video/")) attachmentType = "VIDEO";

    // Create uploads directory if it doesn't exist
    const uploadsDir = path.join(process.cwd(), "public", "uploads", "attachments");
    if (!existsSync(uploadsDir)) {
      await mkdir(uploadsDir, { recursive: true });
    }

    // Generate unique filename
    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const ext = file.name.split(".").pop() || "bin";
    const filename = `${timestamp}-${randomSuffix}.${ext}`;
    const filepath = path.join(uploadsDir, filename);

    // Write file to disk
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(filepath, buffer);

    // URL path for the file
    const url = `/uploads/attachments/${filename}`;

    // Create attachment record in database
    const attachment = await db.nodeAttachment.create({
      data: {
        name: file.name,
        type: attachmentType,
        url: url,
        mimeType: file.type,
        fileSize: file.size,
        nodeId: nodeId,
      },
    });

    return NextResponse.json({ attachment });
  } catch (error) {
    console.error("Error uploading attachment:", error);
    return NextResponse.json(
      { error: "Failed to upload attachment" },
      { status: 500 }
    );
  }
}
