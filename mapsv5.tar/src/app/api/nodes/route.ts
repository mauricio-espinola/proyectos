import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

// Force recompile - v2

// Schema for creating a node
const createNodeSchema = z.object({
  conceptMapId: z.string(),
  title: z.string().min(1, "Title is required").max(100),
  description: z.string().optional(),
  type: z.enum(["MAIN", "COMPLEMENT"]).optional().default("MAIN"),
  positionX: z.number().optional().default(0),
  positionY: z.number().optional().default(0),
  width: z.number().optional().default(200),
  height: z.number().optional().default(120),
  color: z.string().optional(),
  mainNodeId: z.string().optional(),
  // For complement nodes
  bullets: z.string().optional(),
  linkType: z.enum(["URL", "VIDEO"]).optional(),
  linkUrl: z.string().optional(),
  linkType2: z.enum(["URL", "VIDEO"]).optional(),
  linkUrl2: z.string().optional(),
});

// GET /api/nodes - Get nodes for a specific map
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const mapId = searchParams.get("mapId");

    if (!mapId) {
      return NextResponse.json({ error: "Map ID is required" }, { status: 400 });
    }

    const nodes = await db.node.findMany({
      where: { conceptMapId: mapId },
      include: {
        attachments: true,
        complements: {
          include: { attachments: true },
        },
      },
      orderBy: { order: "asc" },
    });

    return NextResponse.json({ nodes });
  } catch (error) {
    console.error("Error fetching nodes:", error);
    return NextResponse.json(
      { error: "Failed to fetch nodes" },
      { status: 500 }
    );
  }
}

// POST /api/nodes - Create a new node
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validationResult = createNodeSchema.safeParse(body);
    
    if (!validationResult.success) {
      return NextResponse.json(
        { error: "Validation failed", details: validationResult.error.flatten() },
        { status: 400 }
      );
    }

    const data = validationResult.data;

    // Verify map ownership
    const map = await db.conceptMap.findFirst({
      where: { id: data.conceptMapId, authorId: session.user.id },
    });

    if (!map) {
      return NextResponse.json({ error: "Map not found" }, { status: 404 });
    }

    // Get max order for positioning
    const maxOrder = await db.node.aggregate({
      where: { conceptMapId: data.conceptMapId },
      _max: { order: true },
    });

    const node = await db.node.create({
      data: {
        title: data.title,
        description: data.description,
        type: data.type,
        positionX: data.positionX,
        positionY: data.positionY,
        width: data.width,
        height: data.height,
        color: data.color,
        order: (maxOrder._max.order || 0) + 1,
        conceptMapId: data.conceptMapId,
        mainNodeId: data.mainNodeId,
        // For complement nodes
        bullets: data.bullets,
        linkType: data.linkType,
        linkUrl: data.linkUrl,
        linkType2: data.linkType2,
        linkUrl2: data.linkUrl2,
      },
      include: {
        attachments: true,
        complements: true,
      },
    });

    return NextResponse.json({ node }, { status: 201 });
  } catch (error) {
    console.error("Error creating node:", error);
    return NextResponse.json(
      { error: "Failed to create node" },
      { status: 500 }
    );
  }
}
