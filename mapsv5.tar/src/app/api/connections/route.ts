import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

// Schema for creating a connection
const createConnectionSchema = z.object({
  conceptMapId: z.string(),
  sourceNodeId: z.string(),
  targetNodeId: z.string(),
  label: z.string().max(100).optional(),
  color: z.string().default("#6B7280"),
  sourcePoint: z.enum(["TOP", "RIGHT", "BOTTOM", "LEFT", "CENTER"]).default("RIGHT"),
  targetPoint: z.enum(["TOP", "RIGHT", "BOTTOM", "LEFT", "CENTER"]).default("LEFT"),
  lineStyle: z.enum(["solid", "dashed", "dotted"]).default("solid"),
  lineWidth: z.number().min(1).max(10).default(2),
  curvature: z.number().min(0).max(2).default(0.5),
});

// GET /api/connections - Get connections for a specific map
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const mapId = searchParams.get("mapId");

    if (!mapId) {
      return NextResponse.json({ error: "Map ID is required" }, { status: 400 });
    }

    const connections = await db.connection.findMany({
      where: { conceptMapId: mapId },
      include: {
        sourceNode: { select: { id: true, title: true } },
        targetNode: { select: { id: true, title: true } },
      },
    });

    return NextResponse.json({ connections });
  } catch (error) {
    console.error("Error fetching connections:", error);
    return NextResponse.json(
      { error: "Failed to fetch connections" },
      { status: 500 }
    );
  }
}

// POST /api/connections - Create a new connection
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validationResult = createConnectionSchema.safeParse(body);
    
    if (!validationResult.success) {
      return NextResponse.json(
        { error: "Validation failed", details: validationResult.error.flatten() },
        { status: 400 }
      );
    }

    const data = validationResult.data;

    // Verify map ownership
    const map = await db.conceptMap.findFirst({
      where: { id: data.conceptMapId, authorId: session.user.id },
    });

    if (!map) {
      return NextResponse.json({ error: "Map not found" }, { status: 404 });
    }

    // Verify nodes exist in this map
    const nodes = await db.node.findMany({
      where: {
        id: { in: [data.sourceNodeId, data.targetNodeId] },
        conceptMapId: data.conceptMapId,
      },
    });

    if (nodes.length !== 2) {
      return NextResponse.json({ error: "Invalid nodes" }, { status: 400 });
    }

    // Check if connection already exists
    const existingConnection = await db.connection.findFirst({
      where: {
        sourceNodeId: data.sourceNodeId,
        targetNodeId: data.targetNodeId,
        conceptMapId: data.conceptMapId,
      },
    });

    if (existingConnection) {
      return NextResponse.json(
        { error: "Connection already exists" },
        { status: 409 }
      );
    }

    const connection = await db.connection.create({
      data: {
        conceptMapId: data.conceptMapId,
        sourceNodeId: data.sourceNodeId,
        targetNodeId: data.targetNodeId,
        label: data.label,
        color: data.color,
        sourcePoint: data.sourcePoint,
        targetPoint: data.targetPoint,
        lineStyle: data.lineStyle,
        lineWidth: data.lineWidth,
        curvature: data.curvature,
      },
      include: {
        sourceNode: { select: { id: true, title: true } },
        targetNode: { select: { id: true, title: true } },
      },
    });

    return NextResponse.json({ connection }, { status: 201 });
  } catch (error) {
    console.error("Error creating connection:", error);
    return NextResponse.json(
      { error: "Failed to create connection" },
      { status: 500 }
    );
  }
}
