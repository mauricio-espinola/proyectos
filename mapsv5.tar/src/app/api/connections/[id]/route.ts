import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

// Schema for updating a connection
const updateConnectionSchema = z.object({
  label: z.string().max(100).optional(),
  color: z.string().optional(),
  sourcePoint: z.enum(["TOP", "RIGHT", "BOTTOM", "LEFT", "CENTER"]).optional(),
  targetPoint: z.enum(["TOP", "RIGHT", "BOTTOM", "LEFT", "CENTER"]).optional(),
  lineStyle: z.enum(["solid", "dashed", "dotted"]).optional(),
  lineWidth: z.number().min(1).max(10).optional(),
  curvature: z.number().min(0).max(2).optional(),
});

// GET /api/connections/[id] - Get a specific connection
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const connection = await db.connection.findUnique({
      where: { id },
      include: {
        sourceNode: { select: { id: true, title: true } },
        targetNode: { select: { id: true, title: true } },
        conceptMap: { select: { authorId: true } },
      },
    });

    if (!connection) {
      return NextResponse.json({ error: "Connection not found" }, { status: 404 });
    }

    if (connection.conceptMap.authorId !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    return NextResponse.json({ connection });
  } catch (error) {
    console.error("Error fetching connection:", error);
    return NextResponse.json(
      { error: "Failed to fetch connection" },
      { status: 500 }
    );
  }
}

// PUT /api/connections/[id] - Update a connection
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validationResult = updateConnectionSchema.safeParse(body);
    
    if (!validationResult.success) {
      return NextResponse.json(
        { error: "Validation failed", details: validationResult.error.flatten() },
        { status: 400 }
      );
    }

    // Check ownership
    const existingConnection = await db.connection.findUnique({
      where: { id },
      include: { conceptMap: { select: { authorId: true } } },
    });

    if (!existingConnection) {
      return NextResponse.json({ error: "Connection not found" }, { status: 404 });
    }

    if (existingConnection.conceptMap.authorId !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const connection = await db.connection.update({
      where: { id },
      data: validationResult.data,
      include: {
        sourceNode: { select: { id: true, title: true } },
        targetNode: { select: { id: true, title: true } },
      },
    });

    return NextResponse.json({ connection });
  } catch (error) {
    console.error("Error updating connection:", error);
    return NextResponse.json(
      { error: "Failed to update connection" },
      { status: 500 }
    );
  }
}

// DELETE /api/connections/[id] - Delete a connection
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check ownership
    const existingConnection = await db.connection.findUnique({
      where: { id },
      include: { conceptMap: { select: { authorId: true } } },
    });

    if (!existingConnection) {
      return NextResponse.json({ error: "Connection not found" }, { status: 404 });
    }

    if (existingConnection.conceptMap.authorId !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    await db.connection.delete({
      where: { id },
    });

    return NextResponse.json({ message: "Connection deleted successfully" });
  } catch (error) {
    console.error("Error deleting connection:", error);
    return NextResponse.json(
      { error: "Failed to delete connection" },
      { status: 500 }
    );
  }
}
