"use client";

import { useState, useEffect, useCallback } from "react";
import { SessionProvider, useSession } from "next-auth/react";
import { motion } from "framer-motion";
import { AuthForm } from "@/components/auth/auth-form";
import { ConceptMapCanvas } from "@/components/canvas/concept-map-canvas";
import { NodePanel } from "@/components/panels/node-panel";
import { ConnectionPanel } from "@/components/panels/connection-panel";
import { MapListPanel } from "@/components/panels/map-list-panel";
import { AppHeader } from "@/components/layout/app-header";
import { useCanvasStore, MapData } from "@/store/canvas-store";
import { Toaster } from "@/components/ui/toaster";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

function ConceptMapAppContent() {
  const { status } = useSession();
  const [maps, setMaps] = useState<MapData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newMapTitle, setNewMapTitle] = useState("");
  
  const {
    currentMap,
    setCurrentMap,
    addNode,
    updateNode,
    removeNode,
    addConnection,
    updateConnection,
    removeConnection,
    toggleMapList,
  } = useCanvasStore();

  // Fetch maps on mount
  useEffect(() => {
    if (status === "authenticated") {
      fetchMaps();
    }
  }, [status]);

  const fetchMaps = async () => {
    try {
      setIsLoading(true);
      const response = await fetch("/api/maps");
      const data = await response.json();
      if (response.ok) {
        setMaps(data.maps);
      }
    } catch (error) {
      console.error("Error fetching maps:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMap = async (mapId: string) => {
    try {
      const response = await fetch(`/api/maps/${mapId}`);
      const data = await response.json();
      if (response.ok) {
        setCurrentMap(data.map);
      }
    } catch (error) {
      console.error("Error fetching map:", error);
    }
  };

  // Map operations
  const handleCreateMap = async (title: string) => {
    try {
      const response = await fetch("/api/maps", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
      });
      const data = await response.json();
      if (response.ok) {
        setMaps([data.map, ...maps]);
        setCurrentMap(data.map);
        // toast({ title: "Mapa creado", description: "El mapa se ha creado exitosamente" });
      }
    } catch (error) {
      console.error("Error creating map:", error);
      toast({ title: "Error", description: "No se pudo crear el mapa", variant: "destructive" });
    }
  };

  const handleSelectMap = async (mapId: string) => {
    await fetchMap(mapId);
  };

  const handleDeleteMap = async (mapId: string) => {
    try {
      const response = await fetch(`/api/maps/${mapId}`, { method: "DELETE" });
      if (response.ok) {
        setMaps(maps.filter((m) => m.id !== mapId));
        if (currentMap?.id === mapId) {
          setCurrentMap(null);
        }
        toast({ title: "Mapa eliminado" });
      }
    } catch (error) {
      console.error("Error deleting map:", error);
    }
  };

  // Open create map dialog
  const handleOpenCreateDialog = useCallback(() => {
    setNewMapTitle("");
    setShowCreateDialog(true);
  }, []);

  // Confirm create map
  const handleConfirmCreate = async () => {
    if (newMapTitle.trim()) {
      await handleCreateMap(newMapTitle.trim());
      setShowCreateDialog(false);
      setNewMapTitle("");
    }
  };

  // Node operations
  const handleCreateNode = async (x: number, y: number) => {
    if (!currentMap) return;
    
    try {
      const response = await fetch("/api/nodes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conceptMapId: currentMap.id,
          title: "Nuevo Nodo",
          positionX: x,
          positionY: y,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        addNode(data.node);
        // toast({ title: "Nodo creado" });
      }
    } catch (error) {
      console.error("Error creating node:", error);
    }
  };

  const handleUpdateNodePosition = async (nodeId: string, x: number, y: number) => {
    if (!currentMap) return;
    
    try {
      const response = await fetch(`/api/nodes/${nodeId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ positionX: x, positionY: y }),
      });
      const data = await response.json();
      if (response.ok) {
        updateNode(nodeId, { positionX: x, positionY: y });
      }
    } catch (error) {
      console.error("Error updating node position:", error);
    }
  };

  const handleUpdateNode = async (nodeId: string, data: Record<string, unknown>) => {
    try {
      const response = await fetch(`/api/nodes/${nodeId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (response.ok) {
        updateNode(nodeId, data);
      }
    } catch (error) {
      console.error("Error updating node:", error);
    }
  };

  const handleDeleteNode = async (nodeId: string) => {
    try {
      const response = await fetch(`/api/nodes/${nodeId}`, { method: "DELETE" });
      if (response.ok) {
        removeNode(nodeId);
        toast({ title: "Nodo eliminado" });
      }
    } catch (error) {
      console.error("Error deleting node:", error);
    }
  };

  // Add complement node with image and/or bullets
  const handleAddComplement = async (
    mainNodeId: string, 
    linkType: "IMAGE" | "AUDIO" | "VIDEO" | "LINK", 
    data?: { url?: string; title?: string; imageFile?: File; bullets?: string; linkType2?: "URL" | "VIDEO"; linkUrl2?: string }
  ) => {
    if (!currentMap) return;
    
    // Get main node position
    const mainNode = currentMap.nodes.find(n => n.id === mainNodeId);
    if (!mainNode) return;

    try {
      // Create complement node positioned next to the main node
      const response = await fetch("/api/nodes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conceptMapId: currentMap.id,
          title: data?.title || `Complemento`,
          type: "COMPLEMENT",
          mainNodeId: mainNodeId,
          positionX: mainNode.positionX + mainNode.width + 20,
          positionY: mainNode.positionY,
          width: 80,
          height: 80,
          // Link 1
          linkType: linkType === "LINK" ? "URL" : linkType,
          linkUrl: data?.url || "",
          // Link 2
          linkType2: data?.linkType2,
          linkUrl2: data?.linkUrl2,
          // Bullets
          bullets: data?.bullets || "",
        }),
      });
      const result = await response.json();
      
      if (response.ok && result.node) {
        // If there's an image file, upload it to the new node
        if (data?.imageFile) {
          const formData = new FormData();
          formData.append("file", data.imageFile);
          formData.append("nodeId", result.node.id);

          const uploadResponse = await fetch("/api/attachments", {
            method: "POST",
            body: formData,
          });

          if (uploadResponse.ok) {
            // Refresh the map to get the updated node with attachment
            await fetchMap(currentMap.id);
          } else {
            console.error("Failed to upload image to complement");
          }
        } else {
          addNode(result.node);
        }
        toast({ title: "Complemento agregado" });
      }
    } catch (error) {
      console.error("Error adding complement:", error);
    }
  };

  // Upload attachment
  const handleUploadAttachment = async (nodeId: string, file: File): Promise<{
    id: string;
    name: string;
    type: "IMAGE" | "AUDIO" | "VIDEO" | "DOCUMENT" | "LINK";
    url: string;
    thumbnail?: string;
    description?: string;
  } | null> => {
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("nodeId", nodeId);

      const response = await fetch("/api/attachments", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      if (response.ok) {
        // Refresh the map to get updated node with attachments
        await fetchMap(currentMap!.id);
        return data.attachment;
      } else {
        toast({ title: "Error", description: data.error || "No se pudo subir el archivo", variant: "destructive" });
        return null;
      }
    } catch (error) {
      console.error("Error uploading attachment:", error);
      return null;
    }
  };

  // Remove attachment
  const handleRemoveAttachment = async (nodeId: string, attachmentId: string): Promise<void> => {
    try {
      const response = await fetch(`/api/attachments/${attachmentId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        // Refresh the map to get updated node without the attachment
        await fetchMap(currentMap!.id);
      } else {
        const data = await response.json();
        toast({ title: "Error", description: data.error || "No se pudo eliminar el adjunto", variant: "destructive" });
      }
    } catch (error) {
      console.error("Error removing attachment:", error);
    }
  };

  // Connection operations
  const handleCreateConnection = async (
    sourceId: string,
    targetId: string,
    sourcePoint: string,
    targetPoint: string
  ) => {
    if (!currentMap) return;
    
    try {
      const response = await fetch("/api/connections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conceptMapId: currentMap.id,
          sourceNodeId: sourceId,
          targetNodeId: targetId,
          sourcePoint,
          targetPoint,
          color: "#6B7280",
        }),
      });
      const data = await response.json();
      if (response.ok) {
        addConnection(data.connection);
        // toast({ title: "Conexión creada" });
      } else {
        toast({ title: "Error", description: data.error, variant: "destructive" });
      }
    } catch (error) {
      console.error("Error creating connection:", error);
    }
  };

  const handleUpdateConnection = async (connectionId: string, data: Record<string, unknown>) => {
    try {
      const response = await fetch(`/api/connections/${connectionId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) {
        updateConnection(connectionId, data);
      }
    } catch (error) {
      console.error("Error updating connection:", error);
    }
  };

  const handleDeleteConnection = async (connectionId: string) => {
    try {
      const response = await fetch(`/api/connections/${connectionId}`, { method: "DELETE" });
      if (response.ok) {
        removeConnection(connectionId);
        toast({ title: "Conexión eliminada" });
      }
    } catch (error) {
      console.error("Error deleting connection:", error);
    }
  };

  // Save current map
  const handleSave = async () => {
    if (!currentMap) return;
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      toast({ title: "Guardado", description: "Todos los cambios han sido guardados" });
    }, 500);
  };

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (status === "unauthenticated") {
    return <AuthForm />;
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900 overflow-hidden">
      <AppHeader onSave={handleSave} isSaving={isSaving} />
      
      <div className="flex-1 relative overflow-hidden">
        {/* Map List Panel */}
        <MapListPanel
          maps={maps}
          onCreateMap={handleCreateMap}
          onSelectMap={handleSelectMap}
          onDeleteMap={handleDeleteMap}
          isLoading={isLoading}
        />

        {/* Canvas */}
        <ConceptMapCanvas
          onCreateNode={handleCreateNode}
          onUpdateNodePosition={handleUpdateNodePosition}
          onCreateConnection={handleCreateConnection}
          onCreateMap={handleOpenCreateDialog}
          onOpenMapList={toggleMapList}
        />

        {/* Node Panel */}
        <NodePanel
          onUpdateNode={handleUpdateNode}
          onDeleteNode={handleDeleteNode}
          onAddComplement={handleAddComplement}
          onUploadAttachment={handleUploadAttachment}
          onRemoveAttachment={handleRemoveAttachment}
        />

        {/* Connection Panel */}
        <ConnectionPanel
          onUpdateConnection={handleUpdateConnection}
          onDeleteConnection={handleDeleteConnection}
        />
      </div>

      {/* Create Map Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Crear Nuevo Mapa</DialogTitle>
            <DialogDescription>
              Ingresa un título para tu nuevo mapa conceptual.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="map-title" className="sr-only">
              Título del mapa
            </Label>
            <Input
              id="map-title"
              placeholder="Ej: Mi primer mapa conceptual"
              value={newMapTitle}
              onChange={(e) => setNewMapTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && newMapTitle.trim()) {
                  handleConfirmCreate();
                }
              }}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleConfirmCreate}
              disabled={!newMapTitle.trim()}
              className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
            >
              Crear Mapa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Toaster />
    </div>
  );
}

export function ConceptMapApp() {
  return (
    <SessionProvider>
      <ConceptMapAppContent />
    </SessionProvider>
  );
}
