"use client";

import { memo, useMemo } from "react";
import { motion } from "framer-motion";
import { useCanvasStore, ConnectionData, NodeData } from "@/store/canvas-store";

interface CanvasConnectionProps {
  connection: ConnectionData;
  nodes: NodeData[];
  scale: number;
  panOffset: { x: number; y: number };
}

// Get connection point at the exact center of each side
function getConnectionPoint(
  node: NodeData,
  point: "TOP" | "RIGHT" | "BOTTOM" | "LEFT" | "CENTER"
): { x: number; y: number } {
  // Node dimensions - use stored values
  const width = node.width;
  const height = node.height;
  const x = node.positionX;
  const y = node.positionY;

  switch (point) {
    case "TOP":
      return { x: x + width / 2, y: y }; // Center of top edge
    case "RIGHT":
      return { x: x + width, y: y + height / 2 }; // Center of right edge
    case "BOTTOM":
      return { x: x + width / 2, y: y + height }; // Center of bottom edge
    case "LEFT":
      return { x: x, y: y + height / 2 }; // Center of left edge
    case "CENTER":
    default:
      return { x: x + width / 2, y: y + height / 2 }; // Exact center
  }
}

function getSmartPath(
  source: { x: number; y: number },
  target: { x: number; y: number },
  sourcePoint: string,
  targetPoint: string
): string {
  // Calculate control points based on which side the connection is on
  // This creates a more natural curve that exits perpendicular to the edge
  
  const getControlOffset = (point: string, distance: number = 50) => {
    switch (point) {
      case "TOP": return { x: 0, y: -distance };
      case "RIGHT": return { x: distance, y: 0 };
      case "BOTTOM": return { x: 0, y: distance };
      case "LEFT": return { x: -distance, y: 0 };
      default: return { x: 0, y: 0 };
    }
  };

  const sourceOffset = getControlOffset(sourcePoint);
  const targetOffset = getControlOffset(targetPoint);

  const cp1 = {
    x: source.x + sourceOffset.x,
    y: source.y + sourceOffset.y,
  };

  const cp2 = {
    x: target.x + targetOffset.x,
    y: target.y + targetOffset.y,
  };

  return `M ${source.x} ${source.y} C ${cp1.x} ${cp1.y}, ${cp2.x} ${cp2.y}, ${target.x} ${target.y}`;
}

export const CanvasConnection = memo(function CanvasConnection({
  connection,
  nodes,
}: CanvasConnectionProps) {
  const { selectedConnectionId, selectConnection, hoveredNodeId } = useCanvasStore();

  const sourceNode = nodes.find((n) => n.id === connection.sourceNodeId);
  const targetNode = nodes.find((n) => n.id === connection.targetNodeId);

  const isSelected = selectedConnectionId === connection.id;
  const isHovered = hoveredNodeId === connection.sourceNodeId || 
                    hoveredNodeId === connection.targetNodeId;

  const pathData = useMemo(() => {
    if (!sourceNode || !targetNode) return null;

    const source = getConnectionPoint(sourceNode, connection.sourcePoint);
    const target = getConnectionPoint(targetNode, connection.targetPoint);

    return {
      path: getSmartPath(source, target, connection.sourcePoint, connection.targetPoint),
      source,
      target,
      midPoint: {
        x: (source.x + target.x) / 2,
        y: (source.y + target.y) / 2,
      },
    };
  }, [sourceNode, targetNode, connection]);

  if (!pathData || !sourceNode || !targetNode) return null;

  const getStrokeDasharray = () => {
    switch (connection.lineStyle) {
      case "dashed": return "8 4";
      case "dotted": return "2 4";
      default: return "none";
    }
  };

  return (
    <g
      className="cursor-pointer"
      onClick={(e) => {
        e.stopPropagation();
        selectConnection(connection.id);
      }}
    >
      {/* Invisible wider path for easier clicking */}
      <path
        d={pathData.path}
        fill="none"
        stroke="transparent"
        strokeWidth={20}
      />

      {/* Visible connection line */}
      <motion.path
        d={pathData.path}
        fill="none"
        stroke={connection.color}
        strokeWidth={isSelected ? connection.lineWidth + 1 : connection.lineWidth}
        strokeDasharray={getStrokeDasharray()}
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ 
          pathLength: 1, 
          opacity: isHovered || isSelected ? 1 : 0.7 
        }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
        className="transition-all duration-200"
        style={{
          filter: isSelected ? `drop-shadow(0 0 6px ${connection.color})` : "none",
        }}
      />

      {/* Connection label */}
      {connection.label && (
        <motion.g
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <rect
            x={pathData.midPoint.x - 40}
            y={pathData.midPoint.y - 10}
            width={80}
            height={20}
            rx={10}
            fill="white"
            stroke={connection.color}
            strokeWidth={1}
            className="dark:fill-gray-800"
          />
          <text
            x={pathData.midPoint.x}
            y={pathData.midPoint.y + 4}
            textAnchor="middle"
            fontSize={10}
            fill={connection.color}
            className="font-medium pointer-events-none select-none dark:fill-white"
          >
            {connection.label.length > 12 
              ? connection.label.slice(0, 12) + "..."
              : connection.label
            }
          </text>
        </motion.g>
      )}

      {/* Endpoint dots at exact connection points */}
      <motion.circle
        cx={pathData.source.x}
        cy={pathData.source.y}
        r={4}
        fill={connection.color}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2 }}
      />
      <motion.circle
        cx={pathData.target.x}
        cy={pathData.target.y}
        r={4}
        fill={connection.color}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.3 }}
      />
    </g>
  );
});
