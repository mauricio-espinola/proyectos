"use client";

import { useCallback, useRef, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCanvasStore } from "@/store/canvas-store";
import { CanvasNode } from "./canvas-node";
import { CanvasConnection } from "./canvas-connection";
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Plus, 
  Move,
  Grid3X3,
  Eye,
  EyeOff,
  Map,
  FolderOpen,
  Link2,
  Hand
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

interface ConceptMapCanvasProps {
  onCreateNode: (x: number, y: number) => void;
  onUpdateNodePosition: (nodeId: string, x: number, y: number) => void;
  onCreateConnection: (sourceId: string, targetId: string, sourcePoint: string, targetPoint: string) => void;
  onCreateMap?: () => void;
  onOpenMapList?: () => void;
}

export function ConceptMapCanvas({
  onCreateNode,
  onUpdateNodePosition,
  onCreateConnection,
  onCreateMap,
  onOpenMapList,
}: ConceptMapCanvasProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [startPan, setStartPan] = useState({ x: 0, y: 0 });
  const [showGrid, setShowGrid] = useState(true);
  const [isPanMode, setIsPanMode] = useState(false);
  const [spacePressed, setSpacePressed] = useState(false);
  
  const {
    currentMap,
    zoom,
    panOffset,
    setZoom,
    setPanOffset,
    isConnecting,
    connectingFrom,
    startConnecting,
    stopConnecting,
    selectNode,
  } = useCanvasStore();

  // Reset view - defined first because it's used in keyboard handler
  const handleResetView = useCallback(() => {
    setZoom(1);
    setPanOffset({ x: 0, y: 0 });
  }, [setZoom, setPanOffset]);

  // Handle keyboard for pan mode (space key)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture space when typing in inputs, textareas, or contenteditable elements
      const target = e.target as HTMLElement;
      const isTyping = target.tagName === 'INPUT' || 
                       target.tagName === 'TEXTAREA' || 
                       target.isContentEditable;
      
      if (e.code === "Space" && !e.repeat && !isConnecting && !isTyping) {
        e.preventDefault();
        setSpacePressed(true);
      }
      if (e.key === "Escape") {
        stopConnecting();
        setIsPanMode(false);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === "0") {
        e.preventDefault();
        handleResetView();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      // Also check for typing context on key up
      const target = e.target as HTMLElement;
      const isTyping = target.tagName === 'INPUT' || 
                       target.tagName === 'TEXTAREA' || 
                       target.isContentEditable;
      
      if (e.code === "Space" && !isTyping) {
        setSpacePressed(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [stopConnecting, isConnecting, handleResetView]);

  // Handle wheel zoom
  const handleWheel = useCallback(
    (e: React.WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const delta = e.deltaY > 0 ? -0.1 : 0.1;
        setZoom(zoom + delta);
      } else {
        setPanOffset({
          x: panOffset.x - e.deltaX,
          y: panOffset.y - e.deltaY,
        });
      }
    },
    [zoom, panOffset, setZoom, setPanOffset]
  );

  // Handle panning - can be activated by: middle click, alt+click, pan mode button, or space key
  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      const isCanvasBackground = target === canvasRef.current || target.classList.contains('canvas-grid');
      
      // Start panning if: middle mouse, alt+click, pan mode active, space pressed, or clicking on canvas background
      const shouldPan = e.button === 1 || 
                       (e.button === 0 && e.altKey) || 
                       (e.button === 0 && isPanMode) ||
                       (e.button === 0 && spacePressed) ||
                       (e.button === 0 && isCanvasBackground && !isConnecting);
      
      if (shouldPan) {
        e.preventDefault();
        setIsPanning(true);
        setStartPan({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      }
    },
    [panOffset, isPanMode, spacePressed, isConnecting]
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (isPanning) {
        setPanOffset({
          x: e.clientX - startPan.x,
          y: e.clientY - startPan.y,
        });
      }
    },
    [isPanning, startPan, setPanOffset]
  );

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
  }, []);

  // Handle connection creation
  const handleConnectionStart = useCallback(
    (nodeId: string, point: string, _e: React.MouseEvent) => {
      startConnecting(nodeId, point);
    },
    [startConnecting]
  );

  const handleConnectionEnd = useCallback(
    (nodeId: string, point: string) => {
      if (connectingFrom && connectingFrom.nodeId !== nodeId) {
        onCreateConnection(
          connectingFrom.nodeId,
          nodeId,
          connectingFrom.point,
          point
        );
      }
      stopConnecting();
    },
    [connectingFrom, onCreateConnection, stopConnecting]
  );

  // Handle double click for creating nodes on canvas
  const handleCanvasDoubleClick = useCallback(
    (e: React.MouseEvent) => {
      // Only create node if double-clicking directly on the canvas background
      const target = e.target as HTMLElement;
      if (target === canvasRef.current || target.classList.contains('canvas-grid')) {
        // Create at a simple visible position (200, 150)
        onCreateNode(200, 150);
      }
      stopConnecting();
    },
    [onCreateNode, stopConnecting]
  );

  // Handle single click - close node panel and stop connecting
  const handleCanvasClick = useCallback(
    (e: React.MouseEvent) => {
      // Only handle clicks directly on the canvas (not on nodes/connections)
      const target = e.target as HTMLElement;
      if (target === canvasRef.current || target.classList.contains('canvas-grid')) {
        // Close node panel when clicking on canvas
        selectNode(null);
      }
      // Stop connecting mode
      if (isConnecting) {
        stopConnecting();
      }
    },
    [isConnecting, stopConnecting, selectNode]
  );

  // Handle button click to add node (with fixed position)
  const handleAddNodeClick = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    // Create node at a fixed position that's always visible (200, 150)
    // This is in canvas coordinates, not screen coordinates
    onCreateNode(200, 150);
  }, [onCreateNode]);

  // Toggle pan mode
  const handleTogglePanMode = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setIsPanMode(prev => !prev);
  }, []);

  // Determine cursor style
  const getCursorStyle = () => {
    if (isPanning) return "cursor-grabbing";
    if (isPanMode || spacePressed) return "cursor-grab";
    if (isConnecting) return "cursor-crosshair";
    return "";
  };

  // Empty state - No map selected
  if (!currentMap) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900 min-h-[calc(100vh-56px)]">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center px-4"
        >
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", duration: 0.6 }}
            className="w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-gray-200 to-gray-300 dark:from-gray-700 dark:to-gray-800 flex items-center justify-center shadow-lg"
          >
            <Grid3X3 className="w-12 h-12 text-gray-400 dark:text-gray-500" />
          </motion.div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            No hay mapa seleccionado
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-sm mx-auto">
            Crea un nuevo mapa conceptual o selecciona uno existente para comenzar a trabajar
          </p>
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg"
              onClick={onCreateMap}
            >
              <Plus className="w-5 h-5 mr-2" />
              Crear Nuevo Mapa
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 shadow-lg"
              onClick={onOpenMapList}
            >
              <FolderOpen className="w-5 h-5 mr-2" />
              Ver Mis Mapas
            </Button>
          </div>
          
          {/* Help text */}
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-8">
            💡 También puedes usar el menú ☰ en la esquina superior izquierda
          </p>
        </motion.div>
      </div>
    );
  }

  // Map is selected - Show canvas with controls
  return (
    <div className="relative flex-1 overflow-hidden bg-gray-50 dark:bg-gray-900 h-full">
      
      {/* Status Bar - Top Left */}
      <div className="absolute top-4 left-4 z-30 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg px-4 py-2 shadow-lg border border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-3 text-sm">
          <Map className="w-4 h-4 text-emerald-500" />
          <span className="font-medium text-gray-900 dark:text-white">
            {currentMap.title}
          </span>
          <span className="text-gray-300 dark:text-gray-600">|</span>
          <span className="text-gray-500 dark:text-gray-400">
            {currentMap.nodes.length} nodos
          </span>
          <span className="text-gray-300 dark:text-gray-600">|</span>
          <span className="text-gray-500 dark:text-gray-400">
            {currentMap.connections.length} conexiones
          </span>
          {isConnecting && (
            <>
              <span className="text-gray-300 dark:text-gray-600">|</span>
              <span className="text-emerald-500 font-medium animate-pulse">
                Conectando...
              </span>
            </>
          )}
          {isPanMode && (
            <>
              <span className="text-gray-300 dark:text-gray-600">|</span>
              <span className="text-blue-500 font-medium">
                Modo Mover
              </span>
            </>
          )}
        </div>
      </div>

      {/* Canvas Area */}
      <div
        ref={canvasRef}
        className={cn(
          "absolute inset-0",
          getCursorStyle()
        )}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={handleCanvasClick}
        onDoubleClick={handleCanvasDoubleClick}
      >
        {/* Grid pattern */}
        {showGrid && (
          <div
            className="absolute inset-0 pointer-events-none canvas-grid"
            style={{
              backgroundImage: `
                linear-gradient(to right, rgba(0,0,0,0.05) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(0,0,0,0.05) 1px, transparent 1px)
              `,
              backgroundSize: `${20 * zoom}px ${20 * zoom}px`,
              backgroundPosition: `${panOffset.x}px ${panOffset.y}px`,
            }}
          />
        )}

        {/* Transformable content */}
        <motion.div
          className="absolute"
          style={{
            transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoom})`,
            transformOrigin: "0 0",
          }}
        >
          {/* SVG for connections */}
          <svg
            className="absolute top-0 left-0 pointer-events-none"
            style={{
              width: "10000px",
              height: "10000px",
            }}
          >
            <g className="pointer-events-auto">
              <AnimatePresence>
                {currentMap.connections.map((connection) => (
                  <CanvasConnection
                    key={connection.id}
                    connection={connection}
                    nodes={currentMap.nodes}
                    scale={zoom}
                    panOffset={panOffset}
                  />
                ))}
              </AnimatePresence>
            </g>
          </svg>

          {/* Nodes */}
          <AnimatePresence>
            {currentMap.nodes.map((node) => (
              <CanvasNode
                key={node.id}
                node={node}
                scale={zoom}
                onDragEnd={onUpdateNodePosition}
                onConnectionStart={handleConnectionStart}
                onConnectionEnd={handleConnectionEnd}
                isConnecting={isConnecting}
                connectingFrom={connectingFrom}
              />
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Empty canvas message */}
        {currentMap.nodes.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center text-gray-400 dark:text-gray-500">
              <p className="text-lg mb-2">Canvas vacío</p>
              <p className="text-sm">Haz clic en "Agregar Nodo" o doble clic en el canvas para comenzar</p>
            </div>
          </div>
        )}

        {/* Connection preview line while connecting */}
        {isConnecting && connectingFrom && (
          <div className="absolute inset-0 pointer-events-none z-20">
            <svg className="w-full h-full">
              <line
                x1="0"
                y1="0"
                x2="0"
                y2="0"
                stroke="rgb(16, 185, 129)"
                strokeWidth="2"
                strokeDasharray="5 5"
                className="animate-pulse"
              />
            </svg>
          </div>
        )}
      </div>

      {/* Action Buttons - Bottom Left */}
      <div className="absolute bottom-6 left-6 z-30 flex gap-3">
        <Button
          size="default"
          className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg h-10 px-5"
          onClick={handleAddNodeClick}
        >
          <Plus className="w-4 h-4 mr-2" />
          Agregar Nodo
        </Button>
        <Button
          size="default"
          variant="outline"
          className="shadow-lg h-10 px-5 border-2"
          onClick={(e) => {
            e.stopPropagation();
            toast({ title: "Conexión", description: "Pasa el mouse sobre un nodo, aparecerán 4 puntos de conexión. Haz clic en uno y luego en otro nodo para conectarlos." });
          }}
        >
          <Link2 className="w-4 h-4 mr-2" />
          Conectar Nodos
        </Button>
        <Button
          size="default"
          variant={isPanMode ? "default" : "outline"}
          className={cn(
            "shadow-lg h-10 px-5 border-2",
            isPanMode && "bg-blue-500 hover:bg-blue-600 text-white border-blue-500"
          )}
          onClick={handleTogglePanMode}
          title="Modo mover canvas (o mantén Espacio)"
        >
          <Hand className="w-4 h-4 mr-2" />
          Mover
        </Button>
      </div>

      {/* Zoom Controls - Bottom Right */}
      <div className="absolute bottom-6 right-6 z-30 flex flex-col gap-2">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 p-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={(e) => { e.stopPropagation(); setZoom(zoom + 0.1); }}
            title="Acercar"
          >
            <ZoomIn className="w-5 h-5" />
          </Button>
          <div className="text-xs text-center py-1 text-gray-500 dark:text-gray-400 font-medium">
            {Math.round(zoom * 100)}%
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={(e) => { e.stopPropagation(); setZoom(zoom - 0.1); }}
            title="Alejar"
          >
            <ZoomOut className="w-5 h-5" />
          </Button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 p-1 flex flex-col gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={(e) => { e.stopPropagation(); handleResetView(); }}
            title="Restablecer vista"
          >
            <Maximize2 className="w-5 h-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={(e) => { e.stopPropagation(); setShowGrid(!showGrid); }}
            title={showGrid ? "Ocultar grid" : "Mostrar grid"}
          >
            {showGrid ? (
              <Eye className="w-5 h-5" />
            ) : (
              <EyeOff className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>

      {/* Pan indicator */}
      {isPanning && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-40">
          <div className="bg-black/60 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow-xl">
            <Move className="w-5 h-5" />
            <span>Arrastrando vista</span>
          </div>
        </div>
      )}
    </div>
  );
}
