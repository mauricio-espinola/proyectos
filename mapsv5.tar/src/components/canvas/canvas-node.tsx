"use client";

import { memo, useCallback, useState, useRef } from "react";
import { motion } from "framer-motion";
import { useCanvasStore, NodeData } from "@/store/canvas-store";
import { cn } from "@/lib/utils";
import {
  FileText,
  Image as ImageIcon,
  Video,
  Link2,
  XCircle,
} from "lucide-react";

interface CanvasNodeProps {
  node: NodeData;
  scale: number;
  onDragEnd: (nodeId: string, x: number, y: number) => void;
  onConnectionStart: (nodeId: string, point: string, e: React.MouseEvent) => void;
  onConnectionEnd: (nodeId: string, point: string) => void;
  isConnecting: boolean;
  connectingFrom: { nodeId: string; point: string } | null;
}

const connectionPoints = [
  { id: "TOP" },
  { id: "RIGHT" },
  { id: "BOTTOM" },
  { id: "LEFT" },
];

// Minimum pixels to consider it a drag (not a click)
const DRAG_THRESHOLD = 5;

export const CanvasNode = memo(function CanvasNode({
  node,
  scale,
  onDragEnd,
  onConnectionStart,
  onConnectionEnd,
  isConnecting,
  connectingFrom,
}: CanvasNodeProps) {
  const { selectedNodeId, selectNode, hoveredNodeId, hoverNode } = useCanvasStore();
  const [isDragging, setIsDragging] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [naturalSize, setNaturalSize] = useState({ width: 0, height: 0 });
  const dragStartRef = useRef({ mouseX: 0, mouseY: 0, nodeX: 0, nodeY: 0 });
  const prevImageUrlRef = useRef<string | undefined>(undefined);

  const isSelected = selectedNodeId === node.id;
  const isHovered = hoveredNodeId === node.id;

  // Reset image error when attachment changes
  const currentImageUrl = node.attachments?.[0]?.url;
  if (prevImageUrlRef.current !== currentImageUrl) {
    prevImageUrlRef.current = currentImageUrl;
    if (imageError) {
      setImageError(false);
    }
  }

  // Handle drag start
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    if ((e.target as HTMLElement).closest('.connection-point')) return;

    e.preventDefault();
    e.stopPropagation();

    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      nodeX: node.positionX,
      nodeY: node.positionY,
    };

    setIsDragging(true);
  }, [node.positionX, node.positionY]);

  // Handle drag move and end
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;

    const screenDeltaX = e.clientX - dragStartRef.current.mouseX;
    const screenDeltaY = e.clientY - dragStartRef.current.mouseY;

    const canvasDeltaX = screenDeltaX / scale;
    const canvasDeltaY = screenDeltaY / scale;

    const nodeEl = document.querySelector(`[data-node-id="${node.id}"]`) as HTMLElement;
    if (nodeEl) {
      nodeEl.style.left = `${dragStartRef.current.nodeX + canvasDeltaX}px`;
      nodeEl.style.top = `${dragStartRef.current.nodeY + canvasDeltaY}px`;
    }
  }, [isDragging, scale, node.id]);

  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;

    const screenDeltaX = e.clientX - dragStartRef.current.mouseX;
    const screenDeltaY = e.clientY - dragStartRef.current.mouseY;

    const wasClick = Math.abs(screenDeltaX) <= DRAG_THRESHOLD && Math.abs(screenDeltaY) <= DRAG_THRESHOLD;

    if (wasClick) {
      selectNode(node.id);
    } else {
      const canvasDeltaX = screenDeltaX / scale;
      const canvasDeltaY = screenDeltaY / scale;
      const newX = dragStartRef.current.nodeX + canvasDeltaX;
      const newY = dragStartRef.current.nodeY + canvasDeltaY;
      onDragEnd(node.id, newX, newY);
    }

    setIsDragging(false);
  }, [isDragging, scale, node.id, onDragEnd, selectNode]);

  const handleConnectionPointClick = useCallback(
    (pointId: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (isConnecting && connectingFrom?.nodeId !== node.id) {
        onConnectionEnd(node.id, pointId);
      } else {
        onConnectionStart(node.id, pointId, e);
      }
    },
    [isConnecting, connectingFrom, node.id, onConnectionStart, onConnectionEnd]
  );

  const getAttachmentIcon = (type: string) => {
    switch (type) {
      case "IMAGE": return ImageIcon;
      case "AUDIO": return FileText;
      case "VIDEO": return Video;
      default: return FileText;
    }
  };

  // Check if we have a valid image attachment
  const hasImageAttachment = node.attachments &&
    node.attachments.length > 0 &&
    node.attachments[0].type === "IMAGE" &&
    node.attachments[0].url &&
    !imageError;

  // Check if we have bullets
  const hasBullets = node.bullets && node.bullets.trim().length > 0;
  const bulletLines = hasBullets ? node.bullets!.split('\n').filter(line => line.trim()) : [];

  // Check if this is a complement node
  const isComplementNode = node.type === "COMPLEMENT";

  // Handle image load
  const handleImageLoad = useCallback((e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    setNaturalSize({ width: img.naturalWidth, height: img.naturalHeight });
    setImageLoaded(true);
  }, []);

  // Handle clicking on link icon to open URL
  const handleLinkIconClick = useCallback((e: React.MouseEvent, url: string) => {
    e.stopPropagation();
    e.preventDefault();
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  }, []);

  // Render complement node
  if (isComplementNode) {
    // Calculate size based on content
    const hasContent = hasImageAttachment || hasBullets;
    const hasLink1 = node.linkUrl && node.linkUrl.trim().length > 0;
    const hasLink2 = node.linkUrl2 && node.linkUrl2.trim().length > 0;
    const hasAnyLink = hasLink1 || hasLink2;
    
    // Check if bullets only (no image)
    const bulletsOnly = hasBullets && !hasImageAttachment;
    
    // Dynamic width/height
    let nodeWidth = 120;
    let nodeHeight = 80;

    if (hasImageAttachment && imageLoaded) {
      // Scale based on natural size
      const maxSize = 150;
      const minSize = 60;
      let width = naturalSize.width;
      let height = naturalSize.height;

      if (width > maxSize || height > maxSize) {
        const ratio = Math.min(maxSize / width, maxSize / height);
        width = width * ratio;
        height = height * ratio;
      }

      width = Math.max(width, minSize);
      height = Math.max(height, minSize);

      // Add extra height for bullets if present
      if (hasBullets) {
        const bulletHeight = Math.min(bulletLines.length * 18 + 16, 100);
        height += bulletHeight;
        width = Math.max(width, 120);
      }

      nodeWidth = width;
      nodeHeight = height;
    } else if (hasBullets) {
      // Only bullets - compact width for highlights
      nodeWidth = Math.min(160, Math.max(80, Math.max(...bulletLines.map(l => l.length * 7 + 16))));
      nodeHeight = Math.min(bulletLines.length * 28 + (hasAnyLink ? 32 : 8), 200);
    }
    
    // Add extra height for link icons
    if (hasAnyLink) {
      nodeHeight += 24 * (hasLink1 && hasLink2 ? 2 : 1);
    }

    const nodeStyle: React.CSSProperties = {
      position: "absolute",
      left: node.positionX,
      top: node.positionY,
      width: nodeWidth,
      height: nodeHeight,
      background: "transparent",
      zIndex: isDragging ? 100 : undefined,
      cursor: "grab",
    };

    return (
      <motion.div
        data-node-id={node.id}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2 }}
        style={nodeStyle}
        className={cn(
          "transition-shadow select-none",
          isSelected && "ring-2 ring-offset-2 ring-emerald-400 rounded-lg",
          isDragging && "shadow-2xl"
        )}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={(e) => {
          if (isDragging) handleMouseUp(e);
          hoverNode(null);
        }}
        onMouseEnter={() => hoverNode(node.id)}
      >
        {/* Content container */}
        <div className="w-full h-full flex flex-col">
          {/* Image */}
          {hasImageAttachment && (
            <img
              src={node.attachments![0].url}
              alt={node.attachments![0].name}
              className={cn(
                "w-full object-contain rounded-lg",
                hasBullets || hasAnyLink ? "flex-shrink-0" : "h-full",
                !imageLoaded && "opacity-0"
              )}
              style={{ maxHeight: hasBullets || hasAnyLink ? '60%' : '100%' }}
              onError={() => setImageError(true)}
              onLoad={handleImageLoad}
              draggable={false}
            />
          )}

          {/* Link icons - between image and text */}
          {(hasLink1 || hasLink2) && (
            <div className="flex justify-center gap-2 py-1">
              {hasLink1 && (
                <button
                  onClick={(e) => handleLinkIconClick(e, node.linkUrl!)}
                  className="w-6 h-6 rounded-full bg-white shadow-md flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all cursor-pointer"
                  title="Abrir enlace 1"
                >
                  {node.linkType === "VIDEO" ? (
                    <Video className="w-3.5 h-3.5 text-red-500" />
                  ) : (
                    <Link2 className="w-3.5 h-3.5 text-blue-500" />
                  )}
                </button>
              )}
              {hasLink2 && (
                <button
                  onClick={(e) => handleLinkIconClick(e, node.linkUrl2!)}
                  className="w-6 h-6 rounded-full bg-white shadow-md flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all cursor-pointer"
                  title="Abrir enlace 2"
                >
                  {node.linkType2 === "VIDEO" ? (
                    <Video className="w-3.5 h-3.5 text-red-500" />
                  ) : (
                    <Link2 className="w-3.5 h-3.5 text-blue-500" />
                  )}
                </button>
              )}
            </div>
          )}

          {/* Bullets - with highlight style when no image */}
          {hasBullets && (
            <div className={cn(
              "flex-1 overflow-hidden",
              bulletsOnly ? "flex flex-col gap-1" : "px-2 py-1"
            )}>
              {bulletsOnly ? (
                // Highlight style for bullets-only
                bulletLines.slice(0, 6).map((line, i) => (
                  <div
                    key={i}
                    className="px-2 py-1 bg-yellow-200/90 rounded text-xs text-gray-800 font-medium truncate shadow-sm"
                  >
                    {line}
                  </div>
                ))
              ) : (
                // Regular bullet list when there's an image
                <ul className="text-xs text-gray-700 space-y-0.5">
                  {bulletLines.slice(0, 5).map((line, i) => (
                    <li key={i} className="flex items-start gap-1 truncate">
                      <span className="text-emerald-500 mt-0.5">•</span>
                      <span className="truncate">{line}</span>
                    </li>
                  ))}
                  {bulletLines.length > 5 && (
                    <li className="text-gray-400 text-[10px]">+{bulletLines.length - 5} más...</li>
                  )}
                </ul>
              )}
            </div>
          )}

          {/* No content placeholder */}
          {!hasContent && (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <ImageIcon className="w-6 h-6" />
            </div>
          )}
        </div>

        {/* Connection Points */}
        {((isHovered || isConnecting) && !isDragging) && (
          <>
            {connectionPoints.map((point) => {
              const isTargetMode = isConnecting && connectingFrom?.nodeId !== node.id;

              const pointStyle: React.CSSProperties = {
                position: "absolute",
                width: "12px",
                height: "12px",
                borderRadius: "50%",
                border: "2px solid white",
                background: isTargetMode ? "#3b82f6" : "#9ca3af",
                boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                zIndex: 10,
                cursor: "pointer",
                opacity: isConnecting && !isTargetMode ? 0.3 : 1,
              };

              switch (point.id) {
                case "TOP":
                  Object.assign(pointStyle, { top: -6, left: "50%", transform: "translateX(-50%)" });
                  break;
                case "RIGHT":
                  Object.assign(pointStyle, { right: -6, top: "50%", transform: "translateY(-50%)" });
                  break;
                case "BOTTOM":
                  Object.assign(pointStyle, { bottom: -6, left: "50%", transform: "translateX(-50%)" });
                  break;
                case "LEFT":
                  Object.assign(pointStyle, { left: -6, top: "50%", transform: "translateY(-50%)" });
                  break;
              }

              return (
                <div
                  key={point.id}
                  style={pointStyle}
                  className="connection-point hover:scale-125 hover:bg-blue-500 transition-all"
                  onMouseDown={(e) => e.stopPropagation()}
                  onClick={(e) => handleConnectionPointClick(point.id, e)}
                />
              );
            })}
          </>
        )}
      </motion.div>
    );
  }

  // Render main node (with rectangle)
  const nodeStyle: React.CSSProperties = {
    position: "absolute",
    left: node.positionX,
    top: node.positionY,
    width: node.width,
    height: node.height,
    background: node.color || "#ffffff",
    zIndex: isDragging ? 100 : undefined,
    cursor: isDragging ? "grabbing" : "grab",
  };

  return (
    <motion.div
      data-node-id={node.id}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.2 }}
      style={nodeStyle}
      className={cn(
        "rounded-xl transition-shadow select-none",
        "border-2 border-gray-200",
        isSelected && "border-gray-400 shadow-lg",
        isDragging && "shadow-2xl"
      )}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={(e) => {
        if (isDragging) handleMouseUp(e);
        hoverNode(null);
      }}
      onMouseEnter={() => hoverNode(node.id)}
    >
      {/* Main Node Content */}
      <div className="h-full rounded-xl overflow-hidden flex flex-col">
        {/* Image Preview */}
        {hasImageAttachment && (
          <div className="w-full h-20 flex-shrink-0 bg-gray-100 overflow-hidden">
            <img
              src={node.attachments![0].url}
              alt={node.attachments![0].name}
              className="w-full h-full object-cover"
              onError={() => setImageError(true)}
            />
          </div>
        )}

        {/* Title and Description */}
        <div className={cn(
          "flex flex-col",
          hasImageAttachment ? "p-2 flex-shrink-0" : "p-3 flex-1"
        )}>
          <div className="flex items-start gap-1">
            <h3 className={cn(
              "font-semibold text-gray-900 leading-tight flex-1",
              hasImageAttachment ? "text-xs" : "text-sm"
            )}>
              {node.title}
            </h3>
            {node.attachments && node.attachments.length > 0 && (
              <div className="flex gap-0.5 flex-shrink-0">
                {node.attachments.slice(0, 2).map((att, i) => {
                  if (att.type === "IMAGE" && att.url) return null;
                  const Icon = getAttachmentIcon(att.type);
                  return <Icon key={i} className="w-3 h-3 text-gray-400" />;
                })}
              </div>
            )}
          </div>

          {!hasImageAttachment && node.description && (
            <p className="mt-1 text-xs text-gray-600 line-clamp-2 flex-1">
              {node.description}
            </p>
          )}
        </div>
      </div>

      {/* Connection Points */}
      {((isHovered || isConnecting) && !isDragging) && (
        <>
          {connectionPoints.map((point) => {
            const isTargetMode = isConnecting && connectingFrom?.nodeId !== node.id;

            const pointStyle: React.CSSProperties = {
              position: "absolute",
              width: "14px",
              height: "14px",
              borderRadius: "50%",
              border: "2px solid white",
              background: isTargetMode ? "#3b82f6" : "#9ca3af",
              boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
              zIndex: 10,
              cursor: "pointer",
              opacity: isConnecting && !isTargetMode ? 0.3 : 1,
            };

            switch (point.id) {
              case "TOP":
                Object.assign(pointStyle, { top: -7, left: "50%", transform: "translateX(-50%)" });
                break;
              case "RIGHT":
                Object.assign(pointStyle, { right: -7, top: "50%", transform: "translateY(-50%)" });
                break;
              case "BOTTOM":
                Object.assign(pointStyle, { bottom: -7, left: "50%", transform: "translateX(-50%)" });
                break;
              case "LEFT":
                Object.assign(pointStyle, { left: -7, top: "50%", transform: "translateY(-50%)" });
                break;
            }

            return (
              <div
                key={point.id}
                style={pointStyle}
                className="connection-point hover:scale-125 hover:bg-blue-500 transition-all"
                onMouseDown={(e) => e.stopPropagation()}
                onClick={(e) => handleConnectionPointClick(point.id, e)}
              />
            );
          })}
        </>
      )}
    </motion.div>
  );
});
