"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCanvasStore } from "@/store/canvas-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  X,
  Trash2,
  Palette,
  FileText,
  Image as ImageIcon,
  Plus,
  Music,
  Video,
  Link2,
  XCircle,
  Loader2,
  ExternalLink,
  Upload,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface AttachmentData {
  id: string;
  name: string;
  type: "IMAGE" | "AUDIO" | "VIDEO" | "DOCUMENT" | "LINK";
  url: string;
  thumbnail?: string;
  description?: string;
}

interface NodePanelProps {
  onUpdateNode: (nodeId: string, data: Record<string, unknown>) => void;
  onDeleteNode: (nodeId: string) => void;
  onAddComplement: (mainNodeId: string, type: "IMAGE" | "AUDIO" | "VIDEO" | "LINK", data?: { url?: string; title?: string; imageFile?: File; bullets?: string; linkType2?: "URL" | "VIDEO"; linkUrl2?: string }) => void;
  onUploadAttachment: (nodeId: string, file: File) => Promise<AttachmentData | null>;
  onRemoveAttachment: (nodeId: string, attachmentId: string) => Promise<void>;
}

const colorOptions = [
  { value: "#ffffff", label: "Blanco" },
  { value: "#fef3c7", label: "Amarillo" },
  { value: "#dbeafe", label: "Azul" },
  { value: "#dcfce7", label: "Verde" },
  { value: "#fce7f3", label: "Rosa" },
  { value: "#f3e8ff", label: "Violeta" },
  { value: "#fed7aa", label: "Naranja" },
  { value: "#e5e7eb", label: "Gris" },
];

const linkTypeOptions = [
  { value: "URL", label: "Enlace Web", icon: Link2 },
  { value: "VIDEO", label: "Video", icon: Video },
];

function NodePanelContent({
  nodeId,
  onUpdateNode,
  onDeleteNode,
  onAddComplement,
  onUploadAttachment,
  onRemoveAttachment
}: {
  nodeId: string;
  onUpdateNode: (nodeId: string, data: Record<string, unknown>) => void;
  onDeleteNode: (nodeId: string) => void;
  onAddComplement: (mainNodeId: string, type: "IMAGE" | "AUDIO" | "VIDEO" | "LINK", data?: { url?: string; title?: string; imageFile?: File; bullets?: string; linkType2?: "URL" | "VIDEO"; linkUrl2?: string }) => void;
  onUploadAttachment: (nodeId: string, file: File) => Promise<AttachmentData | null>;
  onRemoveAttachment: (nodeId: string, attachmentId: string) => Promise<void>;
}) {
  const { currentMap, selectNode } = useCanvasStore();
  const selectedNode = currentMap?.nodes.find((n) => n.id === nodeId);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const complementFileInputRef = useRef<HTMLInputElement>(null);

  const [showComplementDialog, setShowComplementDialog] = useState(false);
  const [complementLinkType, setComplementLinkType] = useState<"URL" | "VIDEO">("URL");
  const [complementLinkUrl, setComplementLinkUrl] = useState("");
  const [complementLinkType2, setComplementLinkType2] = useState<"URL" | "VIDEO">("URL");
  const [complementLinkUrl2, setComplementLinkUrl2] = useState("");
  const [complementBullets, setComplementBullets] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  // State for new complement image
  const [newComplementImage, setNewComplementImage] = useState<File | null>(null);
  const [newComplementImagePreview, setNewComplementImagePreview] = useState<string | null>(null);

  if (!selectedNode) return null;

  const handleClose = () => {
    selectNode(null);
  };

  const handleDelete = () => {
    if (confirm("¿Estás seguro de eliminar este nodo?")) {
      onDeleteNode(nodeId);
    }
  };

  // Handle file selection - upload to server
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    try {
      const attachment = await onUploadAttachment(nodeId, file);
      if (attachment) {
        toast({
          title: "Archivo adjuntado",
          description: `${file.name} se ha adjuntado al nodo`
        });
      }
    } catch (error) {
      console.error("Error uploading file:", error);
      toast({
        title: "Error",
        description: "No se pudo subir el archivo",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  // Handle complement image selection (preview only)
  const handleComplementImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast({
        title: "Error",
        description: "Por favor selecciona un archivo de imagen",
        variant: "destructive"
      });
      return;
    }

    setNewComplementImage(file);

    const reader = new FileReader();
    reader.onload = (event) => {
      setNewComplementImagePreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Handle complement image upload
  const handleComplementImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    try {
      const attachment = await onUploadAttachment(nodeId, file);
      if (attachment) {
        toast({
          title: "Imagen actualizada",
          description: "La imagen del complemento ha sido actualizada"
        });
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      toast({
        title: "Error",
        description: "No se pudo subir la imagen",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
      if (complementFileInputRef.current) {
        complementFileInputRef.current.value = "";
      }
    }
  };

  // Remove attachment
  const handleRemoveAttachment = async (attachmentId: string) => {
    try {
      await onRemoveAttachment(nodeId, attachmentId);
      toast({ title: "Adjunto eliminado" });
    } catch (error) {
      console.error("Error removing attachment:", error);
      toast({
        title: "Error",
        description: "No se pudo eliminar el adjunto",
        variant: "destructive"
      });
    }
  };

  // Handle complement addition with image and/or bullets
  const handleAddComplement = async () => {
    if (!newComplementImage && !complementBullets.trim()) {
      toast({
        title: "Error",
        description: "Debes agregar una imagen o texto en viñetas",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);

    try {
      onAddComplement(nodeId, complementLinkType, {
        url: complementLinkUrl,
        imageFile: newComplementImage || undefined,
        bullets: complementBullets.trim() || undefined,
        linkType2: complementLinkType2,
        linkUrl2: complementLinkUrl2,
      });

      // Reset and close
      setNewComplementImage(null);
      setNewComplementImagePreview(null);
      setComplementLinkUrl("");
      setComplementLinkUrl2("");
      setComplementBullets("");
      setShowComplementDialog(false);

    } catch (error) {
      console.error("Error adding complement:", error);
      toast({
        title: "Error",
        description: "No se pudo crear el complemento",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const getAttachmentIcon = (type: string) => {
    switch (type) {
      case "IMAGE": return ImageIcon;
      case "AUDIO": return Music;
      case "VIDEO": return Video;
      default: return FileText;
    }
  };

  // Check if this is a complement node
  const isComplementNode = selectedNode.type === "COMPLEMENT";

  // Render complement node panel
  if (isComplementNode) {
    const hasImage = selectedNode.attachments && selectedNode.attachments.length > 0 && selectedNode.attachments[0].url;
    const hasBullets = selectedNode.bullets && selectedNode.bullets.trim().length > 0;

    return (
      <motion.div
        initial={{ x: 320, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 320, opacity: 0 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        className="absolute right-0 top-0 bottom-0 w-80 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 shadow-xl z-50"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white">
              Editar Complemento
            </h3>
            <Button variant="ghost" size="icon" onClick={handleClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Scrollable Content */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {/* Image Section */}
              <div className="space-y-2">
                <Label>Imagen</Label>
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden border-2 border-dashed border-gray-300">
                  {hasImage ? (
                    <div className="relative w-full h-full">
                      <img
                        src={selectedNode.attachments![0].url}
                        alt={selectedNode.attachments![0].name}
                        className="w-full h-full object-contain"
                      />
                      <button
                        onClick={() => handleRemoveAttachment(selectedNode.attachments![0].id)}
                        className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400">
                      <ImageIcon className="w-8 h-8 mb-1" />
                      <span className="text-xs">Sin imagen</span>
                    </div>
                  )}
                </div>

                <input
                  ref={complementFileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleComplementImageUpload}
                  disabled={isUploading}
                />

                <Button
                  variant="outline"
                  className="w-full"
                  size="sm"
                  disabled={isUploading}
                  onClick={() => complementFileInputRef.current?.click()}
                >
                  {isUploading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4 mr-2" />
                  )}
                  {hasImage ? "Cambiar" : "Subir"}
                </Button>
              </div>

              {/* Bullets Section */}
              <div className="space-y-2">
                <Label htmlFor="bullets">Texto en viñetas</Label>
                <Textarea
                  id="bullets"
                  placeholder="Escribe cada punto en una línea nueva..."
                  value={selectedNode.bullets || ""}
                  onChange={(e) => onUpdateNode(nodeId, { bullets: e.target.value })}
                  rows={4}
                  className="text-sm"
                />
                <p className="text-xs text-gray-500">
                  Cada línea será una viñeta
                </p>
              </div>

              <Separator />

              {/* Link 1 */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  Enlace 1
                </Label>
                <Select
                  value={selectedNode.linkType || "URL"}
                  onValueChange={(v) => onUpdateNode(nodeId, { linkType: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {linkTypeOptions.map((type) => {
                      const Icon = type.icon;
                      return (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4" />
                            {type.label}
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Input
                    placeholder="https://ejemplo.com"
                    value={selectedNode.linkUrl || ""}
                    onChange={(e) => onUpdateNode(nodeId, { linkUrl: e.target.value })}
                  />
                  {selectedNode.linkUrl && (
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => window.open(selectedNode.linkUrl, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>

              {/* Link 2 */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  Enlace 2 (opcional)
                </Label>
                <Select
                  value={selectedNode.linkType2 || "URL"}
                  onValueChange={(v) => onUpdateNode(nodeId, { linkType2: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {linkTypeOptions.map((type) => {
                      const Icon = type.icon;
                      return (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4" />
                            {type.label}
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Input
                    placeholder="https://ejemplo.com"
                    value={selectedNode.linkUrl2 || ""}
                    onChange={(e) => onUpdateNode(nodeId, { linkUrl2: e.target.value })}
                  />
                  {selectedNode.linkUrl2 && (
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => window.open(selectedNode.linkUrl2, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </ScrollArea>

          {/* Footer - Delete button */}
          <div className="px-4 pt-2 pb-4">
            <Button
              variant="destructive"
              className="w-full"
              onClick={handleDelete}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Eliminar Complemento
            </Button>
          </div>
        </div>
      </motion.div>
    );
  }

  // Render main node panel (original UI)
  return (
    <>
      <motion.div
        initial={{ x: 320, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 320, opacity: 0 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        className="absolute right-0 top-0 bottom-0 w-80 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 shadow-xl z-50"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white">
              Editar Nodo
            </h3>
            <Button variant="ghost" size="icon" onClick={handleClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Scrollable Content */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-3">
              {/* Title */}
              <div className="space-y-2">
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  defaultValue={selectedNode.title}
                  onChange={(e) => onUpdateNode(nodeId, { title: e.target.value })}
                  placeholder="Título del nodo"
                />
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  defaultValue={selectedNode.description}
                  onChange={(e) => onUpdateNode(nodeId, { description: e.target.value })}
                  placeholder="Descripción detallada..."
                  rows={4}
                />
              </div>

              {/* Color */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Color
                </Label>
                <div className="flex flex-wrap gap-1.5">
                  {colorOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => onUpdateNode(nodeId, { color: opt.value })}
                      className={`w-7 h-7 rounded-md border-2 transition-all ${
                        selectedNode.color === opt.value
                          ? "border-emerald-500 scale-110"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      style={{ backgroundColor: opt.value }}
                      title={opt.label}
                    />
                  ))}
                </div>
              </div>

              <Separator />

              {/* Position Info */}
              <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                <p>Posición: ({Math.round(selectedNode.positionX)}, {Math.round(selectedNode.positionY)})</p>
                <p>Tamaño: {selectedNode.width} × {selectedNode.height}</p>
              </div>

              {/* Attachments List */}
              {selectedNode.attachments && selectedNode.attachments.length > 0 && (
                <div className="space-y-2">
                  <Label>Adjuntos</Label>
                  {selectedNode.attachments.map((att) => {
                    const Icon = getAttachmentIcon(att.type);
                    return (
                      <div
                        key={att.id}
                        className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-gray-700 rounded-lg group"
                      >
                        {att.type === "IMAGE" && att.url ? (
                          <img src={att.url} alt={att.name} className="w-8 h-8 rounded object-cover" />
                        ) : (
                          <Icon className="w-4 h-4 text-gray-400" />
                        )}
                        <span className="text-sm truncate flex-1">{att.name}</span>
                        <button
                          onClick={() => handleRemoveAttachment(att.id)}
                          className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 transition-all"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Complements List */}
              {selectedNode.complements && selectedNode.complements.length > 0 && (
                <div className="space-y-2">
                  <Label>Complementos</Label>
                  {selectedNode.complements.map((comp) => {
                    const Icon = comp.linkType === "VIDEO" ? Video : Link2;
                    const hasImage = comp.attachments && comp.attachments.length > 0;
                    const hasBullets = comp.bullets && comp.bullets.trim().length > 0;
                    
                    return (
                      <div
                        key={comp.id}
                        className="flex items-center gap-2 p-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg cursor-pointer hover:bg-emerald-100 dark:hover:bg-emerald-900/30"
                        onClick={() => selectNode(comp.id)}
                      >
                        {hasImage && comp.attachments![0].url ? (
                          <img src={comp.attachments![0].url} alt={comp.title} className="w-8 h-8 rounded object-cover" />
                        ) : hasBullets ? (
                          <FileText className="w-4 h-4 text-emerald-500" />
                        ) : (
                          <ImageIcon className="w-4 h-4 text-emerald-500" />
                        )}
                        <span className="text-sm truncate flex-1">
                          {hasBullets ? comp.bullets?.split('\n')[0]?.substring(0, 20) + (comp.bullets!.length > 20 ? '...' : '') : comp.title}
                        </span>
                        {comp.linkUrl && <Icon className="w-4 h-4 text-emerald-500" />}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Quick Actions */}
          <div className="px-4 pt-3 pb-2 border-t border-gray-200 dark:border-gray-700">
            <div className="flex gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,audio/*,video/*,.pdf,.doc,.docx,.txt"
                className="hidden"
                onChange={handleFileSelect}
                disabled={isUploading}
              />
              <Button
                variant="outline"
                className="flex-1"
                size="sm"
                disabled={isUploading}
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
              >
                {isUploading ? (
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                ) : (
                  <FileText className="w-4 h-4 mr-1.5" />
                )}
                Archivo
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowComplementDialog(true);
                }}
              >
                <Plus className="w-4 h-4 mr-1.5" />
                Complemento
              </Button>
            </div>
          </div>

          {/* Footer - Delete button */}
          <div className="px-4 pt-2 pb-4">
            <Button
              variant="destructive"
              className="w-full"
              onClick={handleDelete}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Eliminar Nodo
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Complement Dialog */}
      <Dialog open={showComplementDialog} onOpenChange={(open) => {
        setShowComplementDialog(open);
        if (!open) {
          setNewComplementImage(null);
          setNewComplementImagePreview(null);
          setComplementLinkUrl("");
          setComplementLinkUrl2("");
          setComplementBullets("");
        }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Agregar Complemento</DialogTitle>
            <DialogDescription>
              Agrega una imagen y/o texto en viñetas. Puedes agregar hasta 2 enlaces.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* Image Upload */}
            <div className="space-y-2">
              <Label>Imagen (opcional)</Label>
              {newComplementImagePreview ? (
                <div className="relative">
                  <img
                    src={newComplementImagePreview}
                    alt="Preview"
                    className="w-full h-24 object-contain rounded-lg border"
                  />
                  <button
                    onClick={() => {
                      setNewComplementImage(null);
                      setNewComplementImagePreview(null);
                    }}
                    className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex items-center justify-center gap-2 h-10 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-200 transition-colors">
                  <Upload className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">Subir imagen</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleComplementImageSelect}
                  />
                </label>
              )}
            </div>

            {/* Bullets */}
            <div className="space-y-2">
              <Label htmlFor="comp-bullets">Texto en viñetas (opcional)</Label>
              <Textarea
                id="comp-bullets"
                placeholder="Escribe cada punto en una línea nueva..."
                value={complementBullets}
                onChange={(e) => setComplementBullets(e.target.value)}
                rows={3}
              />
              <p className="text-xs text-gray-500">
                Cada línea será una viñeta
              </p>
            </div>

            <Separator />

            {/* Link 1 */}
            <div className="space-y-2">
              <Label>Enlace 1</Label>
              <Select value={complementLinkType} onValueChange={(v) => setComplementLinkType(v as "URL" | "VIDEO")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {linkTypeOptions.map((type) => {
                    const Icon = type.icon;
                    return (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" />
                          {type.label}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              <Input
                placeholder="https://ejemplo.com"
                value={complementLinkUrl}
                onChange={(e) => setComplementLinkUrl(e.target.value)}
              />
            </div>

            {/* Link 2 */}
            <div className="space-y-2">
              <Label>Enlace 2 (opcional)</Label>
              <Select value={complementLinkType2} onValueChange={(v) => setComplementLinkType2(v as "URL" | "VIDEO")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {linkTypeOptions.map((type) => {
                    const Icon = type.icon;
                    return (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" />
                          {type.label}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              <Input
                placeholder="https://ejemplo.com"
                value={complementLinkUrl2}
                onChange={(e) => setComplementLinkUrl2(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => {
              setShowComplementDialog(false);
              setNewComplementImage(null);
              setNewComplementImagePreview(null);
              setComplementLinkUrl("");
              setComplementLinkUrl2("");
              setComplementBullets("");
            }}>
              Cancelar
            </Button>
            <Button
              onClick={handleAddComplement}
              disabled={isUploading || (!newComplementImage && !complementBullets.trim())}
              className="bg-emerald-500 hover:bg-emerald-600"
            >
              {isUploading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : null}
              Agregar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function NodePanel({ onUpdateNode, onDeleteNode, onAddComplement, onUploadAttachment, onRemoveAttachment }: NodePanelProps) {
  const { selectedNodeId, showNodePanel } = useCanvasStore();

  return (
    <AnimatePresence mode="wait">
      {showNodePanel && selectedNodeId && (
        <NodePanelContent
          key={selectedNodeId}
          nodeId={selectedNodeId}
          onUpdateNode={onUpdateNode}
          onDeleteNode={onDeleteNode}
          onAddComplement={onAddComplement}
          onUploadAttachment={onUploadAttachment}
          onRemoveAttachment={onRemoveAttachment}
        />
      )}
    </AnimatePresence>
  );
}
