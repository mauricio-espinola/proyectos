"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useCanvasStore, MapData } from "@/store/canvas-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  X, 
  Plus, 
  Map,
  Trash2,
  FileText
} from "lucide-react";
import { useState } from "react";

interface MapListPanelProps {
  maps: MapData[];
  onCreateMap: (title: string) => void;
  onSelectMap: (mapId: string) => void;
  onDeleteMap: (mapId: string) => void;
  isLoading: boolean;
}

export function MapListPanel({
  maps,
  onCreateMap,
  onSelectMap,
  onDeleteMap,
  isLoading,
}: MapListPanelProps) {
  const { showMapList, toggleMapList, currentMap } = useCanvasStore();
  const [newMapTitle, setNewMapTitle] = useState("");

  const handleCreateMap = () => {
    if (newMapTitle.trim()) {
      onCreateMap(newMapTitle.trim());
      setNewMapTitle("");
    }
  };

  return (
    <AnimatePresence>
      {showMapList && (
        <motion.div
          initial={{ x: -320, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -320, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="absolute left-0 top-0 bottom-0 w-80 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 shadow-xl z-20"
        >
          <div className="flex flex-col h-full">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                <Map className="w-5 h-5" />
                Mis Mapas
              </h3>
              <Button variant="ghost" size="icon" onClick={toggleMapList}>
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* Create New Map */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <div className="flex gap-2">
                <Input
                  placeholder="Nuevo mapa..."
                  value={newMapTitle}
                  onChange={(e) => setNewMapTitle(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleCreateMap()}
                />
                <Button
                  onClick={handleCreateMap}
                  disabled={!newMapTitle.trim() || isLoading}
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Map List */}
            <ScrollArea className="flex-1">
              <div className="p-2 space-y-2">
                {maps.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No tienes mapas creados</p>
                    <p className="text-xs mt-1">Crea uno para comenzar</p>
                  </div>
                ) : (
                  maps.map((map) => (
                    <motion.div
                      key={map.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => onSelectMap(map.id)}
                      className={`w-full text-left p-3 rounded-lg transition-all cursor-pointer group ${
                        currentMap?.id === map.id
                          ? "bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 border border-emerald-200 dark:border-emerald-800"
                          : "bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700"
                      }`}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          onSelectMap(map.id);
                        }
                      }}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 dark:text-white truncate">
                            {map.title}
                          </h4>
                          {map.description && (
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                              {map.description}
                            </p>
                          )}
                          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                            <span>{map.nodes?.length || 0} nodos</span>
                            <span>{map.connections?.length || 0} conexiones</span>
                          </div>
                        </div>
                        <button
                          type="button"
                          className="h-8 w-8 flex items-center justify-center rounded-md hover:bg-red-100 dark:hover:bg-red-900/30 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm("¿Eliminar este mapa?")) {
                              onDeleteMap(map.id);
                            }
                          }}
                          title="Eliminar mapa"
                        >
                          <Trash2 className="w-4 h-4 text-gray-400 hover:text-red-500" />
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
