"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useCanvasStore } from "@/store/canvas-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  X, 
  Trash2, 
  Palette,
  ArrowRight
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ConnectionPanelProps {
  onUpdateConnection: (connectionId: string, data: Record<string, unknown>) => void;
  onDeleteConnection: (connectionId: string) => void;
}

const colorOptions = [
  { value: "#6B7280", label: "Gris" },
  { value: "#EF4444", label: "Rojo" },
  { value: "#F59E0B", label: "Naranja" },
  { value: "#10B981", label: "Verde" },
  { value: "#3B82F6", label: "Azul" },
  { value: "#8B5CF6", label: "Violeta" },
  { value: "#EC4899", label: "Rosa" },
  { value: "#6366F1", label: "Índigo" },
];

const lineStyles = [
  { value: "solid", label: "Sólida" },
  { value: "dashed", label: "Discontinua" },
  { value: "dotted", label: "Punteada" },
];

const connectionPoints = [
  { value: "TOP", label: "Arriba" },
  { value: "RIGHT", label: "Derecha" },
  { value: "BOTTOM", label: "Abajo" },
  { value: "LEFT", label: "Izquierda" },
  { value: "CENTER", label: "Centro" },
];

function ConnectionPanelContent({
  connectionId,
  onUpdateConnection,
  onDeleteConnection,
}: {
  connectionId: string;
  onUpdateConnection: (connectionId: string, data: Record<string, unknown>) => void;
  onDeleteConnection: (connectionId: string) => void;
}) {
  const { currentMap, selectConnection } = useCanvasStore();
  const selectedConnection = currentMap?.connections.find((c) => c.id === connectionId);

  if (!selectedConnection) return null;

  const handleClose = () => {
    selectConnection(null);
  };

  const handleDelete = () => {
    if (confirm("¿Estás seguro de eliminar esta conexión?")) {
      onDeleteConnection(connectionId);
    }
  };

  const sourceNode = currentMap?.nodes.find((n) => n.id === selectedConnection.sourceNodeId);
  const targetNode = currentMap?.nodes.find((n) => n.id === selectedConnection.targetNodeId);

  return (
    <motion.div
      initial={{ x: 320, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 320, opacity: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="absolute right-0 top-0 bottom-0 w-80 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 shadow-xl z-50"
      onClick={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white">
            Editar Conexión
          </h3>
          <Button variant="ghost" size="icon" onClick={handleClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          {/* Connection Info */}
          <div className="flex items-center gap-2 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <span className="text-sm font-medium truncate">{sourceNode?.title}</span>
            <ArrowRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
            <span className="text-sm font-medium truncate">{targetNode?.title}</span>
          </div>

          {/* Label */}
          <div className="space-y-2">
            <Label htmlFor="label">Etiqueta de relación</Label>
            <Input
              id="label"
              defaultValue={selectedConnection.label}
              onChange={(e) => onUpdateConnection(connectionId, { label: e.target.value })}
              placeholder="ej: depende de, causa, requiere..."
            />
          </div>

          {/* Color */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Palette className="w-4 h-4" />
              Color
            </Label>
            <div className="flex flex-wrap gap-1.5">
              {colorOptions.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => onUpdateConnection(connectionId, { color: opt.value })}
                  className={`w-7 h-7 rounded-md border-2 transition-all ${
                    selectedConnection.color === opt.value
                      ? "border-gray-900 dark:border-white scale-110"
                      : "border-transparent hover:border-gray-300"
                  }`}
                  style={{ backgroundColor: opt.value }}
                  title={opt.label}
                />
              ))}
            </div>
          </div>

          {/* Line Style */}
          <div className="space-y-2">
            <Label>Estilo de línea</Label>
            <Select
              defaultValue={selectedConnection.lineStyle}
              onValueChange={(v) => onUpdateConnection(connectionId, { lineStyle: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {lineStyles.map((style) => (
                  <SelectItem key={style.value} value={style.value}>
                    {style.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Connection Points */}
          <div className="space-y-3">
            <Label>Puntos de conexión</Label>
            
            <div className="space-y-2">
              <Label className="text-xs text-gray-500">Origen</Label>
              <Select
                defaultValue={selectedConnection.sourcePoint}
                onValueChange={(v) => onUpdateConnection(connectionId, { sourcePoint: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {connectionPoints.map((point) => (
                    <SelectItem key={point.value} value={point.value}>
                      {point.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-gray-500">Destino</Label>
              <Select
                defaultValue={selectedConnection.targetPoint}
                onValueChange={(v) => onUpdateConnection(connectionId, { targetPoint: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {connectionPoints.map((point) => (
                    <SelectItem key={point.value} value={point.value}>
                      {point.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <Button
            variant="destructive"
            className="w-full"
            onClick={handleDelete}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Eliminar Conexión
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

export function ConnectionPanel({ onUpdateConnection, onDeleteConnection }: ConnectionPanelProps) {
  const { selectedConnectionId, showConnectionPanel } = useCanvasStore();

  return (
    <AnimatePresence mode="wait">
      {showConnectionPanel && selectedConnectionId && (
        <ConnectionPanelContent
          key={selectedConnectionId}
          connectionId={selectedConnectionId}
          onUpdateConnection={onUpdateConnection}
          onDeleteConnection={onDeleteConnection}
        />
      )}
    </AnimatePresence>
  );
}
