// Tipos para el laberinto y algoritmo A*

// Tipos de heurística disponibles
export type HeuristicType = 'manhattan' | 'chebyshev' | 'double-chebyshev' | 'euclidean';

// Costos de movimiento configurables
export interface MovementCosts {
  vertical: number;    // Arriba/Abajo
  horizontal: number;  // Izquierda/Derecha
}

export interface Position {
  row: number; // Fila (F1-F6 se almacenan como índices 0-5)
  col: number; // Columna (C1-C6 se almacenan como índices 0-5)
}

export interface MazeCell {
  position: Position;
  isObstacle: boolean;
  isStart: boolean;
  isDestination: boolean; // Puede haber múltiples destinos
  heuristic: number;
}

export interface AStarNode {
  position: Position;
  g: number; // Costo real desde el inicio
  h: number; // Heurística (doble de Chebyshev)
  f: number; // g + h
  parent: AStarNode | null;
}

// Nodo para mostrar en las listas
export interface OpenSetNode {
  position: Position;
  g: number;
  h: number;
  f: number;
}

// Mapa de costos por posición
export interface CostMap {
  [key: string]: { g: number; f: number };
}

export interface AlgorithmStep {
  type: 'visit' | 'expand' | 'found' | 'complete';
  currentNode: Position;
  openSet: Position[];
  openSetNodes: OpenSetNode[]; // Lista abierta ordenada con todos los datos
  closedSet: Position[];
  closedSetNodes: OpenSetNode[]; // Lista cerrada con todos los datos
  path: Position[];
  description: string;
  explanation: string; // Explicación pedagógica de qué pasó
  g?: number;
  h?: number;
  f?: number;
  costsMap: CostMap; // Mapa de costos para cada celda
}

export type MazeGrid = MazeCell[][];

// Direcciones de movimiento: arriba, derecha, abajo, izquierda
// Función para obtener movimientos con costos configurables
export function getMoves(costs: MovementCosts) {
  return [
    { direction: 'arriba', delta: { row: -1, col: 0 }, cost: costs.vertical },
    { direction: 'derecha', delta: { row: 0, col: 1 }, cost: costs.horizontal },
    { direction: 'abajo', delta: { row: 1, col: 0 }, cost: costs.vertical },
    { direction: 'izquierda', delta: { row: 0, col: -1 }, cost: costs.horizontal },
  ];
}

// Costos por defecto
export const DEFAULT_COSTS: MovementCosts = {
  vertical: 3,
  horizontal: 2,
};

// Configuración del laberinto editable
export interface MazeConfiguration {
  rows: number;
  cols: number;
  start: Position;
  destinations: Position[];
  walkableCells: Position[];
}

// Configuración por defecto del laberinto del problema (Grid 6x6)
// NOTACIÓN: F = Fila (F1-F6), C = Columna (C1-C6) - Base 1
// ÍNDICES: Internamente usamos base 0, así que F2,C3 = {row: 1, col: 2}
export const DEFAULT_MAZE_CONFIG: MazeConfiguration = {
  rows: 6,
  cols: 6,
  // INICIO: F2, C3
  start: { row: 1, col: 2 },  // F2 = índice 1, C3 = índice 2
  // DESTINOS: F5,C2 y F5,C5
  destinations: [
    { row: 4, col: 1 },  // F5,C2: F5 = índice 4, C2 = índice 1
    { row: 4, col: 4 },  // F5,C5: F5 = índice 4, C5 = índice 4
  ],
  // Celdas transitables (BLANCAS) - el resto son obstáculos
  walkableCells: [
    // Fila F2 (índice 1): C3(INICIO), C4, C5
    { row: 1, col: 2 },  // F2,C3 - INICIO
    { row: 1, col: 3 },  // F2,C4
    { row: 1, col: 4 },  // F2,C5
    // Fila F3 (índice 2): C4
    { row: 2, col: 3 },  // F3,C4
    // Fila F4 (índice 3): C4, C5
    { row: 3, col: 3 },  // F4,C4
    { row: 3, col: 4 },  // F4,C5
    // Fila F5 (índice 4): C2(DESTINO), C3, C4, C5(DESTINO)
    { row: 4, col: 1 },  // F5,C2 - DESTINO
    { row: 4, col: 2 },  // F5,C3
    { row: 4, col: 3 },  // F5,C4
    { row: 4, col: 4 },  // F5,C5 - DESTINO
  ],
};

// Alias para compatibilidad
export const MAZE_CONFIG = DEFAULT_MAZE_CONFIG;
