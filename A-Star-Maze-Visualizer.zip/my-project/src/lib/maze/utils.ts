// Utilidades para el laberinto y algoritmo A*
import { 
  Position, 
  MazeCell, 
  MazeGrid, 
  AStarNode, 
  AlgorithmStep,
  OpenSetNode,
  CostMap,
  getMoves,
  MazeConfiguration,
  DEFAULT_MAZE_CONFIG,
  HeuristicType,
  MovementCosts,
  DEFAULT_COSTS
} from './types';

/**
 * Calcula la heurística Manhattan
 * Fórmula: h = |Δf| + |Δc|
 */
export function calculateManhattanDistance(pos1: Position, pos2: Position): number {
  return Math.abs(pos1.row - pos2.row) + Math.abs(pos1.col - pos2.col);
}

/**
 * Calcula la heurística Chebyshev
 * Fórmula: h = max(|Δf|, |Δc|)
 */
export function calculateChebyshevDistance(pos1: Position, pos2: Position): number {
  return Math.max(Math.abs(pos1.row - pos2.row), Math.abs(pos1.col - pos2.col));
}

/**
 * Calcula la heurística Doble Chebyshev
 * Fórmula: h = 2 × max(|Δf|, |Δc|)
 */
export function calculateDoubleChebyshevDistance(pos1: Position, pos2: Position): number {
  return 2 * Math.max(Math.abs(pos1.row - pos2.row), Math.abs(pos1.col - pos2.col));
}

/**
 * Calcula la heurística Euclidiana
 * Fórmula: h = √(Δf² + Δc²)
 * Es la distancia en línea recta exacta entre dos puntos
 */
export function calculateEuclideanDistance(pos1: Position, pos2: Position): number {
  const deltaF = pos1.row - pos2.row;
  const deltaC = pos1.col - pos2.col;
  return Math.sqrt(deltaF * deltaF + deltaC * deltaC);
}

/**
 * Calcula la distancia según el tipo de heurística seleccionado
 */
export function calculateDistance(
  pos1: Position, 
  pos2: Position, 
  heuristicType: HeuristicType
): number {
  switch (heuristicType) {
    case 'manhattan':
      return calculateManhattanDistance(pos1, pos2);
    case 'chebyshev':
      return calculateChebyshevDistance(pos1, pos2);
    case 'euclidean':
      return calculateEuclideanDistance(pos1, pos2);
    case 'double-chebyshev':
    default:
      return calculateDoubleChebyshevDistance(pos1, pos2);
  }
}

/**
 * Calcula la heurística h(n) = mínima distancia entre nodo y las posibles metas
 */
export function calculateHeuristic(
  position: Position, 
  destinations: Position[], 
  heuristicType: HeuristicType = 'double-chebyshev'
): number {
  const distances = destinations.map(dest => calculateDistance(position, dest, heuristicType));
  return Math.min(...distances);
}

/**
 * Crea el laberinto inicial con la configuración del problema
 */
export function createMaze(
  heuristicType: HeuristicType = 'double-chebyshev',
  config: MazeConfiguration = DEFAULT_MAZE_CONFIG
): MazeGrid {
  const { rows, cols, start, destinations, walkableCells } = config;
  const grid: MazeGrid = [];

  for (let row = 0; row < rows; row++) {
    const gridRow: MazeCell[] = [];
    for (let col = 0; col < cols; col++) {
      const position = { row, col };
      
      // Una celda es caminable si está en la lista de walkableCells
      const isWalkable = walkableCells.some(w => w.row === row && w.col === col);
      const isObstacle = !isWalkable;
      const isStart = start.row === row && start.col === col;
      const isDestination = destinations.some(d => d.row === row && d.col === col);
      
      // La heurística no se calcula para obstáculos
      const heuristic = isObstacle ? 0 : calculateHeuristic(position, destinations, heuristicType);

      gridRow.push({
        position,
        isObstacle,
        isStart,
        isDestination,
        heuristic,
      });
    }
    grid.push(gridRow);
  }

  return grid;
}

/**
 * Verifica si una posición está dentro del laberinto
 */
export function isValidPosition(pos: Position, rows: number, cols: number): boolean {
  return pos.row >= 0 && pos.row < rows && pos.col >= 0 && pos.col < cols;
}

/**
 * Compara dos posiciones
 */
export function positionsEqual(pos1: Position, pos2: Position): boolean {
  return pos1.row === pos2.row && pos1.col === pos2.col;
}

/**
 * Convierte posición a string para usar como clave
 */
export function positionToKey(pos: Position): string {
  return `${pos.row},${pos.col}`;
}

/**
 * Formatea posición para mostrar
 */
export function formatPosition(pos: Position): string {
  return `F${pos.row + 1}C${pos.col + 1}`;
}

/**
 * Construye el mapa de costos actual
 */
function buildCostsMap(
  openSet: Map<string, AStarNode>, 
  closedNodes: Map<string, AStarNode>
): CostMap {
  const map: CostMap = {};
  
  // Agregar nodos del open set
  openSet.forEach((node, key) => {
    map[key] = { g: node.g, f: node.f };
  });
  
  // Agregar nodos del closed set
  closedNodes.forEach((node, key) => {
    map[key] = { g: node.g, f: node.f };
  });
  
  return map;
}

/**
 * Obtiene la lista abierta ordenada por f, luego h
 */
function getSortedOpenSetNodes(openSet: Map<string, AStarNode>, cols: number): OpenSetNode[] {
  return Array.from(openSet.values())
    .sort((a, b) => {
      if (a.f !== b.f) return a.f - b.f;
      if (a.h !== b.h) return a.h - b.h;
      return (a.position.row * cols + a.position.col) - (b.position.row * cols + b.position.col);
    })
    .map(node => ({
      position: node.position,
      g: node.g,
      h: node.h,
      f: node.f,
    }));
}

/**
 * Obtiene la lista cerrada ordenada por el más reciente primero
 */
function getClosedSetNodes(closedNodes: Map<string, AStarNode>): OpenSetNode[] {
  return Array.from(closedNodes.values())
    .reverse() // Mostrar primero los más recientes
    .map(node => ({
      position: node.position,
      g: node.g,
      h: node.h,
      f: node.f,
    }));
}

/**
 * Implementación del algoritmo A* con seguimiento de pasos detallado
 */
export function runAStar(
  maze: MazeGrid, 
  heuristicType: HeuristicType = 'double-chebyshev',
  movementCosts: MovementCosts = DEFAULT_COSTS
): AlgorithmStep[] {
  const steps: AlgorithmStep[] = [];
  const rows = maze.length;
  const cols = maze[0].length;
  const MOVES = getMoves(movementCosts);
  
  // Encontrar posición inicial y destinos
  let start: Position | null = null;
  const destinations: Position[] = [];
  
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      if (maze[row][col].isStart) {
        start = { row, col };
      }
      if (maze[row][col].isDestination) {
        destinations.push({ row, col });
      }
    }
  }

  if (!start) {
    return steps;
  }

  // Inicializar conjuntos abierto y cerrado
  const openSet: Map<string, AStarNode> = new Map();
  const closedSet: Set<string> = new Set();
  const closedNodes: Map<string, AStarNode> = new Map(); // Para mantener datos de nodos cerrados

  // Nodo inicial
  const startNode: AStarNode = {
    position: start,
    g: 0,
    h: calculateHeuristic(start, destinations, heuristicType),
    f: calculateHeuristic(start, destinations, heuristicType),
    parent: null,
  };

  openSet.set(positionToKey(start), startNode);

  // Paso inicial
  const startCostsMap: CostMap = {};
  startCostsMap[positionToKey(start)] = { g: 0, f: startNode.f };
  
  steps.push({
    type: 'visit',
    currentNode: start,
    openSet: [start],
    openSetNodes: [{ position: start, g: 0, h: startNode.h, f: startNode.f }],
    closedSet: [],
    closedSetNodes: [],
    path: [],
    costsMap: startCostsMap,
    description: `INICIO del algoritmo A*`,
    explanation: `Se inicia en ${formatPosition(start)} con:\n• g = 0 (costo acumulado = 0)\n• h = ${startNode.h} (heurística = doble Chebyshev)\n• f = g + h = ${startNode.f}\n\nEste nodo se agrega a la LISTA ABIERTA.`,
    g: startNode.g,
    h: startNode.h,
    f: startNode.f,
  });

  while (openSet.size > 0) {
    // Obtener lista abierta ordenada
    const sortedOpenNodes = getSortedOpenSetNodes(openSet, cols);
    
    // Encontrar el nodo con menor f (criterio de desempate: menor h, luego orden de direcciones)
    let currentNode: AStarNode | null = null;
    let currentKey = '';

    const sortedEntries = Array.from(openSet.entries()).sort((a, b) => {
      const nodeA = a[1];
      const nodeB = b[1];
      
      if (nodeA.f !== nodeB.f) return nodeA.f - nodeB.f;
      if (nodeA.h !== nodeB.h) return nodeA.h - nodeB.h;
      return (nodeA.position.row * cols + nodeA.position.col) - (nodeB.position.row * cols + nodeB.position.col);
    });

    if (sortedEntries.length > 0) {
      currentKey = sortedEntries[0][0];
      currentNode = sortedEntries[0][1];
    }

    if (!currentNode) break;

    // Construir explicación de por qué se eligió este nodo
    const openListStr = sortedOpenNodes.slice(0, 5).map((n, i) => 
      `${i === 0 ? '➤' : '  '} ${formatPosition(n.position)}: f=${n.f} (g=${n.g}+h=${n.h})`
    ).join('\n');
    const moreCount = sortedOpenNodes.length > 5 ? `\n   ... y ${sortedOpenNodes.length - 5} más` : '';

    // Mover de abierto a cerrado
    openSet.delete(currentKey);
    closedSet.add(currentKey);
    closedNodes.set(currentKey, currentNode);

    // Verificar si llegamos a un destino
    if (destinations.some(d => positionsEqual(d, currentNode!.position))) {
      // Reconstruir camino
      const path: Position[] = [];
      let node: AStarNode | null = currentNode;
      while (node) {
        path.unshift(node.position);
        node = node.parent;
      }

      const pathStr = path.map(p => formatPosition(p)).join(' → ');

      steps.push({
        type: 'found',
        currentNode: currentNode.position,
        openSet: Array.from(openSet.values()).map(n => n.position),
        openSetNodes: getSortedOpenSetNodes(openSet, cols),
        closedSet: Array.from(closedSet).map(k => {
          const [row, col] = k.split(',').map(Number);
          return { row, col };
        }),
        closedSetNodes: getClosedSetNodes(closedNodes),
        path,
        costsMap: buildCostsMap(openSet, closedNodes),
        description: `¡DESTINO ALCANZADO!`,
        explanation: `¡ÉXITO! Se llegó al destino ${formatPosition(currentNode.position)}\n\n` +
          `COSTO TOTAL: g = ${currentNode.g}\n\n` +
          `CAMINO ÓPTIMO (${path.length} pasos):\n${pathStr}\n\n` +
          `El algoritmo A* encontró el camino de menor costo usando:\n` +
          `• g: costo real acumulado\n` +
          `• h: heurística (estimación)\n` +
          `• f = g + h: función de evaluación`,
        g: currentNode.g,
        h: currentNode.h,
        f: currentNode.f,
      });

      return steps;
    }

    // Expandir vecinos
    const neighbors: { position: Position; cost: number; direction: string }[] = [];
    
    for (const move of MOVES) {
      const newPos = {
        row: currentNode.position.row + move.delta.row,
        col: currentNode.position.col + move.delta.col,
      };

      if (isValidPosition(newPos, rows, cols)) {
        const cell = maze[newPos.row][newPos.col];
        if (!cell.isObstacle) {
          neighbors.push({
            position: newPos,
            cost: move.cost,
            direction: move.direction,
          });
        }
      }
    }

    // Paso de expansión
    const neighborsStr = neighbors.map(n => 
      `${n.direction}: ${formatPosition(n.position)} (costo +${n.cost})`
    ).join('\n   ');
    
    steps.push({
      type: 'expand',
      currentNode: currentNode.position,
      openSet: Array.from(openSet.values()).map(n => n.position),
      openSetNodes: getSortedOpenSetNodes(openSet, cols),
      closedSet: Array.from(closedSet).map(k => {
        const [row, col] = k.split(',').map(Number);
        return { row, col };
      }),
      closedSetNodes: getClosedSetNodes(closedNodes),
      path: [],
      costsMap: buildCostsMap(openSet, closedNodes),
      description: `EXPANDIENDO nodo ${formatPosition(currentNode.position)}`,
      explanation: `Se elige ${formatPosition(currentNode.position)} de la LISTA ABIERTA:\n\n` +
        `📋 LISTA ABIERTA (ordenada por f):\n${openListStr}${moreCount}\n\n` +
        `✅ Se selecciona el nodo con MENOR f = ${currentNode.f}\n` +
        `   (g=${currentNode.g} + h=${currentNode.h})\n\n` +
        `📤 El nodo se mueve a la LISTA CERRADA.\n\n` +
        `🔍 VECINOS a explorar (${neighbors.length}):\n   ${neighborsStr}`,
      g: currentNode.g,
      h: currentNode.h,
      f: currentNode.f,
    });

    for (const neighbor of neighbors) {
      const neighborKey = positionToKey(neighbor.position);
      
      // Si ya está en cerrado, saltar
      if (closedSet.has(neighborKey)) {
        continue;
      }

      const tentativeG = currentNode.g + neighbor.cost;
      const existingNode = openSet.get(neighborKey);

      if (!existingNode) {
        // Nuevo nodo
        const h = calculateHeuristic(neighbor.position, destinations, heuristicType);
        const newNode: AStarNode = {
          position: neighbor.position,
          g: tentativeG,
          h,
          f: tentativeG + h,
          parent: currentNode,
        };
        openSet.set(neighborKey, newNode);

        steps.push({
          type: 'visit',
          currentNode: neighbor.position,
          openSet: Array.from(openSet.values()).map(n => n.position),
          openSetNodes: getSortedOpenSetNodes(openSet, cols),
          closedSet: Array.from(closedSet).map(k => {
            const [row, col] = k.split(',').map(Number);
            return { row, col };
          }),
          closedSetNodes: getClosedSetNodes(closedNodes),
          path: [],
          costsMap: buildCostsMap(openSet, closedNodes),
          description: `AGREGANDO ${formatPosition(neighbor.position)} a LISTA ABIERTA`,
          explanation: `Se descubre ${formatPosition(neighbor.position)}:\n\n` +
            `📍 Movimiento: ${neighbor.direction.toUpperCase()}\n` +
            `💰 Costo del movimiento: +${neighbor.cost}\n\n` +
            `Cálculos:\n` +
            `   g = ${currentNode.g} + ${neighbor.cost} = ${tentativeG}\n` +
            `   h = ${h} (mínima distancia a destinos)\n` +
            `   f = g + h = ${newNode.f}\n\n` +
            `✅ NUEVO nodo agregado a LISTA ABIERTA.`,
          g: newNode.g,
          h: newNode.h,
          f: newNode.f,
        });
      } else if (tentativeG < existingNode.g) {
        // Mejor camino encontrado
        const oldG = existingNode.g;
        const oldF = existingNode.f;
        existingNode.g = tentativeG;
        existingNode.f = tentativeG + existingNode.h;
        existingNode.parent = currentNode;

        steps.push({
          type: 'visit',
          currentNode: neighbor.position,
          openSet: Array.from(openSet.values()).map(n => n.position),
          openSetNodes: getSortedOpenSetNodes(openSet, cols),
          closedSet: Array.from(closedSet).map(k => {
            const [row, col] = k.split(',').map(Number);
            return { row, col };
          }),
          closedSetNodes: getClosedSetNodes(closedNodes),
          path: [],
          costsMap: buildCostsMap(openSet, closedNodes),
          description: `ACTUALIZANDO ${formatPosition(neighbor.position)} - mejor camino`,
          explanation: `Se encontró un MEJOR CAMINO a ${formatPosition(neighbor.position)}:\n\n` +
            `📍 Desde: ${formatPosition(currentNode.position)}\n` +
            `💰 Nuevo costo: g = ${tentativeG} (era ${oldG})\n\n` +
            `Valores actualizados:\n` +
            `   g: ${oldG} → ${tentativeG}\n` +
            `   f: ${oldF} → ${existingNode.f}\n\n` +
            `✅ Nodo ACTUALIZADO en LISTA ABIERTA.`,
          g: existingNode.g,
          h: existingNode.h,
          f: existingNode.f,
        });
      }
    }
  }

  // No se encontró camino
  steps.push({
    type: 'complete',
    currentNode: { row: -1, col: -1 },
    openSet: [],
    openSetNodes: [],
    closedSet: Array.from(closedSet).map(k => {
      const [row, col] = k.split(',').map(Number);
      return { row, col };
    }),
    closedSetNodes: getClosedSetNodes(closedNodes),
    path: [],
    costsMap: buildCostsMap(openSet, closedNodes),
    description: 'No se encontró camino',
    explanation: 'La LISTA ABIERTA está vacía y no se llegó al destino.\nNo existe un camino viable.',
  });

  return steps;
}

/**
 * Obtiene el valor de heurística para cada celda no-obstáculo
 */
export function getHeuristicGrid(): number[][] {
  const maze = createMaze();
  return maze.map(row => row.map(cell => cell.heuristic));
}

/**
 * Formatea el nombre de la fila (F1-F6)
 */
export function formatRowName(row: number): string {
  return `F${row + 1}`;
}

/**
 * Formatea el nombre de la columna (C1-C6)
 */
export function formatColName(col: number): string {
  return `C${col + 1}`;
}
