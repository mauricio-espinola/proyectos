'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { MazeGrid } from './MazeGrid';
import { ControlPanel } from './ControlPanel';
import { createMaze, runAStar, calculateHeuristic } from '@/lib/maze/utils';
import { 
  HeuristicType, 
  MovementCosts, 
  DEFAULT_COSTS, 
  MazeConfiguration, 
  DEFAULT_MAZE_CONFIG,
  Position 
} from '@/lib/maze/types';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Target, MapPin, ArrowUp, ArrowRight, ArrowDown, ArrowLeft, Scale, Ruler, Route, ChevronUp, ChevronDown, Edit3, RotateCcw, GripVertical } from 'lucide-react';
import { TheorySection } from './TheorySection';

// Componente para mostrar la heurística con fórmula
function HeuristicDisplay({ 
  heuristicType, 
  heuristicName, 
  start, 
  destinations
}: { 
  heuristicType: HeuristicType;
  heuristicName: string;
  start: Position;
  destinations: Position[];
}) {
  // Calcular heurística para cada destino
  const distances = destinations.map(dest => {
    const deltaF = Math.abs(start.row - dest.row);
    const deltaC = Math.abs(start.col - dest.col);
    let distance: number;
    
    switch (heuristicType) {
      case 'manhattan':
        distance = deltaF + deltaC;
        break;
      case 'chebyshev':
        distance = Math.max(deltaF, deltaC);
        break;
      case 'euclidean':
        distance = Math.sqrt(deltaF * deltaF + deltaC * deltaC);
        break;
      case 'double-chebyshev':
      default:
        distance = 2 * Math.max(deltaF, deltaC);
        break;
    }
    return { dest, deltaF, deltaC, distance };
  });

  // Encontrar el destino más cercano (menor heurística)
  const nearest = distances.reduce((a, b) => a.distance <= b.distance ? a : b);
  const hValue = calculateHeuristic(start, destinations, heuristicType);

  // Generar la fórmula general
  const getFormulaGeneral = () => {
    switch (heuristicType) {
      case 'manhattan':
        return 'h = |Δf| + |Δc|';
      case 'chebyshev':
        return 'h = max(|Δf|, |Δc|)';
      case 'euclidean':
        return 'h = √(Δf² + Δc²)';
      case 'double-chebyshev':
      default:
        return 'h = 2 × max(|Δf|, |Δc|)';
    }
  };

  // Generar la fórmula con valores sustituidos
  const getFormulaWithValues = () => {
    const { deltaF, deltaC, distance, dest } = nearest;
    const destLabel = `F${dest.row + 1}C${dest.col + 1}`;
    
    switch (heuristicType) {
      case 'manhattan':
        return {
          formula: `${deltaF} + ${deltaC}`,
          result: distance,
          destLabel
        };
      case 'chebyshev':
        return {
          formula: `max(${deltaF}, ${deltaC})`,
          result: distance,
          destLabel
        };
      case 'euclidean':
        return {
          formula: `√(${deltaF}² + ${deltaC}²)`,
          result: distance.toFixed(2),
          destLabel
        };
      case 'double-chebyshev':
      default:
        return {
          formula: `2 × max(${deltaF}, ${deltaC})`,
          result: distance,
          destLabel
        };
    }
  };

  const formulaInfo = getFormulaWithValues();

  // Verificar si hay múltiples destinos
  const hasMultipleDestinations = destinations.length > 1;

  return (
    <div className="flex flex-col gap-2 text-sm">
      <div className="flex items-center gap-2">
        <Ruler className="h-4 w-4 text-purple-600" />
        <span className="font-semibold text-slate-700 dark:text-slate-200">Heurística ({heuristicName}):</span>
        {hasMultipleDestinations && (
          <span className="text-xs text-slate-700 dark:text-slate-300 italic">
            (con {destinations.length} destinos se elige la menor h)
          </span>
        )}
      </div>
      
      {/* Fórmula general */}
      <code className="px-3 py-1.5 bg-purple-50 dark:bg-purple-950 rounded text-slate-800 dark:text-slate-200 font-medium text-sm">
        {getFormulaGeneral()}
      </code>
      
      {/* Cálculo con valores */}
      <div className="mt-1 p-2 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950/50 dark:to-blue-950/50 rounded border border-purple-200 dark:border-purple-800">
        <div className="text-xs text-slate-800 dark:text-slate-200 mb-1">
          Desde <strong className="text-emerald-600 dark:text-emerald-400">F{start.row + 1}C{start.col + 1}</strong> hacia <strong className="text-amber-600 dark:text-amber-400">{formulaInfo.destLabel}</strong>:
        </div>
        <code className="text-sm font-semibold text-slate-800 dark:text-slate-200">
          h = {formulaInfo.formula} = <span className="text-purple-600 dark:text-purple-400">{formulaInfo.result}</span>
        </code>
        {hasMultipleDestinations && (
          <div className="mt-1 text-xs text-slate-700 dark:text-slate-300">
            h(final) = min({distances.map(d => d.distance).join(', ')}) = <strong className="text-purple-600 dark:text-purple-400">{hValue}</strong>
          </div>
        )}
      </div>
    </div>
  );
}

export function MazeVisualizer() {
  const [heuristicType, setHeuristicType] = useState<HeuristicType>('double-chebyshev');
  const [movementCosts, setMovementCosts] = useState<MovementCosts>(DEFAULT_COSTS);
  const [mazeConfig, setMazeConfig] = useState<MazeConfiguration>(DEFAULT_MAZE_CONFIG);
  const [isEditMode, setIsEditMode] = useState(false);
  const [dragType, setDragType] = useState<'start' | 'destination' | null>(null);
  const [dragIndex, setDragIndex] = useState<number>(-1);
  
  const [maze, setMaze] = useState(() => createMaze(heuristicType, mazeConfig));
  const [steps, setSteps] = useState(() => runAStar(createMaze(heuristicType, mazeConfig), heuristicType, movementCosts));
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(800);
  const [showHeuristic, setShowHeuristic] = useState(true);
  const [showCost, setShowCost] = useState(true);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const currentStep = steps[currentStepIndex];

  // Recalcular cuando cambia cualquier configuración
  useEffect(() => {
    const newMaze = createMaze(heuristicType, mazeConfig);
    const newSteps = runAStar(newMaze, heuristicType, movementCosts);
    setMaze(newMaze);
    setSteps(newSteps);
    setCurrentStepIndex(0);
    setIsPlaying(false);
  }, [heuristicType, movementCosts, mazeConfig]);

  const handlePlay = useCallback(() => {
    setIsPlaying(true);
  }, []);

  const handlePause = useCallback(() => {
    setIsPlaying(false);
  }, []);

  const handleStep = useCallback((direction: 'next' | 'prev') => {
    setIsPlaying(false);
    if (direction === 'next' && currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else if (direction === 'prev' && currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  }, [currentStepIndex, steps.length]);

  const handleReset = useCallback(() => {
    setIsPlaying(false);
    setCurrentStepIndex(0);
  }, []);

  // Reset del laberinto a configuración por defecto
  const handleResetMaze = useCallback(() => {
    setMazeConfig(DEFAULT_MAZE_CONFIG);
    setIsEditMode(false);
  }, []);

  // Auto-play effect
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev >= steps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, speed);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isPlaying, speed, steps.length]);

  const getHeuristicName = () => {
    switch (heuristicType) {
      case 'manhattan': return 'Manhattan';
      case 'chebyshev': return 'Chebyshev';
      case 'double-chebyshev': return 'Doble Chebyshev';
      case 'euclidean': return 'Euclidiana';
    }
  };

  // Funciones para ajustar costos
  const adjustCost = (type: 'vertical' | 'horizontal', delta: number) => {
    setMovementCosts(prev => ({
      ...prev,
      [type]: Math.max(1, prev[type] + delta)
    }));
  };

  // Toggle obstáculo en una celda
  const handleCellClick = useCallback((position: Position) => {
    if (!isEditMode) return;
    
    const { start, destinations, walkableCells } = mazeConfig;
    
    // No permitir modificar inicio ni destinos
    const isStart = start.row === position.row && start.col === position.col;
    const isDestination = destinations.some(d => d.row === position.row && d.col === position.col);
    
    if (isStart || isDestination) return;
    
    const isCurrentlyWalkable = walkableCells.some(w => w.row === position.row && w.col === position.col);
    
    if (isCurrentlyWalkable) {
      // Remover de walkableCells
      setMazeConfig(prev => ({
        ...prev,
        walkableCells: prev.walkableCells.filter(w => !(w.row === position.row && w.col === position.col))
      }));
    } else {
      // Agregar a walkableCells
      setMazeConfig(prev => ({
        ...prev,
        walkableCells: [...prev.walkableCells, position]
      }));
    }
  }, [isEditMode, mazeConfig]);

  // Drag and Drop handlers
  const handleDragStart = useCallback((type: 'start' | 'destination', index: number = -1) => {
    setDragType(type);
    setDragIndex(index);
  }, []);

  const handleDrop = useCallback((targetPosition: Position) => {
    if (!dragType) return;
    
    const { start, destinations, walkableCells } = mazeConfig;
    
    // Verificar que la posición destino es caminable
    const isTargetWalkable = walkableCells.some(w => w.row === targetPosition.row && w.col === targetPosition.col);
    if (!isTargetWalkable) {
      setDragType(null);
      setDragIndex(-1);
      return;
    }
    
    // Verificar que no colisiona con otros especiales
    const isStart = start.row === targetPosition.row && start.col === targetPosition.col;
    const isDestination = destinations.some(d => d.row === targetPosition.row && d.col === targetPosition.col);
    
    if (dragType === 'start') {
      if (isDestination) {
        setDragType(null);
        setDragIndex(-1);
        return;
      }
      setMazeConfig(prev => ({
        ...prev,
        start: targetPosition
      }));
    } else if (dragType === 'destination') {
      if (isStart) {
        setDragType(null);
        setDragIndex(-1);
        return;
      }
      // Si el destino actual está en la misma posición, ignorar
      if (destinations[dragIndex] && 
          destinations[dragIndex].row === targetPosition.row && 
          destinations[dragIndex].col === targetPosition.col) {
        setDragType(null);
        setDragIndex(-1);
        return;
      }
      
      setMazeConfig(prev => {
        const newDestinations = [...prev.destinations];
        newDestinations[dragIndex] = targetPosition;
        return {
          ...prev,
          destinations: newDestinations
        };
      });
    }
    
    setDragType(null);
    setDragIndex(-1);
  }, [dragType, dragIndex, mazeConfig]);

  // Agregar nuevo destino
  const handleAddDestination = useCallback(() => {
    // Encontrar una posición caminable que no sea inicio ni destino
    const { start, destinations, walkableCells } = mazeConfig;
    const availableCells = walkableCells.filter(w => {
      const isStart = start.row === w.row && start.col === w.col;
      const isDest = destinations.some(d => d.row === w.row && d.col === w.col);
      return !isStart && !isDest;
    });
    
    if (availableCells.length > 0) {
      setMazeConfig(prev => ({
        ...prev,
        destinations: [...prev.destinations, availableCells[0]]
      }));
    }
  }, [mazeConfig]);

  // Remover destino
  const handleRemoveDestination = useCallback((index: number) => {
    if (mazeConfig.destinations.length <= 1) return; // Mantener al menos 1 destino
    setMazeConfig(prev => ({
      ...prev,
      destinations: prev.destinations.filter((_, i) => i !== index)
    }));
  }, [mazeConfig]);

  return (
    <div className="space-y-4">
      {/* PROBLEMA Y CONDICIONES */}
      <Card className="border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Route className="h-5 w-5 text-purple-600" />
              Problema y Condiciones
            </div>
            {/* Botones de edición */}
            <div className="flex items-center gap-2">
              <Button
                variant={isEditMode ? "default" : "outline"}
                size="sm"
                onClick={() => setIsEditMode(!isEditMode)}
                className={`text-sm font-medium ${isEditMode ? 'bg-purple-500 hover:bg-purple-600' : ''}`}
              >
                <Edit3 className="h-4 w-4 mr-1" />
                {isEditMode ? 'Editando' : 'Editar'}
              </Button>
              {isEditMode && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleResetMaze}
                  className="text-sm font-medium"
                >
                  <RotateCcw className="h-4 w-4 mr-1" />
                  Reset
                </Button>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Inicio */}
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg ${isEditMode ? 'bg-emerald-200 dark:bg-emerald-800 cursor-grab active:cursor-grabbing' : 'bg-emerald-100 dark:bg-emerald-900'}`}
                   draggable={isEditMode}
                   onDragStart={() => handleDragStart('start')}
              >
                <MapPin className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Inicio</p>
                <p className="text-sm text-slate-800 dark:text-slate-200 font-medium">
                  F{mazeConfig.start.row + 1}, C{mazeConfig.start.col + 1}
                  {isEditMode && <span className="ml-1 text-xs text-purple-500">arrastrar</span>}
                </p>
              </div>
            </div>
            
            {/* Destinos */}
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg ${isEditMode ? 'bg-amber-200 dark:bg-amber-800' : 'bg-amber-100 dark:bg-amber-900'}`}>
                <Target className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Destinos</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {mazeConfig.destinations.map((dest, index) => (
                    <div 
                      key={index}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium
                        ${isEditMode 
                          ? 'bg-amber-100 dark:bg-amber-900 cursor-grab active:cursor-grabbing border border-amber-300 dark:border-amber-700' 
                          : 'bg-slate-100 dark:bg-slate-800'
                        }`}
                      draggable={isEditMode}
                      onDragStart={() => handleDragStart('destination', index)}
                    >
                      <GripVertical className="h-3 w-3 text-amber-500" />
                      <span>F{dest.row + 1}C{dest.col + 1}</span>
                      {isEditMode && mazeConfig.destinations.length > 1 && (
                        <button 
                          onClick={() => handleRemoveDestination(index)}
                          className="ml-1 text-red-500 hover:text-red-600"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  ))}
                  {isEditMode && mazeConfig.destinations.length < 3 && (
                    <button 
                      onClick={handleAddDestination}
                      className="px-2 py-0.5 rounded text-xs font-medium bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800"
                    >
                      + agregar
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Costos de movimiento con chevrons */}
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Scale className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">Costos</p>
                <div className="flex items-center gap-4">
                  {/* Costo Vertical */}
                  <div className="flex items-center gap-1">
                    <div className="flex flex-col">
                      <button
                        onClick={() => adjustCost('vertical', 1)}
                        className="p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition"
                      >
                        <ChevronUp className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      </button>
                      <button
                        onClick={() => adjustCost('vertical', -1)}
                        className="p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition"
                      >
                        <ChevronDown className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      </button>
                    </div>
                    <div className="flex items-center gap-1 px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded">
                      <ArrowUp className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      <ArrowDown className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      <span className="text-sm font-bold text-blue-600 dark:text-blue-400">{movementCosts.vertical}</span>
                    </div>
                  </div>
                  
                  {/* Costo Horizontal */}
                  <div className="flex items-center gap-1">
                    <div className="flex flex-col">
                      <button
                        onClick={() => adjustCost('horizontal', 1)}
                        className="p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition"
                      >
                        <ChevronUp className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      </button>
                      <button
                        onClick={() => adjustCost('horizontal', -1)}
                        className="p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition"
                      >
                        <ChevronDown className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      </button>
                    </div>
                    <div className="flex items-center gap-1 px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded">
                      <ArrowLeft className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      <ArrowRight className="h-3 w-3 text-slate-800 dark:text-slate-200" />
                      <span className="text-sm font-bold text-blue-600 dark:text-blue-400">{movementCosts.horizontal}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Fórmula de heurística y ayuda de edición */}
          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700">
            {isEditMode ? (
              <div className="flex items-start gap-2 text-sm bg-purple-50 dark:bg-purple-950 p-3 rounded-lg">
                <Edit3 className="h-4 w-4 text-purple-600 mt-0.5" />
                <div className="text-slate-700 dark:text-slate-300">
                  <p className="font-semibold text-purple-700 dark:text-purple-300">Modo Edición Activo:</p>
                  <ul className="mt-1 space-y-1 text-xs">
                    <li>• <strong>Click</strong> en una celda para agregar/quitar obstáculos</li>
                    <li>• <strong>Arrastra</strong> 📍 Inicio o 🎯 Destinos para moverlos</li>
                    <li>• Usa <strong>+ agregar</strong> para añadir más destinos (máx 3)</li>
                  </ul>
                </div>
              </div>
            ) : (
              <HeuristicDisplay 
                heuristicType={heuristicType}
                heuristicName={getHeuristicName()}
                start={mazeConfig.start}
                destinations={mazeConfig.destinations}
              />
            )}
          </div>
        </CardContent>
      </Card>

      {/* CONTROLES DE AVANCE */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow border border-slate-200 dark:border-slate-700">
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          {/* Botones de control */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="p-2 rounded-lg border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition text-lg font-bold"
              title="Reiniciar"
            >
              ↺
            </button>
            <button
              onClick={() => handleStep('prev')}
              disabled={currentStepIndex === 0}
              className="p-2 rounded-lg border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition disabled:opacity-50 text-lg font-bold"
              title="Anterior"
            >
              ◀
            </button>
            <button
              onClick={isPlaying ? handlePause : handlePlay}
              className="px-6 py-2 rounded-lg bg-purple-500 text-white hover:bg-purple-600 transition font-bold text-lg"
            >
              {isPlaying ? '⏸' : '▶'}
            </button>
            <button
              onClick={() => handleStep('next')}
              disabled={currentStepIndex >= steps.length - 1}
              className="p-2 rounded-lg border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition disabled:opacity-50 text-lg font-bold"
              title="Siguiente"
            >
              ▶
            </button>
          </div>

          {/* Progreso */}
          <div className="flex items-center gap-2 flex-1 max-w-xs">
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap">Paso {currentStepIndex + 1}/{steps.length}</span>
            <div className="flex-1 h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-purple-500 transition-all duration-300"
                style={{ width: `${((currentStepIndex + 1) / steps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Velocidad */}
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-800 dark:text-slate-200">Velocidad:</span>
            <input
              type="range"
              min={200}
              max={2000}
              step={100}
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              className="w-24 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-sm font-medium text-slate-800 dark:text-slate-200 w-12">{speed}ms</span>
          </div>

          {/* Selector de heurística */}
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-800 dark:text-slate-200">Heurística:</span>
            <select
              value={heuristicType}
              onChange={(e) => setHeuristicType(e.target.value as HeuristicType)}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-sm font-medium text-slate-700 dark:text-slate-200"
            >
              <option value="manhattan">Manhattan</option>
              <option value="chebyshev">Chebyshev</option>
              <option value="double-chebyshev">Doble Chebyshev</option>
              <option value="euclidean">Euclidiana</option>
            </select>
          </div>

          {/* Toggles con Switch */}
          <div className="flex gap-4 text-sm font-medium text-slate-700 dark:text-slate-300">
            <label className="flex items-center gap-2 cursor-pointer">
              <Switch
                checked={showHeuristic}
                onCheckedChange={setShowHeuristic}
              />
              <span>h</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <Switch
                checked={showCost}
                onCheckedChange={setShowCost}
              />
              <span>g, f</span>
            </label>
          </div>
        </div>
      </div>

      {/* Contenido principal: Laberinto + Listas */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Laberinto */}
        <div className="xl:col-span-2 space-y-4">
          <div className={`p-4 bg-white dark:bg-slate-900 rounded-xl shadow border-2 transition-colors ${
            isEditMode ? 'border-purple-400 dark:border-purple-600' : 'border-slate-200 dark:border-slate-700'
          }`}>
            <div className="flex justify-center overflow-x-auto pb-4">
              <MazeGrid 
                grid={maze} 
                currentStep={currentStep} 
                showHeuristic={showHeuristic}
                showCost={showCost}
                isEditMode={isEditMode}
                onCellClick={handleCellClick}
                onCellDrop={handleDrop}
                isDragging={dragType !== null}
              />
            </div>
          </div>
          
          {/* Leyenda */}
          <Card className="border-slate-300 dark:border-slate-600">
            <CardContent className="pt-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-2 text-xs font-medium text-slate-800 dark:text-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-emerald-500 rounded" />
                  <span><strong>INICIO:</strong> Punto de partida</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-amber-500 rounded" />
                  <span><strong>DESTINO:</strong> Meta (h=0)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-blue-100 border-2 border-blue-400 rounded" />
                  <span><strong>LISTA ABIERTA:</strong> Por explorar</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-slate-300 rounded" />
                  <span><strong>LISTA CERRADA:</strong> Explorados</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-emerald-300 border-2 border-emerald-400 rounded" />
                  <span><strong>CAMINO:</strong> Ruta óptima</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-4 border-fuchsia-500 rounded" />
                  <span><strong>NODO ACTUAL:</strong> En expansión</span>
                </div>
              </div>
              <div className="mt-3 pt-2 border-t border-slate-200 dark:border-slate-700 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-700 dark:text-slate-300 font-medium">
                <span><span className="text-blue-600 dark:text-blue-400 font-bold">h</span> = heurística</span>
                <span><span className="text-green-600 dark:text-green-400 font-bold">g</span> = costo acumulado</span>
                <span><span className="text-purple-600 dark:text-purple-400 font-bold">f</span> = g + h</span>
              </div>
            </CardContent>
          </Card>

          {/* Sección Teórica - Debajo de la leyenda */}
          <TheorySection 
            heuristicType={heuristicType}
            movementCosts={movementCosts}
            mazeConfig={mazeConfig}
            maze={maze}
          />
        </div>

        {/* Panel de listas y explicación */}
        <div className="xl:col-span-1">
          <ControlPanel
            steps={steps}
            currentStepIndex={currentStepIndex}
            isPlaying={isPlaying}
            speed={speed}
            showHeuristic={showHeuristic}
            showCost={showCost}
            onPlay={handlePlay}
            onPause={handlePause}
            onStep={handleStep}
            onReset={handleReset}
            onSpeedChange={setSpeed}
            onShowHeuristicChange={setShowHeuristic}
            onShowCostChange={setShowCost}
            heuristicName={getHeuristicName()}
            movementCosts={movementCosts}
          />
        </div>
      </div>
    </div>
  );
}
