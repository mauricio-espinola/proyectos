'use client';

import { cn } from '@/lib/utils';
import { MazeCell as MazeCellType } from '@/lib/maze/types';

interface MazeCellProps {
  cell: MazeCellType;
  isInOpenSet: boolean;
  isInClosedSet: boolean;
  isOnPath: boolean;
  isCurrentNode: boolean;
  showHeuristic: boolean;
  showCost: boolean;
  currentG?: number;
  currentF?: number;
  isEditMode?: boolean;
  onClick?: () => void;
}

export function MazeCell({ 
  cell, 
  isInOpenSet, 
  isInClosedSet, 
  isOnPath, 
  isCurrentNode,
  showHeuristic,
  showCost,
  currentG,
  currentF,
  isEditMode = false,
  onClick,
}: MazeCellProps) {
  const handleClick = () => {
    if (isEditMode && onClick) {
      onClick();
    }
  };

  return (
    <div
      onClick={handleClick}
      className={cn(
        'w-20 h-20 sm:w-24 sm:h-24 flex flex-col items-center justify-center border-2 border-border font-mono text-sm transition-all duration-300 relative',
        // En modo edición, cursor pointer para celdas modificables
        isEditMode && !cell.isStart && !cell.isDestination && 'cursor-pointer hover:ring-2 hover:ring-purple-400',
        // Obstáculos
        cell.isObstacle && 'bg-slate-700 border-slate-600',
        // Celda de inicio - draggable en modo edición
        cell.isStart && 'bg-emerald-500 text-white font-bold border-emerald-400',
        cell.isStart && isEditMode && 'ring-2 ring-emerald-300',
        // Celda de destino - draggable en modo edición
        cell.isDestination && 'bg-amber-500 text-white font-bold border-amber-400',
        cell.isDestination && isEditMode && 'ring-2 ring-amber-300',
        // Celdas transitables sin estado especial
        !cell.isObstacle && !cell.isStart && !cell.isDestination && 'bg-white dark:bg-slate-50 border-slate-300',
        // En conjunto abierto (azul claro)
        isInOpenSet && !cell.isStart && !cell.isDestination && 'bg-blue-100 dark:bg-blue-900 border-blue-400',
        // En conjunto cerrado (gris)
        isInClosedSet && !cell.isStart && !cell.isDestination && 'bg-slate-200 dark:bg-slate-700 border-slate-400',
        // En el camino final (verde claro)
        isOnPath && !cell.isStart && !cell.isDestination && 'bg-emerald-300 text-slate-800 border-emerald-400',
        // Nodo actual (borde fucsia uniforme)
        isCurrentNode && '!border-4 !border-fuchsia-500',
      )}
    >
      {cell.isObstacle ? (
        <span className="text-2xl">🧱</span>
      ) : cell.isStart ? (
        <div className="text-center">
          <div className="text-xs sm:text-sm font-bold">INICIO</div>
          <div className="flex gap-1 justify-center text-xs sm:text-sm mt-1 font-semibold">
            {showHeuristic && <span>h={cell.heuristic}</span>}
            {showCost && currentG !== undefined && <span>g={currentG}</span>}
          </div>
          {showCost && currentF !== undefined && (
            <div className="text-xs sm:text-sm font-bold text-yellow-200">f={currentF}</div>
          )}
        </div>
      ) : cell.isDestination ? (
        <div className="text-center">
          <div className="text-xs sm:text-sm font-bold">DESTINO</div>
          <div className="text-xs sm:text-sm font-semibold">h=0</div>
        </div>
      ) : (
        <div className="text-center">
          {/* Fila de h y g */}
          <div className="flex gap-1 justify-center text-xs sm:text-sm font-bold">
            {showHeuristic && <span className="text-blue-800 dark:text-blue-200">h={cell.heuristic}</span>}
            {showCost && currentG !== undefined && (
              <span className="text-green-800 dark:text-green-200">g={currentG}</span>
            )}
          </div>
          {/* Valor f */}
          {showCost && (
            <div className="text-sm sm:text-base font-bold text-purple-800 dark:text-purple-200 mt-0.5">
              {currentF !== undefined ? `f=${currentF}` : ''}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
