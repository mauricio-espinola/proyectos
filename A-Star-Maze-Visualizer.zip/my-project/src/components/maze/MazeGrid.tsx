'use client';

import { MazeGrid as MazeGridType, Position, AlgorithmStep } from '@/lib/maze/types';
import { MazeCell } from './MazeCell';
import { formatColName, formatRowName } from '@/lib/maze/utils';

interface MazeGridProps {
  grid: MazeGridType;
  currentStep: AlgorithmStep | null;
  showHeuristic: boolean;
  showCost: boolean;
  isEditMode?: boolean;
  onCellClick?: (position: Position) => void;
  onCellDrop?: (position: Position) => void;
  isDragging?: boolean;
}

export function MazeGrid({ 
  grid, 
  currentStep, 
  showHeuristic, 
  showCost,
  isEditMode = false,
  onCellClick,
  onCellDrop,
  isDragging = false
}: MazeGridProps) {
  // Determinar qué celdas están en cada estado
  const isOpenSet = (pos: Position): boolean => {
    if (!currentStep) return false;
    return currentStep.openSet.some(p => p.row === pos.row && p.col === pos.col);
  };

  const isClosedSet = (pos: Position): boolean => {
    if (!currentStep) return false;
    return currentStep.closedSet.some(p => p.row === pos.row && p.col === pos.col);
  };

  const isOnPath = (pos: Position): boolean => {
    if (!currentStep) return false;
    return currentStep.path.some(p => p.row === pos.row && p.col === pos.col);
  };

  const isCurrentNode = (pos: Position): boolean => {
    if (!currentStep) return false;
    return currentStep.currentNode.row === pos.row && currentStep.currentNode.col === pos.col;
  };

  // Obtener costo g y f de una posición
  const getCosts = (pos: Position): { g?: number; f?: number } => {
    if (!currentStep || !currentStep.costsMap) return {};
    const key = `${pos.row},${pos.col}`;
    return currentStep.costsMap[key] || {};
  };

  // Handlers de drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, position: Position) => {
    e.preventDefault();
    if (onCellDrop) {
      onCellDrop(position);
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* Encabezado de columnas */}
      <div className="flex">
        <div className="w-10 h-8 sm:w-12 sm:h-10" /> {/* Espacio esquina */}
        {Array.from({ length: grid[0]?.length || 0 }).map((_, colIdx) => (
          <div
            key={colIdx}
            className="w-20 h-8 sm:w-24 sm:h-10 flex items-center justify-center font-bold text-slate-800 dark:text-slate-100 text-sm"
          >
            {formatColName(colIdx)}
          </div>
        ))}
      </div>

      {/* Filas del laberinto */}
      {grid.map((row, rowIdx) => (
        <div key={rowIdx} className="flex">
          {/* Etiqueta de fila */}
          <div className="w-10 h-20 sm:w-12 sm:h-24 flex items-center justify-center font-bold text-slate-800 dark:text-slate-100 text-sm">
            {formatRowName(rowIdx)}
          </div>
          
          {/* Celdas */}
          {row.map((cell, colIdx) => {
            const costs = getCosts(cell.position);
            const isCurrent = isCurrentNode(cell.position);
            return (
              <div
                key={`${rowIdx}-${colIdx}`}
                onDragOver={isEditMode ? handleDragOver : undefined}
                onDrop={isEditMode && isDragging ? (e) => handleDrop(e, cell.position) : undefined}
                className={isCurrent ? 'z-10 relative' : ''}
              >
                <MazeCell
                  cell={cell}
                  isInOpenSet={isOpenSet(cell.position)}
                  isInClosedSet={isClosedSet(cell.position)}
                  isOnPath={isOnPath(cell.position)}
                  isCurrentNode={isCurrent}
                  showHeuristic={showHeuristic}
                  showCost={showCost}
                  currentG={costs.g}
                  currentF={costs.f}
                  isEditMode={isEditMode}
                  onClick={() => onCellClick?.(cell.position)}
                />
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
