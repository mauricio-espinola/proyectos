'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Lightbulb, BookOpen, AlertTriangle } from 'lucide-react';
import { HeuristicType, MovementCosts, MazeConfiguration, Position } from '@/lib/maze/types';
import { calculateHeuristic, formatPosition } from '@/lib/maze/utils';

interface TheorySectionProps {
  heuristicType: HeuristicType;
  movementCosts: MovementCosts;
  mazeConfig: MazeConfiguration;
  maze: any[][];
}

export function TheorySection({ heuristicType, movementCosts, mazeConfig, maze }: TheorySectionProps) {
  const { start, destinations } = mazeConfig;
  const minCost = Math.min(movementCosts.vertical, movementCosts.horizontal);
  
  // Calcular heurística del inicio
  const startH = calculateHeuristic(start, destinations, heuristicType);
  
  // Obtener nombre de heurística
  const getHeuristicName = () => {
    switch (heuristicType) {
      case 'manhattan': return 'Manhattan';
      case 'chebyshev': return 'Chebyshev';
      case 'double-chebyshev': return 'Doble Chebyshev';
      case 'euclidean': return 'Euclidiana';
    }
  };

  // Obtener fórmula
  const getFormula = () => {
    switch (heuristicType) {
      case 'manhattan': return 'h = |Δf| + |Δc|';
      case 'chebyshev': return 'h = max(|Δf|, |Δc|)';
      case 'double-chebyshev': return 'h = 2 × max(|Δf|, |Δc|)';
      case 'euclidean': return 'h = √(Δf² + Δc²)';
    }
  };

  // Verificar admisibilidad
  const checkAdmissibility = () => {
    // La heurística es admisible si min(h_costs) * distance <= real_cost_min
    // Para ser admisible: h(n) <= h*(n) para todo n
    if (heuristicType === 'double-chebyshev') {
      return minCost >= 2;
    }
    if (heuristicType === 'chebyshev') {
      return minCost >= 1;
    }
    if (heuristicType === 'manhattan') {
      return movementCosts.vertical >= 1 && movementCosts.horizontal >= 1;
    }
    if (heuristicType === 'euclidean') {
      // Euclidiana siempre es <= Manhattan, así que si costos >= 1 es admisible
      return minCost >= 1;
    }
    return true;
  };

  const isAdmissible = checkAdmissibility();

  return (
    <div className="space-y-4 mt-6">
      {/* Pregunta 1: Admisibilidad */}
      <Card className="border-slate-300 dark:border-slate-600 gap-1 py-4">
        <CardHeader className="pb-1">
          <CardTitle className="flex items-center gap-2 text-base font-bold text-slate-800 dark:text-slate-100">
            <BookOpen className="h-5 w-5 text-blue-600" />
            1. Admisibilidad de la Heurística ({getHeuristicName()})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-2">
          <div className={`p-3 rounded-lg border ${
            isAdmissible 
              ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800' 
              : 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800'
          }`}>
            <div className="flex items-start gap-3">
              {isAdmissible ? (
                <CheckCircle className="h-5 w-5 text-emerald-600 mt-0.5" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
              )}
              <div>
                <h4 className={`font-bold text-base ${
                  isAdmissible 
                    ? 'text-emerald-700 dark:text-emerald-400' 
                    : 'text-red-700 dark:text-red-400'
                }`}>
                  La heurística {isAdmissible ? 'SÍ' : 'NO'} es admisible
                </h4>
                <p className="mt-1 text-sm text-slate-700 dark:text-slate-300 font-medium">
                  Una heurística es admisible si nunca sobreestima el costo real para llegar al objetivo. La heurística se basa solo en el costo mínimo de sus componentes (distancia), sin considerar obstáculos ni caminos alternativos, por lo que siempre será menor o igual al costo real de llegar al destino.
                </p>
                <ul className="mt-2 space-y-1 text-sm text-slate-700 dark:text-slate-300 list-disc list-inside font-medium">
                  <li><strong>Fórmula actual:</strong> <code className="text-purple-600 dark:text-purple-400">{getFormula()}</code></li>
                  <li><strong>Costo mínimo por paso:</strong> {minCost} ({minCost === movementCosts.vertical ? 'vertical' : 'horizontal'})</li>
                  <li><strong>Condición de admisibilidad:</strong> h(n) ≤ costo_real_para_llegar_al_objetivo</li>
                  {!isAdmissible && (
                    <li className="text-red-600 dark:text-red-400">
                      <strong>Problema:</strong> Con costos {movementCosts.vertical},{movementCosts.horizontal} la heurística puede sobreestimar.
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>

          {!isAdmissible && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg">
              <h4 className="font-semibold text-amber-700 dark:text-amber-400 text-sm">
                Para que sea admisible:
              </h4>
              <ul className="mt-1 text-sm text-slate-700 dark:text-slate-300 font-medium">
                {heuristicType === 'double-chebyshev' && (
                  <li>El costo mínimo debe ser al menos 2 (actual: {minCost})</li>
                )}
                {heuristicType === 'chebyshev' && (
                  <li>El costo mínimo debe ser al menos 1</li>
                )}
              </ul>
            </div>
          )}

          {/* Ejemplo dinámico de (no) admisibilidad */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
            <h4 className="font-semibold text-slate-800 dark:text-slate-200 text-sm flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              Ejemplo de heurística NO admisible:
            </h4>
            
            {!isAdmissible ? (
              /* Caso actual NO admisible - usar valores reales */
              <div className="mt-2 p-2 bg-red-50 dark:bg-red-950/50 rounded border border-red-200 dark:border-red-800">
                <p className="text-xs text-slate-700 dark:text-slate-300 font-semibold text-red-600 dark:text-red-400">
                  ⚠️ Tu configuración actual NO es admisible
                </p>
                <p className="mt-1 text-xs text-slate-700 dark:text-slate-300">
                  Fórmula: <code className="text-purple-600 dark:text-purple-400">{getFormula()}</code> con costo mínimo = {minCost}
                </p>
                <ul className="mt-1 space-y-0.5 text-xs text-slate-700 dark:text-slate-300">
                  <li>• Nodo a distancia max(|Δf|, |Δc|) = <strong>1</strong> del destino</li>
                  <li>• Heurística: h = {heuristicType === 'double-chebyshev' ? '2' : '1'} × 1 = <strong className="text-red-600">{heuristicType === 'double-chebyshev' ? '2' : '1'}</strong></li>
                  <li>• Costo real mínimo: 1 paso × {minCost} = <strong className="text-emerald-600">{minCost}</strong></li>
                  {heuristicType === 'double-chebyshev' && (
                    <li className="text-red-600 dark:text-red-400 font-semibold">
                      → h=2 &gt; costo_real={minCost} → SOBRESTIMA → NO admisible
                    </li>
                  )}
                </ul>
              </div>
            ) : (
              /* Configuración admisible - mostrar caso hipotético */
              <div className="mt-2 p-2 bg-amber-50 dark:bg-amber-950/50 rounded border border-amber-200 dark:border-amber-800">
                <p className="text-xs text-slate-700 dark:text-slate-300 font-semibold">
                  Caso hipotético: Doble Chebyshev con costo = 1
                </p>
                <p className="mt-1 text-xs text-slate-700 dark:text-slate-300">
                  Fórmula: <code className="text-purple-600 dark:text-purple-400">h = 2 × max(|Δf|, |Δc|)</code> con costo mínimo = 1
                </p>
                <ul className="mt-1 space-y-0.5 text-xs text-slate-700 dark:text-slate-300">
                  <li>• Nodo a distancia max(|Δf|, |Δc|) = <strong>2</strong> del destino</li>
                  <li>• Heurística: h = 2 × 2 = <strong className="text-red-600">4</strong></li>
                  <li>• Costo real mínimo: 2 pasos × 1 = <strong className="text-emerald-600">2</strong></li>
                  <li className="text-red-600 dark:text-red-400 font-semibold">
                    → h=4 &gt; costo_real=2 → SOBRESTIMA → NO admisible
                  </li>
                </ul>
              </div>
            )}

            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400">
              <strong>Consecuencia:</strong> A* podría no encontrar el camino óptimo, ya que puede descartar nodos prometedores creyendo que son más costosos de lo que realmente son.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Pregunta 2: Valores de Heurística */}
      <Card className="border-slate-300 dark:border-slate-600 gap-1 py-4">
        <CardHeader className="pb-1">
          <CardTitle className="flex items-center gap-2 text-base font-bold text-slate-800 dark:text-slate-100">
            <BookOpen className="h-5 w-5 text-blue-600" />
            2. Valores de Heurística en el Laberinto Actual
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <p className="text-sm text-slate-700 dark:text-slate-300 mb-3 font-medium">
            Valores de h(n) usando <strong>{getHeuristicName()}</strong> desde cada celda hacia los destinos.
          </p>
          
          {/* Tabla de valores */}
          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse text-sm">
              <thead>
                <tr>
                  <th className="p-1.5 border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"></th>
                  {['C1', 'C2', 'C3', 'C4', 'C5', 'C6'].map(c => (
                    <th key={c} className="p-1.5 border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 font-bold text-slate-800 dark:text-slate-200">{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {maze.map((row, rowIdx) => (
                  <tr key={rowIdx}>
                    <td className="p-1.5 border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 font-bold text-xs text-slate-800 dark:text-slate-200">F{rowIdx + 1}</td>
                    {row.map((cell, colIdx) => (
                      <td 
                        key={colIdx} 
                        className={`p-1.5 border border-slate-300 dark:border-slate-600 text-xs font-bold ${
                          cell.isObstacle 
                            ? 'bg-slate-600 text-white' 
                            : cell.isStart 
                              ? 'bg-emerald-200 dark:bg-emerald-800 text-slate-800 dark:text-slate-100'
                              : cell.isDestination
                                ? 'bg-amber-200 dark:bg-amber-800 text-slate-800 dark:text-slate-100'
                                : 'text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {cell.isObstacle ? '🧱' : cell.isStart ? `INICIO h=${heuristicType === 'euclidean' ? cell.heuristic.toFixed(2) : cell.heuristic}` : cell.isDestination ? `DEST h=0` : `h=${heuristicType === 'euclidean' ? cell.heuristic.toFixed(2) : cell.heuristic}`}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Cálculo de ejemplo */}
          <div className="mt-3 p-2 bg-slate-50 dark:bg-slate-800 rounded-lg text-xs">
            <p className="text-slate-800 dark:text-slate-200 font-semibold">
              Cálculo para INICIO ({formatPosition(start)}):
            </p>
            <ul className="mt-1 text-slate-700 dark:text-slate-300 font-medium">
              {destinations.map((dest, idx) => {
                const deltaF = Math.abs(start.row - dest.row);
                const deltaC = Math.abs(start.col - dest.col);
                let h: number;
                let formula: string;
                
                switch (heuristicType) {
                  case 'manhattan':
                    h = deltaF + deltaC;
                    formula = `${deltaF} + ${deltaC}`;
                    break;
                  case 'chebyshev':
                    h = Math.max(deltaF, deltaC);
                    formula = `max(${deltaF}, ${deltaC})`;
                    break;
                  case 'euclidean':
                    h = Math.sqrt(deltaF * deltaF + deltaC * deltaC);
                    formula = `√(${deltaF}² + ${deltaC}²)`;
                    break;
                  case 'double-chebyshev':
                  default:
                    h = 2 * Math.max(deltaF, deltaC);
                    formula = `2 × max(${deltaF}, ${deltaC})`;
                    break;
                }
                
                return (
                  <li key={idx}>
                    → {formatPosition(dest)}: h = {formula} = <strong>{heuristicType === 'euclidean' ? h.toFixed(2) : h}</strong>
                  </li>
                );
              })}
              <li className="text-purple-600 dark:text-purple-400 font-bold">
                h(final) = min({destinations.map(d => {
                  const deltaF = Math.abs(start.row - d.row);
                  const deltaC = Math.abs(start.col - d.col);
                  switch (heuristicType) {
                    case 'manhattan': return deltaF + deltaC;
                    case 'chebyshev': return Math.max(deltaF, deltaC);
                    case 'euclidean': return Math.sqrt(deltaF * deltaF + deltaC * deltaC).toFixed(2);
                    default: return 2 * Math.max(deltaF, deltaC);
                  }
                }).join(', ')}) = {heuristicType === 'euclidean' ? startH.toFixed(2) : startH}
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Pregunta 3: Heurística más informada */}
      <Card className="border-slate-300 dark:border-slate-600 gap-1 py-4">
        <CardHeader className="pb-1">
          <CardTitle className="flex items-center gap-2 text-base font-bold text-slate-800 dark:text-slate-100">
            <BookOpen className="h-5 w-5 text-blue-600" />
            3. Heurística Más Informada
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-2">
          <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
            <div className="flex items-start gap-3">
              <Lightbulb className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-bold text-blue-700 dark:text-blue-400 text-sm">
                  Heurística Ponderada por Costos
                </h4>
                <p className="mt-1 text-sm text-slate-700 dark:text-slate-300 font-medium">
                  Una heurística más informada considera los costos reales de movimiento.
                </p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg text-sm">
            <code className="text-purple-600 dark:text-purple-400 font-semibold">
              h&apos;(n) = {movementCosts.vertical} × |Δf| + {movementCosts.horizontal} × |Δc|
            </code>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 font-medium">
              Pondera según costos actuales: vertical={movementCosts.vertical}, horizontal={movementCosts.horizontal}
            </p>
            <div className="mt-2 p-2 bg-emerald-100 dark:bg-emerald-900 rounded text-xs font-medium text-slate-700 dark:text-slate-300">
              <strong>Ejemplo:</strong> Desde {formatPosition(start)} a {formatPosition(destinations[0])}:
              <br />h&apos; = {movementCosts.vertical}×{Math.abs(start.row - destinations[0].row)} + {movementCosts.horizontal}×{Math.abs(start.col - destinations[0].col)} = {movementCosts.vertical * Math.abs(start.row - destinations[0].row) + movementCosts.horizontal * Math.abs(start.col - destinations[0].col)}
            </div>
          </div>

          <div className="p-3 bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 rounded-lg">
            <h4 className="font-bold text-purple-700 dark:text-purple-400 text-sm">
              ¿Por qué es más informada?
            </h4>
            <ol className="mt-1 space-y-1 text-xs text-slate-700 dark:text-slate-300 list-decimal list-inside font-medium">
              <li>Mayor valor sin sobreestimar (si es admisible)</li>
              <li>Considera los costos diferenciales reales</li>
              <li>Expande menos nodos en A*</li>
            </ol>
          </div>
        </CardContent>
      </Card>

      {/* Resumen de parámetros actuales */}
      <Card className="border-slate-300 dark:border-slate-600 gap-1 py-3">
        <CardHeader className="pb-1">
          <CardTitle className="text-base font-bold text-slate-800 dark:text-slate-100">
            Parámetros Actuales
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Heurística</p>
              <p className="font-bold text-slate-800 dark:text-slate-200">{getHeuristicName()}</p>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Costo ↑↓</p>
              <p className="font-bold text-slate-800 dark:text-slate-200">{movementCosts.vertical}</p>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Costo ←→</p>
              <p className="font-bold text-slate-800 dark:text-slate-200">{movementCosts.horizontal}</p>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Admisible</p>
              <p className={`font-bold ${isAdmissible ? 'text-emerald-600' : 'text-red-600'}`}>
                {isAdmissible ? 'Sí ✓' : 'No ✗'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
