'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ListOrdered, CheckCircle2, Info, ArrowUpDown, Route, DollarSign } from 'lucide-react';
import { AlgorithmStep, OpenSetNode, MovementCosts } from '@/lib/maze/types';
import { formatPosition } from '@/lib/maze/utils';

interface ControlPanelProps {
  steps: AlgorithmStep[];
  currentStepIndex: number;
  isPlaying: boolean;
  speed: number;
  showHeuristic: boolean;
  showCost: boolean;
  onPlay: () => void;
  onPause: () => void;
  onStep: (direction: 'next' | 'prev') => void;
  onReset: () => void;
  onSpeedChange: (speed: number) => void;
  onShowHeuristicChange: (show: boolean) => void;
  onShowCostChange: (show: boolean) => void;
  heuristicName: string;
  movementCosts: MovementCosts;
}

function OpenSetListNode({ node, isSelected }: { node: OpenSetNode; isSelected: boolean }) {
  return (
    <div className={`p-2 rounded border text-sm font-mono ${
      isSelected 
        ? 'bg-purple-100 dark:bg-purple-900 border-purple-500' 
        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
    }`}>
      <div className="flex items-center justify-between">
        <span className={`font-bold ${isSelected ? 'text-purple-800 dark:text-purple-200' : 'text-slate-700 dark:text-slate-300'}`}>
          {isSelected ? '➤' : '  '} {formatPosition(node.position)}
        </span>
        <span className={`font-bold ${isSelected ? 'text-purple-700 dark:text-purple-300' : 'text-purple-600 dark:text-purple-400'}`}>
          f={node.f}
        </span>
      </div>
      <div className="flex gap-2 mt-0.5 text-slate-800 dark:text-slate-200 font-medium">
        <span>g={node.g}</span>
        <span>h={node.h}</span>
      </div>
    </div>
  );
}

function ClosedSetListNode({ node, isMostRecent }: { node: OpenSetNode; isMostRecent: boolean }) {
  return (
    <div className={`p-2 rounded border text-sm font-mono bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600 ${
      isMostRecent ? 'ring-2 ring-emerald-400' : ''
    }`}>
      <div className="flex items-center justify-between">
        <span className="font-bold text-slate-700 dark:text-slate-200">
          {isMostRecent ? '★' : '✓'} {formatPosition(node.position)}
        </span>
        <span className="text-slate-800 dark:text-slate-200 font-medium">
          f={node.f}
        </span>
      </div>
      <div className="flex gap-2 mt-0.5 text-slate-700 dark:text-slate-300 font-medium">
        <span>g={node.g}</span>
        <span>h={node.h}</span>
      </div>
    </div>
  );
}

export function ControlPanel({
  steps,
  currentStepIndex,
  heuristicName,
  movementCosts,
}: ControlPanelProps) {
  const currentStep = steps[currentStepIndex];
  const [closedListReversed, setClosedListReversed] = useState(false);
  const [showAllOpen, setShowAllOpen] = useState(false);
  const [showAllClosed, setShowAllClosed] = useState(false);

  // Mostrar solo 3 por defecto
  const openNodes = currentStep?.openSetNodes || [];
  const openNodesToShow = showAllOpen ? openNodes : openNodes.slice(0, 3);
  
  const closedNodes = currentStep?.closedSetNodes || [];
  const sortedClosedNodes = closedListReversed 
    ? [...closedNodes].reverse() 
    : closedNodes;
  const closedNodesToShow = showAllClosed ? sortedClosedNodes : sortedClosedNodes.slice(0, 3);

  // Información del camino óptimo (solo si se encontró)
  const hasFoundPath = currentStep?.type === 'found';
  const optimalPath = currentStep?.path || [];
  const optimalCost = currentStep?.g || 0;

  return (
    <div className="space-y-3">
      {/* LISTA ABIERTA */}
      <Card className="border-blue-300 dark:border-blue-700 gap-1 py-3">
        <CardHeader className="pb-1">
          <CardTitle className="text-base font-bold flex items-center gap-2 text-blue-700 dark:text-blue-300">
            <ListOrdered className="h-5 w-5" />
            LISTA ABIERTA
            <Badge variant="outline" className="ml-auto text-sm font-semibold">
              {openNodes.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="rounded border border-slate-200 dark:border-slate-700 p-2 bg-blue-50/50 dark:bg-blue-950/30 space-y-1.5">
            {openNodesToShow.length > 0 ? (
              openNodesToShow.map((node, index) => (
                <OpenSetListNode 
                  key={`${node.position.row}-${node.position.col}`}
                  node={node} 
                  isSelected={index === 0} 
                />
              ))
            ) : (
              <div className="text-center text-sm text-slate-800 dark:text-slate-200 py-2 font-medium">
                Lista vacía
              </div>
            )}
          </div>
          
          {/* Botón ver más */}
          {openNodes.length > 3 && (
            <button
              onClick={() => setShowAllOpen(!showAllOpen)}
              className="w-full mt-2 text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition font-medium"
            >
              {showAllOpen ? '▲ Ver menos' : `▼ Ver todos (${openNodes.length})`}
            </button>
          )}
          
          <p className="text-xs text-slate-800 dark:text-slate-200 mt-1.5 font-medium">
            ↑ El nodo con menor f será seleccionado
          </p>
        </CardContent>
      </Card>

      {/* LISTA CERRADA */}
      <Card className="border-slate-400 dark:border-slate-600 gap-1 py-3">
        <CardHeader className="pb-1">
          <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-700 dark:text-slate-300">
            <CheckCircle2 className="h-5 w-5" />
            LISTA CERRADA
            <Badge variant="outline" className="ml-auto text-sm font-semibold">
              {closedNodes.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="rounded border border-slate-200 dark:border-slate-700 p-2 bg-slate-100/50 dark:bg-slate-900/50 space-y-1.5">
            {closedNodesToShow.length > 0 ? (
              closedNodesToShow.map((node, index) => (
                <ClosedSetListNode 
                  key={`${node.position.row}-${node.position.col}`}
                  node={node} 
                  isMostRecent={index === 0 && !closedListReversed}
                />
              ))
            ) : (
              <div className="text-center text-sm text-slate-800 dark:text-slate-200 py-2 font-medium">
                Lista vacía
              </div>
            )}
          </div>
          
          {/* Botones */}
          <div className="flex items-center gap-2 mt-2">
            {/* Botón ver más */}
            {closedNodes.length > 3 && (
              <button
                onClick={() => setShowAllClosed(!showAllClosed)}
                className="flex-1 text-sm text-slate-800 dark:text-slate-200 hover:text-slate-900 dark:hover:text-slate-100 transition font-medium"
              >
                {showAllClosed ? '▲ Ver menos' : `▼ Ver todos (${closedNodes.length})`}
              </button>
            )}
            
            {/* Botón invertir orden */}
            <button
              onClick={() => setClosedListReversed(!closedListReversed)}
              className={`flex items-center gap-1 px-2 py-1 rounded text-sm border transition font-medium ${
                closedListReversed 
                  ? 'bg-purple-100 border-purple-300 text-purple-700 dark:bg-purple-900 dark:border-purple-600 dark:text-purple-300' 
                  : 'border-slate-300 text-slate-800 hover:bg-slate-100 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
              title="Invertir orden"
            >
              <ArrowUpDown className="h-3.5 w-3.5" />
              {closedListReversed ? 'Antiguo→Nuevo' : 'Nuevo→Antiguo'}
            </button>
          </div>
          
          <p className="text-xs text-slate-800 dark:text-slate-200 mt-1.5 font-medium">
            ★ = nodo más reciente agregado
          </p>
        </CardContent>
      </Card>

      {/* CAMINO ÓPTIMO Y COSTO */}
      {(hasFoundPath || closedNodes.length > 0) && (
        <Card className={`border-emerald-400 dark:border-emerald-600 gap-1 py-3 ${hasFoundPath ? 'bg-emerald-50 dark:bg-emerald-950/30' : ''}`}>
          <CardHeader className="pb-1">
            <CardTitle className="text-base font-bold flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
              <Route className="h-5 w-5" />
              CAMINO ÓPTIMO
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {hasFoundPath ? (
              <div className="space-y-2">
                {/* Camino */}
                <div className="p-2 bg-white dark:bg-slate-800 rounded border border-emerald-200 dark:border-emerald-700">
                  <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1">Ruta:</p>
                  <p className="text-sm font-mono text-emerald-700 dark:text-emerald-300 font-medium">
                    {optimalPath.map(p => formatPosition(p)).join(' → ')}
                  </p>
                </div>
                
                {/* Costo total */}
                <div className="flex items-center justify-between p-2 bg-emerald-100 dark:bg-emerald-900 rounded border border-emerald-300 dark:border-emerald-700">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">Costo Total (g):</span>
                  </div>
                  <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300">{optimalCost}</span>
                </div>
                
                {/* Información adicional */}
                <div className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                  <p>• Pasos del camino: {optimalPath.length}</p>
                  <p>• Heurística usada: {heuristicName}</p>
                  <p>• Costos: ↑↓={movementCosts.vertical}, ←→={movementCosts.horizontal}</p>
                </div>
              </div>
            ) : (
              <div className="text-center text-sm text-slate-800 dark:text-slate-200 py-3 font-medium">
                {currentStepIndex === 0 
                  ? 'Inicia la simulación para encontrar el camino'
                  : 'Buscando camino óptimo...'
                }
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Explicación del paso */}
      {currentStep && (
        <Card className={`gap-1 py-3 ${
          currentStep.type === 'expand' ? 'border-purple-400 dark:border-purple-600' :
          currentStep.type === 'visit' ? 'border-blue-400 dark:border-blue-600' :
          currentStep.type === 'found' ? 'border-emerald-400 dark:border-emerald-600' :
          ''
        }`}>
          <CardHeader className="pb-1">
            <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-800 dark:text-slate-100">
              <Info className="h-5 w-5" />
              {currentStep.description}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <pre className="text-sm whitespace-pre-wrap text-slate-700 dark:text-slate-300 font-sans leading-relaxed">
                {currentStep.explanation}
              </pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
