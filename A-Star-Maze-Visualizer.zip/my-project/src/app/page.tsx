'use client';

import { MazeVisualizer } from '@/components/maze/MazeVisualizer';
import { Brain } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 shadow-sm border-b border-slate-200 dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Brain className="h-8 w-8 text-purple-600" />
              <div>
                <h1 className="text-xl font-bold text-slate-800 dark:text-white">
                  Laberinto con Heurística - A*
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-300 font-medium">
                  Visualización interactiva paso a paso
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-4">
        <MazeVisualizer />
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="text-center text-sm text-slate-600 dark:text-slate-400 font-medium">
            Ejercicio de Inteligencia Artificial - Búsqueda Heurística con A*
          </div>
        </div>
      </footer>
    </div>
  );
}
