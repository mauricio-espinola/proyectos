'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';

interface IntroductionProps {
  onStart: () => void;
}

export function Introduction({ onStart }: IntroductionProps) {
  const [showMore, setShowMore] = useState(false);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Título principal */}
      <div className="bg-black text-white p-8 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
        <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">
          TABLAS DE VERDAD
        </h1>
        <p className="text-xl text-gray-300 font-medium">
          Aprende lógica proposicional paso a paso
        </p>
      </div>

      {/* Definición */}
      <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <div className="bg-gray-100 px-6 py-3 border-b-4 border-black">
          <h2 className="text-xl font-bold">📖 ¿Qué es una Tabla de Verdad?</h2>
        </div>
        <div className="p-6">
          <p className="text-lg leading-relaxed mb-4">
            Una <strong>tabla de verdad</strong> es una herramienta matemática que nos permite 
            determinar el valor de verdad (verdadero o falso) de una proposición lógica, 
            analizando <strong>todas las combinaciones posibles</strong> de sus variables.
          </p>
          
          <div className="bg-amber-50 border-4 border-amber-300 p-4 mb-4">
            <p className="font-medium text-amber-800">
              <span className="text-2xl mr-2">🎯</span>
              <strong>Objetivo:</strong> Saber si una proposición es siempre verdadera (tautología), 
              siempre falsa (contradicción), o depende de los valores (contingencia).
            </p>
          </div>

          <div className="bg-blue-50 border-4 border-blue-300 p-4">
            <p className="font-medium text-blue-800">
              <span className="text-2xl mr-2">💡</span>
              <strong>Ejemplo:</strong> "Está lloviendo" es una proposición que puede ser verdadera 
              o falsa. Si llamamos <code className="bg-blue-200 px-2 py-1">p</code> a esta proposición, 
              podemos combinarla con otras usando operadores lógicos.
            </p>
          </div>
        </div>
      </div>

      {/* ¿Cómo funciona? */}
      <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <div className="bg-gray-100 px-6 py-3 border-b-4 border-black">
          <h2 className="text-xl font-bold">⚙️ ¿Cómo Funciona?</h2>
        </div>
        <div className="p-6">
          <div className="grid gap-4 md:grid-cols-3">
            <StepCard
              number={1}
              title="Define Variables"
              description="Asigna letras a cada proposición simple (p, q, r...)"
              icon="📝"
            />
            <StepCard
              number={2}
              title="Construye la Expresión"
              description="Combina variables con operadores lógicos"
              icon="🔗"
            />
            <StepCard
              number={3}
              title="Evalúa Combinaciones"
              description="Calcula el resultado para cada combinación posible"
              icon="📊"
            />
          </div>
        </div>
      </div>

      {/* Mostrar más información */}
      {!showMore && (
        <button
          onClick={() => setShowMore(true)}
          className="w-full bg-gray-100 border-4 border-black p-4 font-bold text-lg hover:bg-gray-200 transition-colors"
        >
          ▼ Ver más detalles sobre operadores
        </button>
      )}

      {showMore && (
        <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
          <div className="bg-gray-100 px-6 py-3 border-b-4 border-black">
            <h2 className="text-xl font-bold">🔤 Operadores Lógicos</h2>
          </div>
          <div className="p-6 grid gap-4 md:grid-cols-2">
            <OperatorExplanation
              symbol="¬"
              name="Negación (NO)"
              description="Invierte el valor de verdad"
              example="Si p es verdadero, ¬p es falso"
            />
            <OperatorExplanation
              symbol="∧"
              name="Conjunción (Y)"
              description="Verdadero solo si ambos son verdaderos"
              example="p ∧ q es V solo si p=V y q=V"
            />
            <OperatorExplanation
              symbol="∨"
              name="Disyunción (O)"
              description="Verdadero si al menos uno es verdadero"
              example="p ∨ q es F solo si ambos son F"
            />
            <OperatorExplanation
              symbol="→"
              name="Condicional (SI...ENTONCES)"
              description="Falso solo si el primero es V y el segundo F"
              example="p → q es F solo si p=V y q=F"
            />
            <OperatorExplanation
              symbol="↔"
              name="Bicondicional (SI Y SOLO SI)"
              description="Verdadero si ambos valores son iguales"
              example="p ↔ q es V si p=q (ambos V o ambos F)"
            />
          </div>
        </div>
      )}

      {/* Botón para comenzar */}
      <button
        onClick={onStart}
        className="w-full bg-black text-white border-4 border-black p-6 font-bold text-2xl 
                   shadow-[8px_8px_0px_0px_rgba(100,100,100,1)] hover:shadow-[12px_12px_0px_0px_rgba(100,100,100,1)]
                   hover:translate-x-[-4px] hover:translate-y-[-4px] transition-all duration-150"
      >
        🚀 COMENZAR A APRENDER
      </button>
    </div>
  );
}

interface StepCardProps {
  number: number;
  title: string;
  description: string;
  icon: string;
}

function StepCard({ number, title, description, icon }: StepCardProps) {
  return (
    <div className="bg-gray-50 border-2 border-gray-300 p-4">
      <div className="flex items-center gap-3 mb-2">
        <span className="w-8 h-8 bg-black text-white flex items-center justify-center font-bold">
          {number}
        </span>
        <span className="text-2xl">{icon}</span>
      </div>
      <h3 className="font-bold text-lg mb-1">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  );
}

interface OperatorExplanationProps {
  symbol: string;
  name: string;
  description: string;
  example: string;
}

function OperatorExplanation({ symbol, name, description, example }: OperatorExplanationProps) {
  return (
    <div className="border-2 border-black p-4">
      <div className="flex items-center gap-3 mb-2">
        <span className="text-4xl font-black">{symbol}</span>
        <span className="font-bold">{name}</span>
      </div>
      <p className="text-sm text-gray-700 mb-2">{description}</p>
      <p className="text-xs text-gray-500 italic">{example}</p>
    </div>
  );
}
