'use client';

import { useState, useMemo } from 'react';
import {
  Proposition,
  generateTruthTable,
  SubExpression,
} from '@/lib/truth-table/logic';
import { TruthTableDisplay } from './TruthTableDisplay';
import { CalculationPanel } from './CalculationPanel';
import { ExerciseSelector } from './ExerciseSelector';
import { PropositionEditor } from './PropositionEditor';
import { OperatorCard, OperatorOverview } from './OperatorCard';
import { Introduction } from './Introduction';
import { cn } from '@/lib/utils';

type ViewMode = 'intro' | 'simple' | 'full';

export function TruthTableApp() {
  const [viewMode, setViewMode] = useState<ViewMode>('intro');
  const [expression, setExpression] = useState<string>('p ∧ q');
  const [selectedRowId, setSelectedRowId] = useState<number | null>(null);
  const [showOperators, setShowOperators] = useState(false);

  // Generar tabla usando useMemo (valores derivados)
  const tableData = useMemo(() => {
    const result = generateTruthTable(expression);
    return result;
  }, [expression]);

  const { variables, subExpressions, rows, error } = tableData;

  const handleExerciseSelect = (proposition: Proposition) => {
    setExpression(proposition.expression);
    setSelectedRowId(null);
  };

  const handleExpressionChange = (newExpression: string) => {
    setExpression(newExpression);
    setSelectedRowId(null);
  };

  const handleStart = () => {
    setViewMode('simple');
  };

  const selectedRow = selectedRowId ? rows.find((r) => r.id === selectedRowId) || null : null;

  // Vista de introducción
  if (viewMode === 'intro') {
    return (
      <div className="min-h-screen bg-gray-100 p-4 md:p-8">
        <Introduction onStart={handleStart} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-black text-white sticky top-0 z-50 border-b-4 border-black">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl md:text-2xl font-black tracking-tight">
              📊 TABLAS DE VERDAD
            </h1>
            <div className="flex gap-2">
              <button
                onClick={() => setShowOperators(!showOperators)}
                className={cn(
                  'px-3 py-1 border-2 border-white font-bold text-sm transition-colors',
                  showOperators ? 'bg-white text-black' : 'bg-transparent hover:bg-gray-800'
                )}
              >
                📚 Operadores
              </button>
              <button
                onClick={() => setViewMode(viewMode === 'simple' ? 'full' : 'simple')}
                className="px-3 py-1 border-2 border-white font-bold text-sm hover:bg-gray-800 transition-colors"
              >
                {viewMode === 'simple' ? '📖 Vista Completa' : '🎯 Vista Simple'}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Panel de operadores (colapsable) */}
      {showOperators && (
        <div className="fixed inset-0 z-40 bg-black/50 flex items-center justify-center p-4">
          <div className="max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowOperators(false)}
              className="w-full bg-red-600 text-white border-4 border-black p-3 font-bold mb-4"
            >
              ✕ Cerrar
            </button>
            <OperatorCard />
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto p-4 md:p-6 space-y-6">
        {/* Referencia rápida de operadores */}
        <OperatorOverview />

        {/* Grid principal */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Columna izquierda: Selector y Editor */}
          <div className="space-y-6">
            <ExerciseSelector
              selectedExpression={expression}
              onSelect={handleExerciseSelect}
            />
            <PropositionEditor expression={expression} onChange={handleExpressionChange} />
          </div>

          {/* Columna derecha: Tabla y Cálculos */}
          <div className="lg:col-span-2 space-y-6">
            {/* Error */}
            {error && (
              <div className="bg-red-100 border-4 border-red-500 p-4 text-red-700 font-bold">
                ⚠️ {error}
              </div>
            )}

            {/* Tabla de verdad */}
            {!error && rows.length > 0 && (
              <TruthTableDisplay
                expression={expression}
                variables={variables}
                subExpressions={subExpressions}
                rows={rows}
                selectedRowId={selectedRowId}
                onRowSelect={setSelectedRowId}
              />
            )}

            {/* Panel de cálculos */}
            {!error && rows.length > 0 && (
              <CalculationPanel row={selectedRow} variables={variables} />
            )}
          </div>
        </div>

        {/* Explicación paso a paso de la proposición actual */}
        {!error && rows.length > 0 && (
          <PropositionExplanation 
            expression={expression} 
            variables={variables} 
            subExpressions={subExpressions}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black text-white mt-auto py-4 border-t-4 border-gray-800">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-sm text-gray-400">
            Aprende lógica proposicional de forma interactiva • Selecciona una fila para ver el cálculo detallado
          </p>
        </div>
      </footer>
    </div>
  );
}

interface PropositionExplanationProps {
  expression: string;
  variables: string[];
  subExpressions: SubExpression[];
}

function PropositionExplanation({ expression, variables, subExpressions }: PropositionExplanationProps) {
  return (
    <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
      <div className="bg-black text-white px-4 py-3 font-bold text-lg tracking-tight">
        📝 ANÁLISIS DE LA PROPOSICIÓN
      </div>
      <div className="p-4">
        {/* Expresión original */}
        <div className="mb-4">
          <h3 className="font-bold text-gray-700 mb-2">Expresión Original</h3>
          <div className="bg-gray-100 border-2 border-gray-300 p-3 font-mono text-xl font-bold">
            {expression}
          </div>
        </div>

        {/* Variables */}
        <div className="grid gap-4 md:grid-cols-2 mb-4">
          <div>
            <h3 className="font-bold text-gray-700 mb-2">Variables Identificadas</h3>
            <div className="flex flex-wrap gap-2">
              {variables.map((v) => (
                <span key={v} className="px-3 py-2 bg-blue-100 border-2 border-blue-400 font-bold text-blue-700">
                  {v}
                </span>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-bold text-gray-700 mb-2">Total de Combinaciones</h3>
            <div className="px-3 py-2 bg-purple-100 border-2 border-purple-400 font-bold text-purple-700">
              2<sup>{variables.length}</sup> = {Math.pow(2, variables.length)} filas
            </div>
          </div>
        </div>

        {/* Sub-expresiones (orden de evaluación) */}
        {subExpressions.length > 0 && (
          <div className="mb-4">
            <h3 className="font-bold text-gray-700 mb-2">📊 Orden de Evaluación (Columnas de la Tabla)</h3>
            <div className="bg-gray-50 border-2 border-gray-300 p-3">
              <div className="grid gap-2">
                {subExpressions.map((sub, idx) => (
                  <div 
                    key={sub.id} 
                    className={cn(
                      'flex items-center gap-3 p-2 border-2',
                      idx === subExpressions.length - 1 
                        ? 'bg-amber-50 border-amber-400' 
                        : 'bg-white border-gray-200'
                    )}
                  >
                    <span className={cn(
                      'w-6 h-6 flex items-center justify-center text-sm font-bold border-2',
                      idx === subExpressions.length - 1 
                        ? 'bg-amber-500 text-white border-amber-600' 
                        : 'bg-gray-200 text-gray-700 border-gray-300'
                    )}>
                      {idx + 1}
                    </span>
                    <code className="font-mono font-bold text-lg">
                      {formatExpressionDisplay(sub.expression)}
                    </code>
                    <span className="text-gray-500 text-sm">
                      → {sub.description}
                    </span>
                    {idx === subExpressions.length - 1 && (
                      <span className="ml-auto text-xs bg-amber-200 px-2 py-1 font-bold text-amber-800">
                        RESULTADO FINAL
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Información adicional */}
        <div className="bg-blue-50 border-2 border-blue-300 p-3">
          <p className="text-sm">
            <span className="font-bold text-blue-700">📌 Cómo leer la tabla:</span>
            <br />
            <span className="text-gray-700">
              La tabla muestra los valores de cada variable y luego los resultados de cada operación intermedia, 
              de izquierda a derecha, hasta llegar al resultado final.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

// Formatear expresión para mostrar (simplificar paréntesis externos)
function formatExpressionDisplay(expr: string): string {
  if (expr.startsWith('(') && expr.endsWith(')')) {
    return expr.slice(1, -1);
  }
  return expr;
}
