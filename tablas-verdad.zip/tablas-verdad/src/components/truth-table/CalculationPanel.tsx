'use client';

import { TruthTableRow, CalculationStep, formatValue, OPERATORS } from '@/lib/truth-table/logic';
import { cn } from '@/lib/utils';

interface CalculationPanelProps {
  row: TruthTableRow | null;
  variables: string[];
}

export function CalculationPanel({ row, variables }: CalculationPanelProps) {
  if (!row) {
    return (
      <div className="bg-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] h-full">
        <div className="bg-black text-white px-4 py-2 font-bold text-base tracking-tight">
          🧮 CÁLCULO PASO A PASO
        </div>
        <div className="p-6 text-center text-gray-500">
          <div className="text-5xl mb-3">👆</div>
          <p className="text-base font-medium">
            Selecciona una fila de la tabla para ver el cálculo detallado
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
      <div className="bg-black text-white px-4 py-2 font-bold text-base tracking-tight">
        🧮 CÁLCULO PASO A PASO - Fila #{row.id}
      </div>

      {/* Valores iniciales */}
      <div className="p-3 bg-gray-50 border-b-2 border-black">
        <div className="text-xs font-bold text-gray-500 mb-2">VALORES INICIALES</div>
        <div className="flex flex-wrap gap-2">
          {variables.map((v) => (
            <div
              key={v}
              className={cn(
                'px-3 py-1.5 border-2 border-black font-bold',
                row.values[v] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              )}
            >
              <span className="text-base">{v}</span>
              <span className="text-xl ml-1">{formatValue(row.values[v])}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Pasos de cálculo */}
      <div className="p-3">
        <div className="text-xs font-bold text-gray-500 mb-2">PROCESO DE EVALUACIÓN</div>
        
        {row.intermediateSteps.length === 0 ? (
          <div className="text-center py-3 text-gray-500">
            Esta proposición es una variable simple, no requiere operaciones.
          </div>
        ) : (
          <div className="space-y-2">
            {row.intermediateSteps.map((step, idx) => (
              <CalculationStepCard key={step.id} step={step} stepNumber={idx + 1} />
            ))}
          </div>
        )}

        {/* Resultado final */}
        <div className="mt-4 border-2 border-black">
          <div className={cn(
            'px-4 py-3',
            row.finalResult ? 'bg-green-100' : 'bg-red-100'
          )}>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-gray-500">RESULTADO FINAL</div>
                <div className={cn(
                  'text-xl font-black',
                  row.finalResult ? 'text-green-700' : 'text-red-700'
                )}>
                  {formatValue(row.finalResult)}
                </div>
              </div>
              <div className={cn(
                'text-4xl font-black',
                row.finalResult ? 'text-green-600' : 'text-red-600'
              )}>
                {row.finalResult ? '✓' : '✗'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface CalculationStepCardProps {
  step: CalculationStep;
  stepNumber: number;
}

function CalculationStepCard({ step, stepNumber }: CalculationStepCardProps) {
  const isUnary = step.inputs.length === 1;

  return (
    <div className="border-2 border-black bg-white">
      {/* Paso número */}
      <div className="bg-black text-white px-3 py-1 text-xs font-bold flex items-center justify-between">
        <span>PASO {stepNumber}</span>
        <span className="font-mono">{step.expression}</span>
      </div>
      
      <div className="p-3">
        {/* Operador */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl font-black">{step.operator}</span>
          <span className="font-bold text-gray-600 text-sm">{step.operatorName}</span>
        </div>

        {/* Operación visual */}
        <div className="bg-gray-50 border border-gray-300 p-2 mb-2">
          <div className="flex items-center justify-center gap-3 text-lg font-bold">
            {isUnary ? (
              <>
                <span className="text-gray-500">{step.operator}</span>
                <ValueDisplay value={step.inputs[0].value} label={step.inputs[0].name} />
                <span className="text-gray-400">=</span>
                <ValueDisplay value={step.result} label="Resultado" highlight />
              </>
            ) : (
              <>
                <ValueDisplay value={step.inputs[0].value} label={step.inputs[0].name} />
                <span className="text-gray-500">{step.operator}</span>
                <ValueDisplay value={step.inputs[1]!.value} label={step.inputs[1]!.name} />
                <span className="text-gray-400">=</span>
                <ValueDisplay value={step.result} label="Resultado" highlight />
              </>
            )}
          </div>
        </div>

        {/* Explicación detallada */}
        <div className="bg-amber-50 border border-amber-300 p-2">
          <div className="flex items-start gap-2">
            <span className="text-lg">💡</span>
            <div>
              <div className="font-bold text-amber-700 text-xs mb-0.5">¿Por qué?</div>
              <p className="text-xs text-gray-700">{step.explanation}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface ValueDisplayProps {
  value: boolean;
  label: string;
  highlight?: boolean;
}

function ValueDisplay({ value, label, highlight }: ValueDisplayProps) {
  return (
    <div className={cn(
      'px-2 py-0.5 border font-bold',
      value ? 'border-green-600 text-green-700' : 'border-red-600 text-red-700',
      highlight && value && 'bg-green-100',
      highlight && !value && 'bg-red-100'
    )}>
      <span className="text-xs block text-gray-500">{label}</span>
      <span className="text-lg">{formatValue(value)}</span>
    </div>
  );
}
