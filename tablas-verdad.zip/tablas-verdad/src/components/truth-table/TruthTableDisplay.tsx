'use client';

import { TruthTableRow, SubExpression, formatValue, analyzeProposition } from '@/lib/truth-table/logic';
import { cn } from '@/lib/utils';

interface TruthTableDisplayProps {
  expression: string;
  variables: string[];
  subExpressions: SubExpression[];
  rows: TruthTableRow[];
  onRowSelect?: (rowId: number) => void;
  selectedRowId?: number;
}

export function TruthTableDisplay({
  expression,
  variables,
  subExpressions,
  rows,
  onRowSelect,
  selectedRowId,
}: TruthTableDisplayProps) {
  const analysis = analyzeProposition(rows);

  return (
    <div className="bg-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
      {/* Header con la expresión */}
      <div className="bg-black text-white px-4 py-3">
        <div className="text-sm font-medium text-gray-300 mb-1">PROPOSICIÓN</div>
        <div className="text-2xl font-bold tracking-tight font-mono">{expression}</div>
      </div>

      {/* Análisis de la proposición */}
      <div className={cn(
        'px-4 py-3 border-b-2 border-black',
        analysis.type === 'tautology' && 'bg-green-100',
        analysis.type === 'contradiction' && 'bg-red-100',
        analysis.type === 'contingency' && 'bg-amber-100'
      )}>
        <div className="flex items-center gap-2">
          <span className="text-2xl">
            {analysis.type === 'tautology' && '✅'}
            {analysis.type === 'contradiction' && '❌'}
            {analysis.type === 'contingency' && '⚖️'}
          </span>
          <div>
            <div className={cn(
              'font-bold text-lg',
              analysis.type === 'tautology' && 'text-green-700',
              analysis.type === 'contradiction' && 'text-red-700',
              analysis.type === 'contingency' && 'text-amber-700'
            )}>
              {analysis.type === 'tautology' && 'TAUTOLOGÍA'}
              {analysis.type === 'contradiction' && 'CONTRADICCIÓN'}
              {analysis.type === 'contingency' && 'CONTINGENCIA'}
            </div>
            <p className="text-sm text-gray-600">{analysis.description}</p>
          </div>
        </div>
      </div>

      {/* Tabla completa con columnas intermedias */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              {/* Columna de número de fila */}
              <th className="px-2 py-2 text-center font-bold border-b-2 border-black border-r border-gray-300 text-sm">
                #
              </th>
              {/* Variables */}
              {variables.map((v, idx) => (
                <th
                  key={v}
                  className={cn(
                    'px-3 py-2 text-center font-bold text-lg border-b-2 border-black min-w-[50px]',
                    idx < variables.length - 1 && 'border-r border-gray-300'
                  )}
                >
                  {v}
                </th>
              ))}
              {/* Sub-expresiones intermedias */}
              {subExpressions.map((sub, idx) => {
                const isLast = idx === subExpressions.length - 1;
                return (
                  <th
                    key={sub.id}
                    className={cn(
                      'px-3 py-2 text-center font-bold border-b-2 border-black min-w-[80px]',
                      isLast ? 'bg-amber-50 text-lg' : 'text-base border-r border-gray-300'
                    )}
                    title={sub.description}
                  >
                    <div className="flex flex-col items-center">
                      <span className="font-mono">{formatExpressionDisplay(sub.expression)}</span>
                      <span className="text-xs font-normal text-gray-500 mt-0.5">{sub.description}</span>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => (
              <tr
                key={row.id}
                onClick={() => onRowSelect?.(row.id)}
                className={cn(
                  'cursor-pointer transition-all duration-150 border-b border-gray-200',
                  selectedRowId === row.id && 'bg-amber-100',
                  idx === rows.length - 1 && 'border-b-2 border-black',
                  'hover:bg-gray-50'
                )}
              >
                <td className="px-2 py-1.5 text-center font-mono text-gray-500 border-r border-gray-200 text-sm">
                  {row.id}
                </td>
                {/* Valores de variables */}
                {variables.map((v, vIdx) => (
                  <td
                    key={v}
                    className={cn(
                      'px-3 py-1.5 text-center font-bold text-lg',
                      vIdx < variables.length - 1 && 'border-r border-gray-200',
                      row.values[v] ? 'text-green-600' : 'text-red-600'
                    )}
                  >
                    {formatValue(row.values[v])}
                  </td>
                ))}
                {/* Valores de sub-expresiones */}
                {subExpressions.map((sub, subIdx) => {
                  const value = row.intermediateValues[sub.expression];
                  const isLast = subIdx === subExpressions.length - 1;
                  return (
                    <td
                      key={sub.id}
                      className={cn(
                        'px-3 py-1.5 text-center font-bold',
                        isLast ? 'text-lg' : 'text-base border-r border-gray-200',
                        value ? 'text-green-600' : 'text-red-600',
                        isLast && selectedRowId === row.id && 'bg-amber-200',
                        isLast && selectedRowId !== row.id && (value ? 'bg-green-50' : 'bg-red-50')
                      )}
                    >
                      {formatValue(value)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Leyenda */}
      <div className="px-4 py-2 bg-gray-50 border-t-2 border-black">
        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 bg-green-100 border border-green-600 flex items-center justify-center font-bold text-green-600 text-xs">
              V
            </span>
            <span className="font-medium text-gray-600">Verdadero</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 bg-red-100 border border-red-600 flex items-center justify-center font-bold text-red-600 text-xs">
              F
            </span>
            <span className="font-medium text-gray-600">Falso</span>
          </div>
          <div className="flex items-center gap-2 ml-auto text-gray-500 text-xs">
            👆 Clic en una fila para ver el cálculo detallado
          </div>
        </div>
      </div>
    </div>
  );
}

// Formatear expresión para mostrar (simplificar paréntesis externos)
function formatExpressionDisplay(expr: string): string {
  // Quitar paréntesis externos si existen
  if (expr.startsWith('(') && expr.endsWith(')')) {
    return expr.slice(1, -1);
  }
  return expr;
}
