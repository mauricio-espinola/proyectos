'use client';

import { EXERCISES, Proposition } from '@/lib/truth-table/logic';
import { cn } from '@/lib/utils';

interface ExerciseSelectorProps {
  selectedExpression: string;
  onSelect: (proposition: Proposition) => void;
}

export function ExerciseSelector({ selectedExpression, onSelect }: ExerciseSelectorProps) {
  const simpleExercises = EXERCISES.filter((e) => e.difficulty === 'simple');
  const intermediateExercises = EXERCISES.filter((e) => e.difficulty === 'intermediate');
  const advancedExercises = EXERCISES.filter((e) => e.difficulty === 'advanced');

  return (
    <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
      <div className="bg-black text-white px-4 py-3 font-bold text-lg tracking-tight">
        📋 EJERCICIOS
      </div>

      <div className="p-4 space-y-6">
        {/* Ejercicios simples */}
        <DifficultySection
          title="🟢 SIMPLE"
          description="Un solo operador"
          exercises={simpleExercises}
          selectedExpression={selectedExpression}
          onSelect={onSelect}
          color="green"
        />

        {/* Ejercicios intermedios */}
        <DifficultySection
          title="🟡 INTERMEDIO"
          description="Combinación de operadores"
          exercises={intermediateExercises}
          selectedExpression={selectedExpression}
          onSelect={onSelect}
          color="amber"
        />

        {/* Ejercicios avanzados */}
        <DifficultySection
          title="🔴 AVANZADO"
          description="Tautologías y leyes lógicas"
          exercises={advancedExercises}
          selectedExpression={selectedExpression}
          onSelect={onSelect}
          color="red"
        />
      </div>
    </div>
  );
}

interface DifficultySectionProps {
  title: string;
  description: string;
  exercises: Proposition[];
  selectedExpression: string;
  onSelect: (proposition: Proposition) => void;
  color: 'green' | 'amber' | 'red';
}

function DifficultySection({
  title,
  description,
  exercises,
  selectedExpression,
  onSelect,
  color,
}: DifficultySectionProps) {
  const colorClasses = {
    green: {
      bg: 'bg-green-100',
      border: 'border-green-400',
      text: 'text-green-700',
      selected: 'bg-green-200 border-green-600',
    },
    amber: {
      bg: 'bg-amber-100',
      border: 'border-amber-400',
      text: 'text-amber-700',
      selected: 'bg-amber-200 border-amber-600',
    },
    red: {
      bg: 'bg-red-100',
      border: 'border-red-400',
      text: 'text-red-700',
      selected: 'bg-red-200 border-red-600',
    },
  };

  return (
    <div className={cn('border-2 p-3', colorClasses[color].border, colorClasses[color].bg)}>
      <div className="flex items-center justify-between mb-2">
        <h3 className={cn('font-bold', colorClasses[color].text)}>{title}</h3>
        <span className="text-xs text-gray-500">{description}</span>
      </div>

      <div className="flex flex-wrap gap-2">
        {exercises.map((exercise) => (
          <button
            key={exercise.expression}
            onClick={() => onSelect(exercise)}
            className={cn(
              'px-3 py-2 border-2 border-black font-mono text-sm font-bold transition-all duration-150 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]',
              selectedExpression === exercise.expression
                ? `${colorClasses[color].selected} shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`
                : 'bg-white hover:bg-gray-50'
            )}
          >
            {exercise.expression}
          </button>
        ))}
      </div>
    </div>
  );
}
