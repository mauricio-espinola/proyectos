'use client';

import { useState } from 'react';
import { OPERATORS, formatValue } from '@/lib/truth-table/logic';
import { cn } from '@/lib/utils';

interface OperatorCardProps {
  symbol?: string;
  expanded?: boolean;
  onToggle?: () => void;
}

export function OperatorCard({ symbol, expanded = false, onToggle }: OperatorCardProps) {
  const [selectedOperator, setSelectedOperator] = useState<string | null>(symbol || null);

  const operators = Object.values(OPERATORS);
  const currentOp = selectedOperator ? OPERATORS[selectedOperator] : null;

  return (
    <div className="bg-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
      <div className="bg-black text-white px-4 py-2 font-bold text-base tracking-tight">
        📚 OPERADORES LÓGICOS
      </div>
      
      <div className="p-3">
        {/* Selector de operadores */}
        <div className="flex flex-wrap gap-2 mb-3">
          {operators.map((op) => (
            <button
              key={op.symbol}
              onClick={() => setSelectedOperator(op.symbol)}
              className={cn(
                'px-3 py-1.5 text-xl font-bold border-2 border-black transition-all duration-150',
                selectedOperator === op.symbol
                  ? 'bg-black text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,0.3)]'
                  : 'bg-white text-black hover:bg-gray-100 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
              )}
            >
              {op.symbol}
            </button>
          ))}
        </div>

        {/* Detalle del operador seleccionado */}
        {currentOp && (
          <div className="border-2 border-black p-3 bg-gray-50">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-4xl font-black">{currentOp.symbol}</span>
              <div>
                <h3 className="text-lg font-bold text-black">{currentOp.name}</h3>
              </div>
            </div>

            <p className="text-base mb-3 font-medium text-gray-700 leading-relaxed">
              {currentOp.description}
            </p>

            {/* Tabla de verdad del operador */}
            <div className="bg-white border-2 border-black mb-3">
              <div className="bg-black text-white px-3 py-1 text-xs font-bold">
                TABLA DE VERDAD
              </div>
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b-2 border-black">
                    <th className="px-3 py-1.5 text-center font-bold border-r border-gray-300">A</th>
                    {currentOp.truthTable[0].B !== undefined && (
                      <th className="px-3 py-1.5 text-center font-bold border-r border-gray-300">B</th>
                    )}
                    <th className="px-3 py-1.5 text-center font-bold">
                      {currentOp.symbol}
                      {currentOp.truthTable[0].B !== undefined ? '(A,B)' : '(A)'}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {currentOp.truthTable.map((row, idx) => (
                    <tr key={idx} className={idx < currentOp.truthTable.length - 1 ? 'border-b border-gray-200' : ''}>
                      <td className={cn(
                        'px-3 py-1 text-center font-bold text-lg border-r border-gray-300',
                        row.A ? 'text-green-600' : 'text-red-600'
                      )}>
                        {formatValue(row.A)}
                      </td>
                      {row.B !== undefined && (
                        <td className={cn(
                          'px-3 py-1 text-center font-bold text-lg border-r border-gray-300',
                          row.B ? 'text-green-600' : 'text-red-600'
                        )}>
                          {formatValue(row.B)}
                        </td>
                      )}
                      <td className={cn(
                        'px-3 py-1 text-center font-bold text-lg',
                        row.result ? 'text-green-600' : 'text-red-600'
                      )}>
                        {formatValue(row.result)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Ejemplo */}
            <div className="bg-amber-50 border-2 border-amber-400 p-2">
              <div className="flex items-start gap-2">
                <span className="text-xl">💡</span>
                <p className="text-sm font-medium text-gray-700">
                  <span className="font-bold text-amber-700">Ejemplo: </span>
                  {currentOp.example}
                </p>
              </div>
            </div>
          </div>
        )}

        {!selectedOperator && (
          <div className="text-center py-6 text-gray-500 font-medium">
            Selecciona un operador para ver su definición
          </div>
        )}
      </div>
    </div>
  );
}

// Versión compacta para mostrar todos los operadores
export function OperatorOverview() {
  const operators = Object.values(OPERATORS);

  return (
    <div className="bg-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
      <div className="bg-black text-white px-4 py-2 font-bold text-base tracking-tight">
        📖 REFERENCIA RÁPIDA DE OPERADORES
      </div>
      
      <div className="p-3 grid grid-cols-5 gap-2">
        {operators.map((op) => (
          <div key={op.symbol} className="border-2 border-black p-2 bg-gray-50">
            <div className="text-center mb-1">
              <span className="text-2xl font-black">{op.symbol}</span>
            </div>
            <div className="text-center text-xs font-bold mb-0.5">{op.name.split('(')[0].trim()}</div>
            <div className="text-xs text-gray-600 text-center">
              {op.symbol === '¬' && 'NO'}
              {op.symbol === '∧' && 'Y'}
              {op.symbol === '∨' && 'O'}
              {op.symbol === '→' && 'SI...ENTONCES'}
              {op.symbol === '↔' && 'SI Y SOLO SI'}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
