'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';

interface PropositionEditorProps {
  expression: string;
  onChange: (expression: string) => void;
}

const OPERATOR_BUTTONS = [
  { symbol: '¬', label: 'NO', description: 'Negación' },
  { symbol: '∧', label: 'Y', description: 'Conjunción' },
  { symbol: '∨', label: 'O', description: 'Disyunción' },
  { symbol: '→', label: '→', description: 'Condicional' },
  { symbol: '↔', label: '↔', description: 'Bicondicional' },
];

const VARIABLE_BUTTONS = ['p', 'q', 'r', 's', 't'];

export function PropositionEditor({ expression, onChange }: PropositionEditorProps) {
  const [isFocused, setIsFocused] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
  };

  const insertSymbol = (symbol: string) => {
    onChange(expression + symbol);
  };

  const insertVariable = (variable: string) => {
    onChange(expression + variable);
  };

  const clearExpression = () => {
    onChange('');
  };

  const addParenthesis = (type: 'open' | 'close') => {
    onChange(expression + (type === 'open' ? '(' : ')'));
  };

  return (
    <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
      <div className="bg-black text-white px-4 py-3 font-bold text-lg tracking-tight">
        ✏️ EDITOR DE PROPOSICIÓN
      </div>

      <div className="p-4 space-y-4">
        {/* Input de expresión */}
        <div>
          <label className="text-sm font-bold text-gray-500 block mb-2">
            Escribe o modifica la proposición:
          </label>
          <input
            type="text"
            value={expression}
            onChange={handleInputChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            placeholder="Ejemplo: p ∧ q"
            className={cn(
              'w-full px-4 py-3 text-2xl font-mono font-bold border-4 border-black',
              'focus:outline-none transition-all duration-150',
              isFocused ? 'bg-amber-50' : 'bg-gray-50'
            )}
          />
        </div>

        {/* Botones de variables */}
        <div>
          <div className="text-xs font-bold text-gray-500 mb-2">VARIABLES</div>
          <div className="flex flex-wrap gap-2">
            {VARIABLE_BUTTONS.map((v) => (
              <button
                key={v}
                onClick={() => insertVariable(v)}
                className="px-4 py-2 bg-blue-100 border-2 border-blue-400 font-bold text-blue-700 hover:bg-blue-200 transition-colors"
              >
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* Botones de operadores */}
        <div>
          <div className="text-xs font-bold text-gray-500 mb-2">OPERADORES</div>
          <div className="flex flex-wrap gap-2">
            {OPERATOR_BUTTONS.map((op) => (
              <button
                key={op.symbol}
                onClick={() => insertSymbol(op.symbol)}
                className="px-4 py-2 bg-purple-100 border-2 border-purple-400 font-bold text-purple-700 hover:bg-purple-200 transition-colors text-xl"
                title={op.description}
              >
                {op.symbol}
              </button>
            ))}
          </div>
        </div>

        {/* Botones de paréntesis */}
        <div>
          <div className="text-xs font-bold text-gray-500 mb-2">AGRUPACIÓN</div>
          <div className="flex gap-2">
            <button
              onClick={() => addParenthesis('open')}
              className="px-4 py-2 bg-gray-100 border-2 border-gray-400 font-bold text-gray-700 hover:bg-gray-200 transition-colors text-xl"
            >
              (
            </button>
            <button
              onClick={() => addParenthesis('close')}
              className="px-4 py-2 bg-gray-100 border-2 border-gray-400 font-bold text-gray-700 hover:bg-gray-200 transition-colors text-xl"
            >
              )
            </button>
            <button
              onClick={() => insertSymbol(' ')}
              className="px-4 py-2 bg-gray-100 border-2 border-gray-400 font-bold text-gray-700 hover:bg-gray-200 transition-colors"
            >
              ESPACIO
            </button>
          </div>
        </div>

        {/* Botones de acción */}
        <div className="flex gap-2 pt-2">
          <button
            onClick={clearExpression}
            className="px-4 py-2 bg-red-100 border-2 border-red-400 font-bold text-red-700 hover:bg-red-200 transition-colors"
          >
            🗑️ Borrar todo
          </button>
          <button
            onClick={() => onChange(expression.slice(0, -1))}
            className="px-4 py-2 bg-orange-100 border-2 border-orange-400 font-bold text-orange-700 hover:bg-orange-200 transition-colors"
          >
            ← Borrar último
          </button>
        </div>

        {/* Ayuda */}
        <div className="bg-gray-50 border-2 border-gray-300 p-3 text-sm">
          <div className="font-bold text-gray-600 mb-2">📝 SINTAXIS</div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div><span className="font-mono bg-gray-200 px-1">¬p</span> = NO p</div>
            <div><span className="font-mono bg-gray-200 px-1">p ∧ q</span> = p Y q</div>
            <div><span className="font-mono bg-gray-200 px-1">p ∨ q</span> = p O q</div>
            <div><span className="font-mono bg-gray-200 px-1">p → q</span> = SI p ENTONCES q</div>
            <div><span className="font-mono bg-gray-200 px-1">p ↔ q</span> = p SI Y SOLO SI q</div>
            <div><span className="font-mono bg-gray-200 px-1">( )</span> = Agrupación</div>
          </div>
        </div>
      </div>
    </div>
  );
}
