import { TruthTableApp } from '@/components/truth-table';

export default function Home() {
  return <TruthTableApp />;
}
