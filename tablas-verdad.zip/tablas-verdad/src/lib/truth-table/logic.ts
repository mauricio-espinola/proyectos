// Definiciones de operadores lógicos
export interface Operator {
  symbol: string;
  name: string;
  description: string;
  truthTable: { A: boolean; B?: boolean; result: boolean }[];
  example: string;
  precedence: number;
}

export const OPERATORS: Record<string, Operator> = {
  '¬': {
    symbol: '¬',
    name: 'Negación (NO)',
    description: 'Invierte el valor de verdad. Si A es verdadero, ¬A es falso, y viceversa.',
    truthTable: [
      { A: true, result: false },
      { A: false, result: true },
    ],
    example: 'Si "llueve" es verdadero, entonces "no llueve" (¬llueve) es falso.',
    precedence: 4,
  },
  '∧': {
    symbol: '∧',
    name: 'Conjunción (Y)',
    description: 'Solo es verdadero cuando AMBOS valores son verdaderos. Como una intersección.',
    truthTable: [
      { A: true, B: true, result: true },
      { A: true, B: false, result: false },
      { A: false, B: true, result: false },
      { A: false, B: false, result: false },
    ],
    example: '"Está soleado Y hace calor" - solo verdadero si ambos son ciertos.',
    precedence: 3,
  },
  '∨': {
    symbol: '∨',
    name: 'Disyunción (O)',
    description: 'Es verdadero cuando AL MENOS UNO de los valores es verdadero. Como una unión.',
    truthTable: [
      { A: true, B: true, result: true },
      { A: true, B: false, result: true },
      { A: false, B: true, result: true },
      { A: false, B: false, result: false },
    ],
    example: '"Comeré pizza O pasta" - verdadero si como cualquiera de los dos.',
    precedence: 2,
  },
  '→': {
    symbol: '→',
    name: 'Condicional (SI...ENTONCES)',
    description: 'Solo es falso cuando el antecedente es verdadero y el consecuente es falso.',
    truthTable: [
      { A: true, B: true, result: true },
      { A: true, B: false, result: false },
      { A: false, B: true, result: true },
      { A: false, B: false, result: true },
    ],
    example: '"Si llueve, entonces llevo paraguas" - solo miento si llueve y no llevo paraguas.',
    precedence: 1,
  },
  '↔': {
    symbol: '↔',
    name: 'Bicondicional (SI Y SOLO SI)',
    description: 'Es verdadero cuando ambos valores son iguales (ambos verdaderos o ambos falsos).',
    truthTable: [
      { A: true, B: true, result: true },
      { A: true, B: false, result: false },
      { A: false, B: true, result: false },
      { A: false, B: false, result: true },
    ],
    example: '"Un número es par si y solo si es divisible por 2" - equivalencia completa.',
    precedence: 0,
  },
};

// Variables proposicionales
export interface Variable {
  name: string;
  description: string;
}

// Token para el parser
export interface Token {
  type: 'variable' | 'operator' | 'parenthesis';
  value: string;
}

// Nodo del árbol de expresión
export interface ExpressionNode {
  type: 'variable' | 'unary' | 'binary';
  value?: string;
  operator?: string;
  left?: ExpressionNode;
  right?: ExpressionNode;
}

// Sub-expresión para mostrar en columnas
export interface SubExpression {
  id: string;
  expression: string;
  description: string;
  order: number; // Orden de evaluación
}

// Paso de cálculo detallado
export interface CalculationStep {
  id: string;
  expression: string;
  description: string;
  operator: string;
  operatorName: string;
  inputs: { name: string; value: boolean }[];
  result: boolean;
  explanation: string;
}

// Fila de la tabla de verdad con valores intermedios
export interface TruthTableRow {
  id: number;
  values: Record<string, boolean>; // Variables
  intermediateValues: Record<string, boolean>; // Sub-expresiones -> valor
  intermediateSteps: CalculationStep[];
  finalResult: boolean;
}

// Proposición completa
export interface Proposition {
  expression: string;
  variables: string[];
  description: string;
  difficulty: 'simple' | 'intermediate' | 'advanced';
}

// Resultado del análisis de tabla
export interface TruthTableResult {
  variables: string[];
  subExpressions: SubExpression[];
  rows: TruthTableRow[];
  parseTree: ExpressionNode | null;
  error?: string;
}

// Ejercicios predefinidos
export const EXERCISES: Proposition[] = [
  {
    expression: 'p ∧ q',
    variables: ['p', 'q'],
    description: 'Conjunción simple: p Y q',
    difficulty: 'simple',
  },
  {
    expression: 'p ∨ q',
    variables: ['p', 'q'],
    description: 'Disyunción simple: p O q',
    difficulty: 'simple',
  },
  {
    expression: '¬p',
    variables: ['p'],
    description: 'Negación simple: NO p',
    difficulty: 'simple',
  },
  {
    expression: 'p → q',
    variables: ['p', 'q'],
    description: 'Condicional: SI p ENTONCES q',
    difficulty: 'simple',
  },
  {
    expression: 'p ∧ ¬q',
    variables: ['p', 'q'],
    description: 'Conjunción con negación: p Y (NO q)',
    difficulty: 'intermediate',
  },
  {
    expression: '¬(p ∨ q)',
    variables: ['p', 'q'],
    description: 'Negación de disyunción: NO (p O q)',
    difficulty: 'intermediate',
  },
  {
    expression: '(p → q) ∧ (q → p)',
    variables: ['p', 'q'],
    description: 'Equivalencia de condicionales',
    difficulty: 'intermediate',
  },
  {
    expression: 'p ↔ q',
    variables: ['p', 'q'],
    description: 'Bicondicional: p SI Y SOLO SI q',
    difficulty: 'intermediate',
  },
  {
    expression: '(p ∨ q) ∧ ¬(p ∧ q)',
    variables: ['p', 'q'],
    description: 'Disyunción exclusiva (XOR): p O q pero no ambos',
    difficulty: 'advanced',
  },
  {
    expression: '(p → q) ∧ (q → r) → (p → r)',
    variables: ['p', 'q', 'r'],
    description: 'Silogismo hipotético',
    difficulty: 'advanced',
  },
  {
    expression: '¬(p ∧ q) ↔ (¬p ∨ ¬q)',
    variables: ['p', 'q'],
    description: 'Ley de De Morgan',
    difficulty: 'advanced',
  },
  {
    expression: '(p → q) ↔ (¬q → ¬p)',
    variables: ['p', 'q'],
    description: 'Contrarrecíproco',
    difficulty: 'advanced',
  },
];

// Función para tokenizar la expresión
export function tokenize(expression: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const cleanExpr = expression.replace(/\s+/g, '');

  while (i < cleanExpr.length) {
    const char = cleanExpr[i];

    // Variables (letras minúsculas o mayúsculas)
    if (/[a-zA-Z]/.test(char)) {
      tokens.push({ type: 'variable', value: char });
      i++;
    }
    // Operadores
    else if (['¬', '∧', '∨', '→', '↔'].includes(char)) {
      tokens.push({ type: 'operator', value: char });
      i++;
    }
    // Paréntesis
    else if (['(', ')'].includes(char)) {
      tokens.push({ type: 'parenthesis', value: char });
      i++;
    }
    else {
      i++;
    }
  }

  return tokens;
}

// Función para parsear la expresión (convertir a árbol)
export function parse(tokens: Token[]): ExpressionNode | null {
  let pos = 0;

  function parseBiconditional(): ExpressionNode | null {
    let left = parseConditional();
    if (!left) return null;

    while (pos < tokens.length && tokens[pos].value === '↔') {
      const op = tokens[pos].value;
      pos++;
      const right = parseConditional();
      if (right) {
        left = { type: 'binary', operator: op, left, right };
      }
    }
    return left;
  }

  function parseConditional(): ExpressionNode | null {
    let left = parseOr();
    if (!left) return null;

    while (pos < tokens.length && tokens[pos].value === '→') {
      const op = tokens[pos].value;
      pos++;
      const right = parseOr();
      if (right) {
        left = { type: 'binary', operator: op, left, right };
      }
    }
    return left;
  }

  function parseOr(): ExpressionNode | null {
    let left = parseAnd();
    if (!left) return null;

    while (pos < tokens.length && tokens[pos].value === '∨') {
      const op = tokens[pos].value;
      pos++;
      const right = parseAnd();
      if (right) {
        left = { type: 'binary', operator: op, left, right };
      }
    }
    return left;
  }

  function parseAnd(): ExpressionNode | null {
    let left = parseNot();
    if (!left) return null;

    while (pos < tokens.length && tokens[pos].value === '∧') {
      const op = tokens[pos].value;
      pos++;
      const right = parseNot();
      if (right) {
        left = { type: 'binary', operator: op, left, right };
      }
    }
    return left;
  }

  function parseNot(): ExpressionNode | null {
    if (pos < tokens.length && tokens[pos].value === '¬') {
      pos++;
      const operand = parseNot();
      return { type: 'unary', operator: '¬', left: operand || undefined };
    }
    return parsePrimary();
  }

  function parsePrimary(): ExpressionNode | null {
    if (pos >= tokens.length) return null;

    const token = tokens[pos];

    if (token.type === 'variable') {
      pos++;
      return { type: 'variable', value: token.value };
    }

    if (token.value === '(') {
      pos++;
      const node = parseBiconditional();
      if (pos < tokens.length && tokens[pos].value === ')') {
        pos++;
      }
      return node;
    }

    return null;
  }

  return parseBiconditional();
}

// Convertir nodo a string (para mostrar sub-expresiones)
export function nodeToString(node: ExpressionNode | null): string {
  if (!node) return '';
  
  if (node.type === 'variable') {
    return node.value!;
  }
  
  if (node.type === 'unary') {
    const operand = nodeToString(node.left);
    return `${node.operator}${operand}`;
  }
  
  if (node.type === 'binary') {
    const left = nodeToString(node.left);
    const right = nodeToString(node.right);
    // Agregar paréntesis para claridad
    return `(${left} ${node.operator} ${right})`;
  }
  
  return '';
}

// Extraer todas las sub-expresiones del árbol (en orden de evaluación)
export function extractSubExpressions(node: ExpressionNode | null): SubExpression[] {
  const subExprs: SubExpression[] = [];
  let order = 0;
  
  function traverse(n: ExpressionNode | null): string {
    if (!n) return '';
    
    if (n.type === 'variable') {
      return n.value!;
    }
    
    if (n.type === 'unary') {
      const operandExpr = traverse(n.left);
      const expr = `${n.operator}${operandExpr}`;
      const description = getOperatorDescription(n.operator!, operandExpr);
      
      subExprs.push({
        id: `sub-${order}`,
        expression: expr,
        description,
        order: order++,
      });
      
      return expr;
    }
    
    if (n.type === 'binary') {
      const leftExpr = traverse(n.left);
      const rightExpr = traverse(n.right);
      const expr = `(${leftExpr} ${n.operator} ${rightExpr})`;
      const description = getBinaryDescription(n.operator!, leftExpr, rightExpr);
      
      subExprs.push({
        id: `sub-${order}`,
        expression: expr,
        description,
        order: order++,
      });
      
      return expr;
    }
    
    return '';
  }
  
  traverse(node);
  return subExprs;
}

// Obtener descripción del operador
function getOperatorDescription(operator: string, operand: string): string {
  const op = OPERATORS[operator];
  if (operator === '¬') {
    return `Lo contrario de ${operand}`;
  }
  return `${op.name} de ${operand}`;
}

// Obtener descripción de operación binaria
function getBinaryDescription(operator: string, left: string, right: string): string {
  const op = OPERATORS[operator];
  const descriptions: Record<string, string> = {
    '∧': `${left} Y ${right}`,
    '∨': `${left} O ${right}`,
    '→': `SI ${left} ENTONCES ${right}`,
    '↔': `${left} SI Y SOLO SI ${right}`,
  };
  return descriptions[operator] || `${left} ${operator} ${right}`;
}

// Evaluar un nodo con valores dados, guardando valores intermedios
export function evaluate(
  node: ExpressionNode,
  values: Record<string, boolean>,
  steps: CalculationStep[],
  intermediateValues: Record<string, boolean>
): boolean {
  if (node.type === 'variable') {
    return values[node.value!];
  }

  if (node.type === 'unary') {
    const operandValue = evaluate(node.left!, values, steps, intermediateValues);
    const result = !operandValue;
    const op = OPERATORS['¬'];
    const operandStr = nodeToString(node.left);
    const exprStr = `${node.operator}${operandStr}`;
    const description = `Lo contrario de ${operandStr}`;

    steps.push({
      id: exprStr,
      expression: exprStr,
      description: `Negación de ${formatValue(operandValue)}`,
      operator: '¬',
      operatorName: op.name,
      inputs: [{ name: operandStr, value: operandValue }],
      result,
      explanation: `${operandStr} es ${formatValue(operandValue)}, entonces ¬${operandStr} es ${formatValue(result)}`,
    });

    intermediateValues[exprStr] = result;
    return result;
  }

  if (node.type === 'binary') {
    const leftValue = evaluate(node.left!, values, steps, intermediateValues);
    const rightValue = evaluate(node.right!, values, steps, intermediateValues);
    const op = OPERATORS[node.operator!];

    let result: boolean;
    switch (node.operator) {
      case '∧':
        result = leftValue && rightValue;
        break;
      case '∨':
        result = leftValue || rightValue;
        break;
      case '→':
        result = !leftValue || rightValue;
        break;
      case '↔':
        result = leftValue === rightValue;
        break;
      default:
        result = false;
    }

    const leftStr = nodeToString(node.left);
    const rightStr = nodeToString(node.right);
    const exprStr = `(${leftStr} ${node.operator} ${rightStr})`;

    steps.push({
      id: exprStr,
      expression: exprStr,
      description: `${formatValue(leftValue)} ${node.operator} ${formatValue(rightValue)}`,
      operator: node.operator!,
      operatorName: op.name,
      inputs: [
        { name: leftStr, value: leftValue },
        { name: rightStr, value: rightValue },
      ],
      result,
      explanation: `${leftStr}=${formatValue(leftValue)}, ${rightStr}=${formatValue(rightValue)} → ${formatValue(result)}`,
    });

    intermediateValues[exprStr] = result;
    return result;
  }

  return false;
}

// Formatear valor booleano
export function formatValue(value: boolean): string {
  return value ? 'V' : 'F';
}

// Extraer variables de la expresión
export function extractVariables(expression: string): string[] {
  const variables = new Set<string>();
  const tokens = tokenize(expression);

  for (const token of tokens) {
    if (token.type === 'variable') {
      variables.add(token.value);
    }
  }

  return Array.from(variables).sort();
}

// Generar todas las combinaciones de valores
export function generateCombinations(variables: string[]): Record<string, boolean>[] {
  const n = variables.length;
  const combinations: Record<string, boolean>[] = [];

  for (let i = 0; i < Math.pow(2, n); i++) {
    const combo: Record<string, boolean> = {};
    for (let j = 0; j < n; j++) {
      combo[variables[j]] = Boolean((i >> (n - 1 - j)) & 1);
    }
    combinations.push(combo);
  }

  return combinations;
}

// Generar la tabla de verdad completa con columnas intermedias
export function generateTruthTable(expression: string): TruthTableResult {
  try {
    const tokens = tokenize(expression);
    const parseTree = parse(tokens);
    const variables = extractVariables(expression);

    if (!parseTree) {
      return { variables: [], subExpressions: [], rows: [], parseTree: null, error: 'Expresión inválida' };
    }

    // Extraer sub-expresiones
    const subExpressions = extractSubExpressions(parseTree);
    
    const combinations = generateCombinations(variables);
    const rows: TruthTableRow[] = combinations.map((values, index) => {
      const steps: CalculationStep[] = [];
      const intermediateValues: Record<string, boolean> = {};
      const finalResult = evaluate(parseTree, values, steps, intermediateValues);

      return {
        id: index + 1,
        values,
        intermediateValues,
        intermediateSteps: steps,
        finalResult,
      };
    });

    return { variables, subExpressions, rows, parseTree };
  } catch (error) {
    return {
      variables: [],
      subExpressions: [],
      rows: [],
      parseTree: null,
      error: 'Error al procesar la expresión',
    };
  }
}

// Verificar si la proposición es tautología, contradicción o contingencia
export function analyzeProposition(rows: TruthTableRow[]): {
  type: 'tautology' | 'contradiction' | 'contingency';
  description: string;
} {
  const allTrue = rows.every((row) => row.finalResult);
  const allFalse = rows.every((row) => !row.finalResult);

  if (allTrue) {
    return {
      type: 'tautology',
      description: 'Tautología: La proposición siempre es verdadera, independientemente de los valores de las variables.',
    };
  }
  if (allFalse) {
    return {
      type: 'contradiction',
      description: 'Contradicción: La proposición siempre es falsa, independientemente de los valores de las variables.',
    };
  }
  return {
    type: 'contingency',
    description: 'Contingencia: La proposición puede ser verdadera o falsa dependiendo de los valores de las variables.',
  };
}
