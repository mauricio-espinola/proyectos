import { db } from '../src/lib/db';
import bcrypt from 'bcryptjs';

async function createAdmin() {
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  try {
    const user = await db.user.create({
      data: {
        id: 'admin-' + Date.now(),
        email: 'admin@copropiedad.cl',
        password: hashedPassword,
        name: 'Administrador',
        role: 'admin',
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    });
    
    console.log('Usuario administrador creado exitosamente:');
    console.log('Email: admin@copropiedad.cl');
    console.log('Password: admin123');
    console.log('User ID:', user.id);
  } catch (error: any) {
    if (error.code === 'P2002') {
      console.log('El usuario ya existe. Intentando actualizar...');
      const updated = await db.user.update({
        where: { email: 'admin@copropiedad.cl' },
        data: {
          password: hashedPassword,
          role: 'admin',
          isActive: true,
        },
      });
      console.log('Usuario actualizado:', updated.email);
    } else {
      throw error;
    }
  }
  
  process.exit(0);
}

createAdmin();
