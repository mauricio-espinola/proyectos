// Tipos de bloques de contenido enriquecido

export type BlockType = 
  | 'paragraph'
  | 'heading1'
  | 'heading2'
  | 'heading3'
  | 'image'
  | 'gallery'
  | 'carousel'
  | 'video'
  | 'audio'
  | 'quote'
  | 'table'
  | 'timeline'
  | 'poll'
  | 'link'
  | 'list'
  | 'code'
  | 'divider'
  | 'callout'
  | 'embed';

// Bloque base
export interface BaseBlock {
  id: string;
  type: BlockType;
  order: number;
}

// Párrafo
export interface ParagraphBlock extends BaseBlock {
  type: 'paragraph';
  content: string;
}

// Títulos
export interface HeadingBlock extends BaseBlock {
  type: 'heading1' | 'heading2' | 'heading3';
  content: string;
}

// Imagen
export interface ImageBlock extends BaseBlock {
  type: 'image';
  url: string;
  alt: string;
  caption?: string;
  width?: number;
  height?: number;
}

// Galería de imágenes
export interface GalleryBlock extends BaseBlock {
  type: 'gallery';
  images: Array<{
    url: string;
    alt: string;
    caption?: string;
  }>;
  columns?: 2 | 3 | 4;
}

// Carrusel
export interface CarouselBlock extends BaseBlock {
  type: 'carousel';
  images: Array<{
    url: string;
    alt: string;
    caption?: string;
    link?: string;
  }>;
  autoPlay?: boolean;
  interval?: number;
}

// Video
export interface VideoBlock extends BaseBlock {
  type: 'video';
  url: string;
  platform: 'youtube' | 'vimeo' | 'custom';
  caption?: string;
}

// Audio
export interface AudioBlock extends BaseBlock {
  type: 'audio';
  url: string;
  title?: string;
  description?: string;
}

// Cita
export interface QuoteBlock extends BaseBlock {
  type: 'quote';
  content: string;
  author?: string;
  source?: string;
  style?: 'default' | 'highlighted' | 'minimal';
}

// Tabla
export interface TableBlock extends BaseBlock {
  type: 'table';
  headers: string[];
  rows: string[][];
  caption?: string;
  striped?: boolean;
  bordered?: boolean;
}

// Timeline
export interface TimelineBlock extends BaseBlock {
  type: 'timeline';
  events: Array<{
    date: string;
    title: string;
    description?: string;
    icon?: string;
  }>;
  style?: 'vertical' | 'horizontal';
}

// Encuesta/Votación
export interface PollBlock extends BaseBlock {
  type: 'poll';
  pollId: string;
  question: string;
  options: string[];
  allowMultiple?: boolean;
  endsAt?: string;
}

// Link destacado
export interface LinkBlock extends BaseBlock {
  type: 'link';
  url: string;
  title: string;
  description?: string;
  imageUrl?: string;
  style?: 'card' | 'button' | 'inline';
}

// Lista
export interface ListBlock extends BaseBlock {
  type: 'list';
  items: string[];
  ordered?: boolean;
  style?: 'default' | 'checklist' | 'steps';
}

// Código
export interface CodeBlock extends BaseBlock {
  type: 'code';
  code: string;
  language?: string;
  filename?: string;
  showLineNumbers?: boolean;
}

// Separador
export interface DividerBlock extends BaseBlock {
  type: 'divider';
  style?: 'line' | 'dots' | 'gradient';
}

// Callout (destacado)
export interface CalloutBlock extends BaseBlock {
  type: 'callout';
  content: string;
  variant?: 'info' | 'warning' | 'success' | 'error' | 'tip';
  icon?: string;
}

// Embed (contenido externo)
export interface EmbedBlock extends BaseBlock {
  type: 'embed';
  url: string;
  embedType: 'twitter' | 'instagram' | 'facebook' | 'spotify' | 'maps' | 'iframe';
  width?: number;
  height?: number;
}

// Unión de todos los tipos de bloques
export type ContentBlock = 
  | ParagraphBlock 
  | HeadingBlock 
  | ImageBlock 
  | GalleryBlock 
  | CarouselBlock 
  | VideoBlock 
  | AudioBlock 
  | QuoteBlock 
  | TableBlock 
  | TimelineBlock 
  | PollBlock 
  | LinkBlock 
  | ListBlock 
  | CodeBlock 
  | DividerBlock 
  | CalloutBlock 
  | EmbedBlock;

// Helper para crear bloques
export function createBlock(type: BlockType, data: Partial<ContentBlock>): ContentBlock {
  const id = `block-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  const base = { id, type, order: 0 };
  
  switch (type) {
    case 'paragraph':
      return { ...base, type: 'paragraph', content: (data as Partial<ParagraphBlock>).content || '' };
    case 'heading1':
    case 'heading2':
    case 'heading3':
      return { ...base, type, content: (data as Partial<HeadingBlock>).content || '' };
    case 'image':
      return { ...base, type: 'image', url: '', alt: '', ...(data as Partial<ImageBlock>) };
    case 'gallery':
      return { ...base, type: 'gallery', images: [], columns: 3, ...(data as Partial<GalleryBlock>) };
    case 'carousel':
      return { ...base, type: 'carousel', images: [], autoPlay: true, interval: 5000, ...(data as Partial<CarouselBlock>) };
    case 'video':
      return { ...base, type: 'video', url: '', platform: 'youtube', ...(data as Partial<VideoBlock>) };
    case 'audio':
      return { ...base, type: 'audio', url: '', ...(data as Partial<AudioBlock>) };
    case 'quote':
      return { ...base, type: 'quote', content: '', style: 'default', ...(data as Partial<QuoteBlock>) };
    case 'table':
      return { ...base, type: 'table', headers: [], rows: [], striped: true, ...(data as Partial<TableBlock>) };
    case 'timeline':
      return { ...base, type: 'timeline', events: [], style: 'vertical', ...(data as Partial<TimelineBlock>) };
    case 'poll':
      return { ...base, type: 'poll', pollId: '', question: '', options: [], ...(data as Partial<PollBlock>) };
    case 'link':
      return { ...base, type: 'link', url: '', title: '', style: 'card', ...(data as Partial<LinkBlock>) };
    case 'list':
      return { ...base, type: 'list', items: [], ordered: false, style: 'default', ...(data as Partial<ListBlock>) };
    case 'code':
      return { ...base, type: 'code', code: '', showLineNumbers: true, ...(data as Partial<CodeBlock>) };
    case 'divider':
      return { ...base, type: 'divider', style: 'line', ...(data as Partial<DividerBlock>) };
    case 'callout':
      return { ...base, type: 'callout', content: '', variant: 'info', ...(data as Partial<CalloutBlock>) };
    case 'embed':
      return { ...base, type: 'embed', url: '', embedType: 'iframe', ...(data as Partial<EmbedBlock>) };
    default:
      throw new Error(`Unknown block type: ${type}`);
  }
}

// Configuración de tipos de bloque para el editor
export const blockTypeConfig: Record<BlockType, { 
  label: string; 
  icon: string; 
  description: string;
  category: 'text' | 'media' | 'interactive' | 'layout';
}> = {
  paragraph: { label: 'Párrafo', icon: 'Type', description: 'Texto simple', category: 'text' },
  heading1: { label: 'Título 1', icon: 'Heading1', description: 'Título principal', category: 'text' },
  heading2: { label: 'Título 2', icon: 'Heading2', description: 'Subtítulo', category: 'text' },
  heading3: { label: 'Título 3', icon: 'Heading3', description: 'Sub-subtítulo', category: 'text' },
  image: { label: 'Imagen', icon: 'Image', description: 'Imagen individual', category: 'media' },
  gallery: { label: 'Galería', icon: 'Images', description: 'Conjunto de imágenes', category: 'media' },
  carousel: { label: 'Carrusel', icon: 'ImagePlus', description: 'Imágenes en carrusel', category: 'media' },
  video: { label: 'Video', icon: 'Video', description: 'Video de YouTube/Vimeo', category: 'media' },
  audio: { label: 'Audio', icon: 'Music', description: 'Archivo de audio', category: 'media' },
  quote: { label: 'Cita', icon: 'Quote', description: 'Cita destacada', category: 'text' },
  table: { label: 'Tabla', icon: 'Table', description: 'Tabla de datos', category: 'layout' },
  timeline: { label: 'Timeline', icon: 'Clock', description: 'Línea de tiempo', category: 'layout' },
  poll: { label: 'Encuesta', icon: 'BarChart3', description: 'Votación interactiva', category: 'interactive' },
  link: { label: 'Link', icon: 'Link', description: 'Enlace destacado', category: 'interactive' },
  list: { label: 'Lista', icon: 'List', description: 'Lista de items', category: 'text' },
  code: { label: 'Código', icon: 'Code', description: 'Bloque de código', category: 'text' },
  divider: { label: 'Separador', icon: 'Minus', description: 'Línea divisoria', category: 'layout' },
  callout: { label: 'Destacado', icon: 'AlertCircle', description: 'Mensaje destacado', category: 'text' },
  embed: { label: 'Embed', icon: 'ExternalLink', description: 'Contenido externo', category: 'media' },
};
