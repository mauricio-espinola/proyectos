import { db } from './db';
import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 10;

export interface UserSession {
  id: string;
  email: string;
  name: string;
  role: string;
  avatar?: string | null;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}

export async function createUser(
  email: string,
  password: string,
  name: string,
  role: string = 'user'
) {
  const hashedPassword = await hashPassword(password);
  
  const user = await db.user.create({
    data: {
      email,
      password: hashedPassword,
      name,
      role,
    },
  });
  
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    avatar: user.avatar,
  };
}

export async function authenticateUser(email: string, password: string): Promise<UserSession | null> {
  const user = await db.user.findUnique({
    where: { email },
  });
  
  if (!user || !user.isActive) {
    return null;
  }
  
  const isValid = await verifyPassword(password, user.password);
  
  if (!isValid) {
    return null;
  }
  
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    avatar: user.avatar,
  };
}

export async function getUserById(id: string): Promise<UserSession | null> {
  const user = await db.user.findUnique({
    where: { id },
  });
  
  if (!user || !user.isActive) {
    return null;
  }
  
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    avatar: user.avatar,
  };
}
