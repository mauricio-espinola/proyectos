import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  avatar?: string | null;
}

export interface DiagnosticCategory {
  id: string;
  name: string;
  description: string;
  order: number;
  icon: string | null;
  color: string | null;
  lawReference: string | null;
  items: DiagnosticItem[];
}

export interface DiagnosticItem {
  id: string;
  categoryId: string;
  question: string;
  description: string | null;
  order: number;
  weight: number;
  lawSource: string | null;
  lawArticle: string | null;
  lawText: string | null;
  riskText: string | null;
  adviceText: string | null;
  helpText: string | null;
}

export interface CopropietarioType {
  id: string;
  name: string;
  description: string;
  minScore: number;
  maxScore: number;
  icon: string | null;
  color: string | null;
  advice: string | null;
}

export interface DiagnosticResult {
  id: string;
  totalScore: number;
  maxScore: number;
  percentage: number;
  completedAt: string;
  copropietarioType: CopropietarioType | null;
  evaluations: {
    id: string;
    itemId: string;
    score: number;
    item: DiagnosticItem & { category: DiagnosticCategory };
  }[];
}

export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  featuredImage: string | null;
  category: string | null;
  tags: string | null;
  views: number;
  isPublished: boolean;
  isFeatured: boolean;
  publishedAt: string | null;
  createdAt: string;
  author: { id: string; name: string; avatar: string | null };
  _count?: { comments: number; ratings: number };
  avgRating?: number;
  ratingCount?: number;
}

interface AppState {
  // Auth state
  user: User | null;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;

  // Diagnostic state
  categories: DiagnosticCategory[];
  setCategories: (categories: DiagnosticCategory[]) => void;
  currentCategoryIndex: number;
  setCurrentCategoryIndex: (index: number) => void;
  evaluations: Map<string, number>;
  setEvaluation: (itemId: string, score: number) => void;
  resetEvaluations: () => void;
  diagnosticResult: DiagnosticResult | null;
  setDiagnosticResult: (result: DiagnosticResult | null) => void;

  // Posts state
  posts: Post[];
  setPosts: (posts: Post[]) => void;
  currentPost: Post | null;
  setCurrentPost: (post: Post | null) => void;

  // UI state
  isMenuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Auth
      user: null,
      isLoading: true,
      setUser: (user) => set({ user, isLoading: false }),
      setLoading: (isLoading) => set({ isLoading }),
      logout: () => set({ user: null, evaluations: new Map(), diagnosticResult: null }),

      // Diagnostic
      categories: [],
      setCategories: (categories) => set({ categories }),
      currentCategoryIndex: 0,
      setCurrentCategoryIndex: (index) => set({ currentCategoryIndex: index }),
      evaluations: new Map(),
      setEvaluation: (itemId, score) =>
        set((state) => {
          const newEvaluations = new Map(state.evaluations);
          newEvaluations.set(itemId, score);
          return { evaluations: newEvaluations };
        }),
      resetEvaluations: () => set({ evaluations: new Map(), currentCategoryIndex: 0, diagnosticResult: null }),
      diagnosticResult: null,
      setDiagnosticResult: (result) => set({ diagnosticResult: result }),

      // Posts
      posts: [],
      setPosts: (posts) => set({ posts }),
      currentPost: null,
      setCurrentPost: (post) => set({ currentPost: post }),

      // UI
      isMenuOpen: false,
      setMenuOpen: (open) => set({ isMenuOpen: open }),
      activeSection: 'home',
      setActiveSection: (section) => set({ activeSection: section }),
    }),
    {
      name: 'condominio-portal-storage',
      partialize: (state) => ({
        user: state.user,
        evaluations: Array.from(state.evaluations.entries()),
      }),
      merge: (persisted, current) => ({
        ...current,
        ...(persisted as Partial<AppState>),
        evaluations: new Map((persisted as { evaluations?: [string, number][] }).evaluations || []),
      }),
    }
  )
);
