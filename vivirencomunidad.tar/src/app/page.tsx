"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAppStore, type DiagnosticCategory, type Post } from "@/store/useAppStore";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { toast } from "sonner";
import {
  Home,
  FileText,
  Users,
  Settings,
  Menu,
  X,
  ChevronRight,
  Star,
  MessageCircle,
  Eye,
  Clock,
  Shield,
  Building2,
  Scale,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  LogOut,
  User as UserIcon,
  ChevronDown,
  Sparkles,
  TrendingUp,
  Award,
  BookOpen,
  Lightbulb,
  ArrowRight,
  Play,
  BarChart3,
  FileQuestion,
  Plus,
  Edit,
  Trash2,
  Sun,
  Moon,
  Monitor,
  GraduationCap,
  ShoppingCart,
  Search,
  MapPin,
  Phone,
  Mail,
  Download,
  DollarSign,
  Tag,
  Mic,
  Video,
  Calendar,
  Layout,
} from "lucide-react";
import { useTheme } from "next-themes";
import type { ContentBlock } from "@/types/blocks";
import BlockEditor from "@/components/admin/BlockEditor";
import BlockRenderer from "@/components/blocks/BlockRenderer";

// ==================== COMPONENTES ====================

// Auth Modal Component
function AuthModal({ mode, onClose }: { mode: "login" | "register"; onClose: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const { setUser } = useAppStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body = mode === "login" ? { email, password } : { email, password, name };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Error de autenticación");
      }

      setUser(data.user);
      toast.success(mode === "login" ? "¡Bienvenido!" : "Cuenta creada exitosamente");
      onClose();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Error de autenticación");
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        className="w-full max-w-md bg-card rounded-2xl shadow-2xl border overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative bg-gradient-to-r from-purple-500 to-violet-600 p-6 text-white">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <h2 className="text-2xl font-bold">
            {mode === "login" ? "Iniciar Sesión" : "Crear Cuenta"}
          </h2>
          <p className="text-white/80 mt-1">
            {mode === "login"
              ? "Accede a tu cuenta para continuar"
              : "Únete a nuestra comunidad"}
          </p>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {mode === "register" && (
            <div className="space-y-2">
              <Label htmlFor="name">Nombre completo</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Tu nombre"
                required
              />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tu@email.com"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Contraseña</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700"
            disabled={loading}
          >
            {loading ? "Procesando..." : mode === "login" ? "Ingresar" : "Registrarse"}
          </Button>
        </form>
      </motion.div>
    </motion.div>
  );
}

// Header Component
function Header() {
  const { user, logout, isMenuOpen, setMenuOpen } = useAppStore();
  const [authMode, setAuthMode] = useState<"login" | "register" | null>(null);
  const { theme, setTheme } = useTheme();

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    logout();
    toast.success("Sesión cerrada");
  };

  return (
    <>
      <header className="sticky top-0 z-40 glass border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <motion.div
              className="flex items-center gap-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shadow-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg gradient-text">Portal Condominios</h1>
                <p className="text-xs text-muted-foreground">Ley 21.442</p>
              </div>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-2">
              <NavLink icon={<Home className="w-4 h-4" />} label="Inicio" section="home" />
              <NavLink icon={<FileQuestion className="w-4 h-4" />} label="Diagnóstico" section="diagnostic" />
              <NavLink icon={<FileText className="w-4 h-4" />} label="Artículos" section="posts" />
              <NavLink icon={<GraduationCap className="w-4 h-4" />} label="Estudios" section="studies" />
              <NavLink icon={<Mic className="w-4 h-4" />} label="Entrevistas" section="interviews" />
              <NavLink icon={<ShoppingCart className="w-4 h-4" />} label="Marketplace" section="marketplace" />
              <NavLink icon={<Users className="w-4 h-4" />} label="Nosotros" section="about" />
            </nav>

            <div className="flex items-center gap-2">
              {/* Theme Toggle */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="hidden md:flex">
                    <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                    <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setTheme("light")}>
                    <Sun className="w-4 h-4 mr-2" /> Claro
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTheme("dark")}>
                    <Moon className="w-4 h-4 mr-2" /> Oscuro
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTheme("system")}>
                    <Monitor className="w-4 h-4 mr-2" /> Sistema
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center text-white font-medium">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <span className="hidden md:inline">{user.name}</span>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-2 py-1.5">
                      <p className="font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                      <Badge variant="secondary" className="mt-1">
                        {user.role === "admin" ? "Administrador" : "Usuario"}
                      </Badge>
                    </div>
                    <DropdownMenuSeparator />
                    {user.role === "admin" && (
                      <DropdownMenuItem onClick={() => useAppStore.getState().setActiveSection("admin")}>
                        <Settings className="w-4 h-4 mr-2" />
                        Panel Admin
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => useAppStore.getState().setActiveSection("profile")}>
                      <UserIcon className="w-4 h-4 mr-2" />
                      Mi Perfil
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                      <LogOut className="w-4 h-4 mr-2" />
                      Cerrar Sesión
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="hidden md:flex items-center gap-2">
                  <Button
                    variant="ghost"
                    onClick={() => setAuthMode("login")}
                  >
                    Ingresar
                  </Button>
                  <Button
                    onClick={() => setAuthMode("register")}
                    className="bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700"
                  >
                    Registrarse
                  </Button>
                </div>
              )}

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t"
            >
              <div className="container mx-auto px-4 py-4 space-y-2">
                <MobileNavLink label="Inicio" section="home" />
                <MobileNavLink label="Diagnóstico" section="diagnostic" />
                <MobileNavLink label="Artículos" section="posts" />
                <MobileNavLink label="Estudios" section="studies" />
                <MobileNavLink label="Entrevistas" section="interviews" />
                <MobileNavLink label="Marketplace" section="marketplace" />
                <MobileNavLink label="Nosotros" section="about" />
                {!user && (
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => { setAuthMode("login"); setMenuOpen(false); }}
                    >
                      Ingresar
                    </Button>
                    <Button
                      className="flex-1 bg-gradient-to-r from-purple-500 to-violet-600"
                      onClick={() => { setAuthMode("register"); setMenuOpen(false); }}
                    >
                      Registrarse
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Auth Modal */}
      <AnimatePresence>
        {authMode && (
          <AuthModal mode={authMode} onClose={() => setAuthMode(null)} />
        )}
      </AnimatePresence>
    </>
  );
}

function NavLink({ icon, label, section }: { icon: React.ReactNode; label: string; section: string }) {
  const { activeSection, setActiveSection } = useAppStore();
  const isActive = activeSection === section;

  return (
    <button
      onClick={() => setActiveSection(section)}
      className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-all text-sm ${
        isActive
          ? "bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400"
          : "hover:bg-muted text-muted-foreground hover:text-foreground"
      }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </button>
  );
}

function MobileNavLink({ label, section }: { label: string; section: string }) {
  const { activeSection, setActiveSection, setMenuOpen } = useAppStore();
  const isActive = activeSection === section;

  return (
    <button
      onClick={() => {
        setActiveSection(section);
        setMenuOpen(false);
      }}
      className={`w-full text-left px-4 py-3 rounded-lg transition-all ${
        isActive
          ? "bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400"
          : "hover:bg-muted"
      }`}
    >
      {label}
    </button>
  );
}

// Footer Component
function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-white">Portal Condominios</span>
            </div>
            <p className="text-sm text-gray-400">
              Tu guía completa sobre la Ley de Copropiedad Inmobiliaria 21.442 y la vida en comunidad.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-purple-400 transition-colors">Inicio</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">Diagnóstico</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">Artículos</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">Ley 21.442</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Recursos Legales</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="https://www.bcn.cl/leychile/navegar?idNorma=1174663" target="_blank" rel="noopener" className="hover:text-purple-400 transition-colors">Ley 21.442</a></li>
              <li><a href="https://www.minvu.gob.cl" target="_blank" rel="noopener" className="hover:text-purple-400 transition-colors">Minvu</a></li>
              <li><a href="https://www.dt.gob.cl" target="_blank" rel="noopener" className="hover:text-purple-400 transition-colors">Dirección del Trabajo</a></li>
              <li><a href="https://www.isl.gob.cl" target="_blank" rel="noopener" className="hover:text-purple-400 transition-colors">ISL</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Contacto</h4>
            <ul className="space-y-2 text-sm">
              <li>info@portalcondominios.cl</li>
              <li>Santiago, Chile</li>
            </ul>
          </div>
        </div>
        <Separator className="my-8 bg-gray-700" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-400">
          <p>© 2025 Portal Condominios. Todos los derechos reservados.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-purple-400 transition-colors">Términos</a>
            <a href="#" className="hover:text-purple-400 transition-colors">Privacidad</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Hero Section
function HeroSection() {
  const { user, setActiveSection } = useAppStore();

  return (
    <section className="relative overflow-hidden py-20 lg:py-32">
      {/* Background decorations */}
      <div className="absolute inset-0 hero-pattern" />
      <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Badge className="mb-6 bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
              <Sparkles className="w-3 h-3 mr-1" />
              Nueva Ley 21.442
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
              <span className="gradient-text">Conoce tus derechos</span>
              <br />
              <span className="text-foreground">como copropietario</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Portal completo sobre la Ley de Copropiedad Inmobiliaria. Evalúa tu comunidad,
              infórmate y participa activamente en la vida de tu condominio.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700 text-lg px-8"
                onClick={() => setActiveSection(user ? "diagnostic" : "home")}
              >
                {user ? (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Iniciar Diagnóstico
                  </>
                ) : (
                  <>
                    Comenzar Ahora
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8"
                onClick={() => setActiveSection("posts")}
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Ver Artículos
              </Button>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6"
          >
            {[
              { label: "Categorías de Evaluación", value: "7", icon: <BarChart3 className="w-5 h-5" /> },
              { label: "Aspectos Legales", value: "35+", icon: <Scale className="w-5 h-5" /> },
              { label: "Tipos de Vecino", value: "5", icon: <Users className="w-5 h-5" /> },
              { label: "Artículos", value: "∞", icon: <FileText className="w-5 h-5" /> },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="glass-card rounded-xl p-4"
              >
                <div className="flex items-center justify-center mb-2 text-purple-500">
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Features Section
function FeaturesSection() {
  const features = [
    {
      icon: <FileQuestion className="w-8 h-8" />,
      title: "Diagnóstico Interactivo",
      description: "Evalúa el estado de tu comunidad en 7 áreas clave: mantención, asambleas, finanzas, reglamento, seguridad, laboral y medio ambiente.",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: "Clasificación Personal",
      description: "Descubre qué tipo de copropietario eres: desde El Confiado hasta El Súper Vecino, con consejos personalizados.",
      color: "from-amber-500 to-orange-500",
    },
    {
      icon: <Scale className="w-8 h-8" />,
      title: "Base Legal Completa",
      description: "Cada pregunta tiene su fundamento legal: Ley 21.442, Código del Trabajo, Normas ISL y más.",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: <Lightbulb className="w-8 h-8" />,
      title: "Consejos Prácticos",
      description: "Recibe recomendaciones específicas para mejorar tu participación y proteger tus derechos.",
      color: "from-purple-500 to-violet-500",
    },
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <Badge variant="secondary" className="mb-4">Características</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Todo lo que necesitas saber
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Herramientas diseñadas para empoderarte como copropietario
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-all hover:-translate-y-1 border-0 bg-background/80 backdrop-blur">
                <CardHeader>
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white mb-4`}>
                    {feature.icon}
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Diagnostic Section
function DiagnosticSection() {
  const {
    user,
    categories,
    setCategories,
    currentCategoryIndex,
    setCurrentCategoryIndex,
    evaluations,
    setEvaluation,
    resetEvaluations,
    setDiagnosticResult,
    diagnosticResult,
  } = useAppStore();
  const [loading, setLoading] = useState(false);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch("/api/diagnostic/categories");
        const data = await res.json();
        setCategories(data.categories);
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };
    fetchCategories();
  }, [setCategories]);

  const currentCategory = categories[currentCategoryIndex];
  const totalCategories = categories.length;
  const progress = totalCategories > 0 ? ((currentCategoryIndex + 1) / totalCategories) * 100 : 0;

  const getCategoryItems = useCallback(() => {
    if (!currentCategory) return [];
    return currentCategory.items;
  }, [currentCategory]);

  const handleScoreChange = (itemId: string, score: number) => {
    setEvaluation(itemId, score);
  };

  const handleSubmit = async () => {
    if (!user) {
      toast.error("Debes iniciar sesión para guardar tu diagnóstico");
      return;
    }

    setLoading(true);
    try {
      const evaluationsArray = Array.from(evaluations.entries()).map(([itemId, score]) => ({
        itemId,
        score,
      }));

      const res = await fetch("/api/diagnostic/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ evaluations: evaluationsArray }),
      });

      const data = await res.json();
      setDiagnosticResult(data.result);
      setShowResult(true);
      toast.success("¡Diagnóstico completado!");
    } catch (error) {
      console.error("Error submitting diagnostic:", error);
      toast.error("Error al guardar diagnóstico");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    resetEvaluations();
    setShowResult(false);
  };

  if (!user) {
    return (
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md mx-auto text-center"
          >
            <Card className="border-0 shadow-xl">
              <CardHeader>
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-white mx-auto mb-4">
                  <Shield className="w-10 h-10" />
                </div>
                <CardTitle className="text-2xl">Acceso Requerido</CardTitle>
                <CardDescription>
                  Inicia sesión o crea una cuenta para realizar el diagnóstico de tu comunidad.
                </CardDescription>
              </CardHeader>
            </Card>
          </motion.div>
        </div>
      </section>
    );
  }

  if (showResult && diagnosticResult) {
    return <DiagnosticResultView result={diagnosticResult} onReset={handleReset} />;
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-8">
            <Badge className="mb-4" variant="secondary">
              <BarChart3 className="w-3 h-3 mr-1" />
              Diagnóstico de Comunidad
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Evalúa tu Condominio
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Responde cada pregunta basándote en la realidad de tu comunidad.
              Al finalizar, conocerás tu perfil como copropietario.
            </p>
          </div>

          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between text-sm mb-2">
              <span>Progreso</span>
              <span>{currentCategoryIndex + 1} de {totalCategories} categorías</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Category Navigation */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 mb-6">
            {categories.map((cat, i) => (
              <button
                key={cat.id}
                onClick={() => setCurrentCategoryIndex(i)}
                className={`px-3 py-2 rounded-lg transition-all text-left ${
                  i === currentCategoryIndex
                    ? "bg-gradient-to-r from-purple-500 to-violet-600 text-white"
                    : evaluations.size > 0 && cat.items.every(item => evaluations.has(item.id))
                    ? "bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400"
                    : "bg-muted hover:bg-muted/80"
                }`}
              >
                <span className="text-sm font-medium">{cat.name}</span>
              </button>
            ))}
          </div>

          {/* Current Category */}
          {currentCategory && (
            <motion.div
              key={currentCategory.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-0 shadow-lg mb-6">
                <CardHeader className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 rounded-t-lg">
                  <div className="flex items-center gap-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-white text-2xl"
                      style={{ backgroundColor: currentCategory.color || "#10B981" }}
                    >
                      {currentCategory.icon}
                    </div>
                    <div>
                      <CardTitle>{currentCategory.name}</CardTitle>
                      <CardDescription>{currentCategory.description}</CardDescription>
                    </div>
                  </div>
                  {currentCategory.lawReference && (
                    <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                      <Scale className="w-4 h-4" />
                      <span>Referencia: {currentCategory.lawReference}</span>
                    </div>
                  )}
                </CardHeader>
              </Card>

              {/* Items */}
              <div className="space-y-4">
                {getCategoryItems().map((item, i) => (
                  <DiagnosticItemCard
                    key={item.id}
                    item={item}
                    index={i + 1}
                    selectedScore={evaluations.get(item.id)}
                    onScoreChange={handleScoreChange}
                  />
                ))}
              </div>

              {/* Navigation Buttons */}
              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setCurrentCategoryIndex(Math.max(0, currentCategoryIndex - 1))}
                  disabled={currentCategoryIndex === 0}
                >
                  Anterior
                </Button>
                {currentCategoryIndex === totalCategories - 1 ? (
                  <Button
                    onClick={handleSubmit}
                    disabled={loading || evaluations.size < categories.reduce((acc, cat) => acc + cat.items.length, 0)}
                    className="bg-gradient-to-r from-purple-500 to-violet-600"
                  >
                    {loading ? "Guardando..." : "Ver Resultado"}
                  </Button>
                ) : (
                  <Button
                    onClick={() => setCurrentCategoryIndex(currentCategoryIndex + 1)}
                    className="bg-gradient-to-r from-purple-500 to-violet-600"
                  >
                    Siguiente
                  </Button>
                )}
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

function DiagnosticItemCard({
  item,
  index,
  selectedScore,
  onScoreChange,
}: {
  item: {
    id: string;
    question: string;
    description: string | null;
    lawSource: string | null;
    lawArticle: string | null;
    lawText: string | null;
    riskText: string | null;
    adviceText: string | null;
    helpText: string | null;
  };
  index: number;
  selectedScore?: number;
  onScoreChange: (itemId: string, score: number) => void;
}) {
  const [showDetails, setShowDetails] = useState(false);

  const scores = [
    { value: 0, label: "No logrado", color: "bg-red-500" },
    { value: 1, label: "Más o menos", color: "bg-yellow-500" },
    { value: 2, label: "Logrado", color: "bg-purple-500" },
  ];

  return (
    <Card className="border-0 shadow-md overflow-hidden">
      <CardContent className="p-0">
        <div className="p-4">
          <div className="flex items-start gap-4">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium shrink-0">
              {index}
            </div>
            <div className="flex-1">
              <p className="font-medium mb-2">{item.question}</p>
              {item.description && (
                <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
              )}

              {/* Score Buttons */}
              <div className="flex gap-2 flex-wrap">
                {scores.map((score) => (
                  <button
                    key={score.value}
                    onClick={() => onScoreChange(item.id, score.value)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      selectedScore === score.value
                        ? `${score.color} text-white`
                        : "bg-muted hover:bg-muted/80"
                    }`}
                  >
                    {score.label}
                  </button>
                ))}
              </div>

              {/* Help Text */}
              {item.helpText && (
                <div className="mt-3 flex items-start gap-2 text-sm text-muted-foreground">
                  <HelpCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{item.helpText}</p>
                </div>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDetails(!showDetails)}
            >
              {showDetails ? "Ocultar" : "Info"}
            </Button>
          </div>
        </div>

        {/* Expandable Details */}
        <AnimatePresence>
          {showDetails && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t bg-muted/50"
            >
              <div className="p-4 space-y-4">
                {item.lawSource && (
                  <div>
                    <div className="flex items-center gap-2 text-sm font-medium text-purple-600 dark:text-purple-400 mb-1">
                      <Scale className="w-4 h-4" />
                      Fuente Legal
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {item.lawSource} {item.lawArticle && `- ${item.lawArticle}`}
                    </p>
                    {item.lawText && (
                      <p className="text-sm mt-1 italic bg-background p-2 rounded">
                        "{item.lawText}"
                      </p>
                    )}
                  </div>
                )}
                {item.riskText && (
                  <div>
                    <div className="flex items-center gap-2 text-sm font-medium text-red-600 dark:text-red-400 mb-1">
                      <AlertTriangle className="w-4 h-4" />
                      Riesgos
                    </div>
                    <p className="text-sm text-muted-foreground">{item.riskText}</p>
                  </div>
                )}
                {item.adviceText && (
                  <div>
                    <div className="flex items-center gap-2 text-sm font-medium text-blue-600 dark:text-blue-400 mb-1">
                      <Lightbulb className="w-4 h-4" />
                      Consejo
                    </div>
                    <p className="text-sm text-muted-foreground">{item.adviceText}</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}

function DiagnosticResultView({ result, onReset }: { result: NonNullable<ReturnType<typeof useAppStore.getState>["diagnosticResult"]>; onReset: () => void }) {
  const percentage = Math.round(result.percentage);

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-4xl mx-auto"
        >
          {/* Result Card */}
          <Card className="border-0 shadow-2xl overflow-hidden">
            <div
              className="p-8 text-center text-white"
              style={{
                background: result.copropietarioType?.color
                  ? `linear-gradient(135deg, ${result.copropietarioType.color}, ${result.copropietarioType.color}99)`
                  : "linear-gradient(135deg, #10B981, #14B8A6)",
              }}
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", duration: 0.5 }}
                className="text-8xl mb-4"
              >
                {result.copropietarioType?.icon || "🎉"}
              </motion.div>
              <h2 className="text-3xl font-bold mb-2">
                {result.copropietarioType?.name || "Resultado"}
              </h2>
              <p className="text-white/90 max-w-md mx-auto">
                {result.copropietarioType?.description || "Has completado el diagnóstico."}
              </p>
            </div>

            <CardContent className="p-8">
              {/* Score Display */}
              <div className="text-center mb-8">
                <div className="relative w-40 h-40 mx-auto">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="currentColor"
                      strokeWidth="12"
                      fill="none"
                      className="text-muted"
                    />
                    <motion.circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="currentColor"
                      strokeWidth="12"
                      fill="none"
                      strokeLinecap="round"
                      className="text-purple-500"
                      initial={{ strokeDasharray: "0 440" }}
                      animate={{ strokeDasharray: `${percentage * 4.4} 440` }}
                      transition={{ duration: 1, delay: 0.5 }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div>
                      <span className="text-4xl font-bold">{percentage}</span>
                      <span className="text-xl text-muted-foreground">%</span>
                    </div>
                  </div>
                </div>
                <p className="mt-4 text-muted-foreground">
                  Puntaje: {result.totalScore.toFixed(1)} de {result.maxScore.toFixed(1)} puntos
                </p>
              </div>

              {/* Advice */}
              {result.copropietarioType?.advice && (
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-6 mb-8">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center shrink-0">
                      <Lightbulb className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Consejo Personalizado</h4>
                      <p className="text-muted-foreground">{result.copropietarioType.advice}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Category Breakdown */}
              {result.evaluations && result.evaluations.length > 0 && (
                <div className="mb-8">
                  <h4 className="font-semibold mb-4">Desglose por Categoría</h4>
                  <div className="space-y-3">
                    {(() => {
                      const categoryData = result.evaluations.reduce((acc, eval_) => {
                        const catId = eval_.item.categoryId;
                        if (!acc[catId]) {
                          acc[catId] = { category: eval_.item.category, scores: [] };
                        }
                        acc[catId].scores.push(eval_.score);
                        return acc;
                      }, {} as Record<string, { category: { name: string; icon: string | null; color: string | null }; scores: number[] }>);
                      
                      return Object.entries(categoryData).map(([catId, data]) => {
                        const avg = data.scores.reduce((a, b) => a + b, 0) / data.scores.length;
                        const percent = (avg / 2) * 100;
                        return (
                          <div key={catId} className="flex items-center gap-3">
                            <span className="text-lg">{data.category.icon}</span>
                            <span className="flex-1 text-sm">{data.category.name}</span>
                            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full bg-purple-500 rounded-full"
                                style={{ width: `${percent}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium w-12 text-right">
                              {Math.round(percent)}%
                            </span>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-4 justify-center">
                <Button variant="outline" onClick={onReset}>
                  Hacer de Nuevo
                </Button>
                <Button className="bg-gradient-to-r from-purple-500 to-violet-600">
                  Compartir Resultado
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

// Posts Section
function PostsSection() {
  const { posts, setPosts } = useAppStore();
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const res = await fetch("/api/posts?limit=20");
        const data = await res.json();
        setPosts(data.posts);
      } catch (error) {
        console.error("Error fetching posts:", error);
      }
    };
    fetchPosts();
  }, [setPosts]);

  const featuredPosts = posts.filter((p) => p.isFeatured);
  const regularPosts = posts.filter((p) => !p.isFeatured);

  if (selectedPost) {
    return (
      <PostDetailView post={selectedPost} onBack={() => setSelectedPost(null)} />
    );
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4">
              <FileText className="w-3 h-3 mr-1" />
              Artículos y Noticias
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Mantente Informado
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Artículos sobre la Ley de Copropiedad, guías prácticas y noticias relevantes para tu comunidad.
            </p>
          </div>

          {/* Featured Posts */}
          {featuredPosts.length > 0 && (
            <div className="mb-12">
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                Destacados
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                {featuredPosts.map((post, i) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card
                      className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 border-0 overflow-hidden py-0"
                      onClick={() => setSelectedPost(post)}
                    >
                      <div className="h-48 bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center">
                        <FileText className="w-16 h-16 text-white/50" />
                      </div>
                      <CardHeader>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary">{post.category}</Badge>
                          {post.isFeatured && (
                            <Badge className="bg-amber-100 text-amber-700">
                              <Star className="w-3 h-3 mr-1" />
                              Destacado
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="line-clamp-2">{post.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {post.excerpt}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>{post.author.name}</span>
                          <div className="flex items-center gap-4">
                            <span className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              {post.views}
                            </span>
                            <span className="flex items-center gap-1">
                              <MessageCircle className="w-4 h-4" />
                              {post._count?.comments || 0}
                            </span>
                            <span className="flex items-center gap-1">
                              <Star className="w-4 h-4" />
                              {post.avgRating?.toFixed(1) || "0"}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Regular Posts */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Todos los Artículos</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {regularPosts.map((post, i) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card
                    className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
                    onClick={() => setSelectedPost(post)}
                  >
                    <CardHeader>
                      <Badge variant="secondary" className="w-fit mb-2">
                        {post.category}
                      </Badge>
                      <CardTitle className="line-clamp-2 text-lg">{post.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {post.excerpt}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{post.author.name}</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {new Date(post.createdAt).toLocaleDateString("es-CL")}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {posts.length === 0 && (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No hay artículos disponibles</p>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

function PostDetailView({ post, onBack }: { post: Post; onBack: () => void }) {
  const [content, setContent] = useState(post.content);
  const [blocks, setBlocks] = useState<ContentBlock[]>([]);
  const [comments, setComments] = useState<Array<{ id: string; content: string; createdAt: string; user: { id: string; name: string; avatar: string | null } }>>([]);
  const [newComment, setNewComment] = useState("");
  const [userRating, setUserRating] = useState(0);
  const { user } = useAppStore();

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const res = await fetch(`/api/posts/${post.id}`);
        const data = await res.json();
        setContent(data.post.content);
        setBlocks(data.post.blocks ? JSON.parse(data.post.blocks) : []);
        setComments(data.post.comments || []);
      } catch (error) {
        console.error("Error fetching post:", error);
      }
    };
    fetchPost();
  }, [post.id]);

  const handleSubmitComment = async () => {
    if (!user || !newComment.trim()) return;

    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ postId: post.id, content: newComment }),
      });
      const data = await res.json();
      setComments([data.comment, ...comments]);
      setNewComment("");
      toast.success("Comentario agregado");
    } catch (error) {
      toast.error("Error al agregar comentario");
    }
  };

  const handleRate = async (rating: number) => {
    if (!user) return;

    try {
      await fetch("/api/ratings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ postId: post.id, value: rating }),
      });
      setUserRating(rating);
      toast.success("Valoración guardada");
    } catch (error) {
      toast.error("Error al guardar valoración");
    }
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          {/* Back Button */}
          <Button variant="ghost" onClick={onBack} className="mb-6">
            <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
            Volver
          </Button>

          {/* Post */}
          <Card className="border-0 shadow-lg overflow-hidden py-0">
            <div className="h-64 bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center">
              <FileText className="w-20 h-20 text-white/30" />
            </div>
            <CardHeader>
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="secondary">{post.category}</Badge>
                {post.isFeatured && (
                  <Badge className="bg-amber-100 text-amber-700">
                    <Star className="w-3 h-3 mr-1" />
                    Destacado
                  </Badge>
                )}
              </div>
              <CardTitle className="text-3xl">{post.title}</CardTitle>
              <div className="flex items-center gap-4 text-muted-foreground mt-4">
                <span className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center text-white text-sm">
                    {post.author.name.charAt(0)}
                  </div>
                  {post.author.name}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {new Date(post.createdAt).toLocaleDateString("es-CL")}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {post.views} vistas
                </span>
              </div>
            </CardHeader>
            <CardContent>
              {/* Rating */}
              <div className="flex items-center gap-2 mb-6 pb-6 border-b">
                <span className="text-sm text-muted-foreground">Califica:</span>
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => handleRate(star)}
                    className="focus:outline-none"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= (userRating || post.avgRating || 0)
                          ? "fill-amber-400 text-amber-400"
                          : "text-gray-300"
                      }`}
                    />
                  </button>
                ))}
                <span className="text-sm text-muted-foreground ml-2">
                  ({post.ratingCount || 0} valoraciones)
                </span>
              </div>

              {/* Content */}
              <div className="mb-8">
                {blocks.length > 0 ? (
                  <BlockRenderer blocks={blocks} />
                ) : (
                  <div className="prose dark:prose-invert max-w-none">
                    {content.split("\n").map((line, i) => {
                      if (line.startsWith("# ")) {
                        return (
                          <h1 key={i} className="text-3xl font-bold mt-6 mb-4">
                            {line.slice(2)}
                          </h1>
                        );
                      }
                      if (line.startsWith("## ")) {
                        return (
                          <h2 key={i} className="text-2xl font-semibold mt-6 mb-3">
                            {line.slice(3)}
                          </h2>
                        );
                      }
                      if (line.startsWith("### ")) {
                        return (
                          <h3 key={i} className="text-xl font-medium mt-4 mb-2">
                            {line.slice(4)}
                          </h3>
                        );
                      }
                      if (line.startsWith("- ")) {
                        return (
                          <li key={i} className="ml-4">
                            {line.slice(2)}
                          </li>
                        );
                      }
                      if (line.trim()) {
                        return (
                          <p key={i} className="mb-4 text-muted-foreground">
                            {line}
                          </p>
                        );
                      }
                      return null;
                    })}
                  </div>
                )}
              </div>

              {/* Comments */}
              <div className="border-t pt-6">
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Comentarios ({comments.length})
                </h3>

                {user ? (
                  <div className="flex gap-4 mb-6">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center text-white shrink-0">
                      {user.name.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Escribe un comentario..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        className="mb-2"
                      />
                      <Button onClick={handleSubmitComment} disabled={!newComment.trim()}>
                        Comentar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="text-muted-foreground mb-6">
                    Inicia sesión para comentar.
                  </p>
                )}

                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-400 to-gray-500 flex items-center justify-center text-white shrink-0">
                        {comment.user.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{comment.user.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(comment.createdAt).toLocaleDateString("es-CL")}
                          </span>
                        </div>
                        <p className="text-muted-foreground">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

// Studies Section
function StudiesSection() {
  const [studies, setStudies] = useState<Array<{
    id: string;
    title: string;
    slug: string;
    excerpt: string | null;
    content: string;
    category: string;
    tags: string | null;
    views: number;
    downloadCount: number;
    isFeatured: boolean;
    publishedAt: string | null;
    createdAt: string;
    author: { id: string; name: string; avatar: string | null };
    _count: { comments: number };
  }>>([]);
  const [selectedStudy, setSelectedStudy] = useState<typeof studies[0] | null>(null);

  useEffect(() => {
    const fetchStudies = async () => {
      try {
        const res = await fetch("/api/studies?limit=20");
        const data = await res.json();
        setStudies(data.studies || []);
      } catch (error) {
        console.error("Error fetching studies:", error);
      }
    };
    fetchStudies();
  }, []);

  const featuredStudies = studies.filter((s) => s.isFeatured);
  const regularStudies = studies.filter((s) => !s.isFeatured);

  if (selectedStudy) {
    return (
      <StudyDetailView study={selectedStudy} onBack={() => setSelectedStudy(null)} />
    );
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4">
              <GraduationCap className="w-3 h-3 mr-1" />
              Estudios y Publicaciones
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Investigación y Análisis
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Estudios, investigaciones y guías sobre copropiedad inmobiliaria,
              gestion de condominios y vida en comunidad.
            </p>
          </div>

          {/* Featured Studies */}
          {featuredStudies.length > 0 && (
            <div className="mb-12">
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                Destacados
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                {featuredStudies.map((study, i) => (
                  <motion.div
                    key={study.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card
                      className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 border-0 overflow-hidden"
                      onClick={() => setSelectedStudy(study)}
                    >
                      <div className="h-32 bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                        <GraduationCap className="w-12 h-12 text-white/50" />
                      </div>
                      <CardHeader>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary">{study.category}</Badge>
                          {study.isFeatured && (
                            <Badge className="bg-amber-100 text-amber-700">
                              <Star className="w-3 h-3 mr-1" />
                              Destacado
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="line-clamp-2">{study.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {study.excerpt}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>{study.author.name}</span>
                          <div className="flex items-center gap-4">
                            <span className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              {study.views}
                            </span>
                            <span className="flex items-center gap-1">
                              <Download className="w-4 h-4" />
                              {study.downloadCount}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Regular Studies */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Todos los Estudios</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {regularStudies.map((study, i) => (
                <motion.div
                  key={study.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card
                    className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
                    onClick={() => setSelectedStudy(study)}
                  >
                    <CardHeader>
                      <Badge variant="secondary" className="w-fit mb-2">
                        {study.category}
                      </Badge>
                      <CardTitle className="line-clamp-2 text-lg">{study.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {study.excerpt}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{study.author.name}</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {new Date(study.createdAt).toLocaleDateString("es-CL")}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {studies.length === 0 && (
            <div className="text-center py-12">
              <GraduationCap className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No hay estudios disponibles</p>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

function StudyDetailView({ study, onBack }: { study: NonNullable<ReturnType<typeof StudiesSection> extends (props: infer P) => unknown ? P extends { studies: infer S } ? S : never : never>; onBack: () => void }) {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <Button variant="ghost" onClick={onBack} className="mb-6">
            <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
            Volver
          </Button>

          <Card className="border-0 shadow-lg overflow-hidden">
            <div className="h-48 bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <GraduationCap className="w-20 h-20 text-white/30" />
            </div>
            <CardHeader>
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="secondary">{study.category}</Badge>
                {study.isFeatured && (
                  <Badge className="bg-amber-100 text-amber-700">
                    <Star className="w-3 h-3 mr-1" />
                    Destacado
                  </Badge>
                )}
              </div>
              <CardTitle className="text-3xl">{study.title}</CardTitle>
              <div className="flex items-center gap-4 text-muted-foreground mt-4">
                <span className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white text-sm">
                    {study.author.name.charAt(0)}
                  </div>
                  {study.author.name}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {new Date(study.createdAt).toLocaleDateString("es-CL")}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {study.views} vistas
                </span>
                <span className="flex items-center gap-1">
                  <Download className="w-4 h-4" />
                  {study.downloadCount} descargas
                </span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose dark:prose-invert max-w-none mb-8">
                {study.content.split("\n").map((line, i) => {
                  if (line.startsWith("# ")) {
                    return (
                      <h1 key={i} className="text-3xl font-bold mt-6 mb-4">
                        {line.slice(2)}
                      </h1>
                    );
                  }
                  if (line.startsWith("## ")) {
                    return (
                      <h2 key={i} className="text-2xl font-semibold mt-6 mb-3">
                        {line.slice(3)}
                      </h2>
                    );
                  }
                  if (line.startsWith("### ")) {
                    return (
                      <h3 key={i} className="text-xl font-medium mt-4 mb-2">
                        {line.slice(4)}
                      </h3>
                    );
                  }
                  if (line.startsWith("- ")) {
                    return (
                      <li key={i} className="ml-4">
                        {line.slice(2)}
                      </li>
                    );
                  }
                  if (line.trim()) {
                    return (
                      <p key={i} className="mb-4 text-muted-foreground">
                        {line}
                      </p>
                    );
                  }
                  return null;
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

// Marketplace Section
function MarketplaceSection() {
  const [products, setProducts] = useState<Array<{
    id: string;
    title: string;
    slug: string;
    description: string;
    price: number;
    currency: string;
    condition: string;
    location: string | null;
    contactPhone: string | null;
    contactEmail: string | null;
    isAvailable: boolean;
    isFeatured: boolean;
    createdAt: string;
    seller: { id: string; name: string; avatar: string | null };
    category: { id: string; name: string; icon: string | null; color: string | null };
    _count: { inquiries: number };
  }>>([]);
  const [categories, setCategories] = useState<Array<{ id: string; name: string; icon: string | null; color: string | null; _count: { products: number } }>>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [productsRes, categoriesRes] = await Promise.all([
          fetch(`/api/marketplace/products?limit=20${selectedCategory ? `&category=${selectedCategory}` : ""}${searchQuery ? `&search=${searchQuery}` : ""}`),
          fetch("/api/marketplace/categories"),
        ]);
        const productsData = await productsRes.json();
        const categoriesData = await categoriesRes.json();
        setProducts(productsData.products || []);
        setCategories(categoriesData.categories || []);
      } catch (error) {
        console.error("Error fetching marketplace data:", error);
      }
    };
    fetchData();
  }, [selectedCategory, searchQuery]);

  if (selectedProduct) {
    return (
      <ProductDetailView product={selectedProduct} onBack={() => setSelectedProduct(null)} />
    );
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4">
              <ShoppingCart className="w-3 h-3 mr-1" />
              Marketplace
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Compra y Venta para Condominios
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Equipamiento, maquinaria, servicios y más para tu condominio.
              Conecta con vendedores verificados.
            </p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar productos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-4 mb-6">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                !selectedCategory
                  ? "bg-gradient-to-r from-purple-500 to-violet-600 text-white"
                  : "bg-muted hover:bg-muted/80"
              }`}
            >
              Todos
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? "bg-gradient-to-r from-purple-500 to-violet-600 text-white"
                    : "bg-muted hover:bg-muted/80"
                }`}
              >
                {cat.icon} {cat.name} ({cat._count.products})
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card
                  className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 overflow-hidden"
                  onClick={() => setSelectedProduct(product)}
                >
                  <div 
                    className="h-40 flex items-center justify-center"
                    style={{ backgroundColor: product.category.color || "#6B7280" }}
                  >
                    <span className="text-6xl opacity-50">{product.category.icon}</span>
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="capitalize">
                        {product.condition}
                      </Badge>
                      {product.isFeatured && (
                        <Badge className="bg-amber-100 text-amber-700">
                          <Star className="w-3 h-3 mr-1" />
                          Destacado
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="line-clamp-2 text-lg">{product.title}</CardTitle>
                    <CardDescription className="line-clamp-2">
                      {product.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-2xl font-bold text-purple-600">
                        {product.currency === 'CLP' ? '$' : product.currency} {product.price.toLocaleString('es-CL')}
                      </span>
                      {product.location && (
                        <span className="text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {product.location}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>{product.seller.name}</span>
                      <span>{new Date(product.createdAt).toLocaleDateString("es-CL")}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {products.length === 0 && (
            <div className="text-center py-12">
              <ShoppingCart className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No hay productos disponibles</p>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

function ProductDetailView({ product, onBack }: { product: NonNullable<ReturnType<typeof MarketplaceSection> extends (props: infer P) => unknown ? P extends { products: infer S } ? S : never : never>; onBack: () => void }) {
  const { user } = useAppStore();
  const [inquirySent, setInquirySent] = useState(false);
  const [inquiry, setInquiry] = useState({ message: "", phone: "", email: "" });

  const handleSendInquiry = async () => {
    if (!user) {
      toast.error("Debes iniciar sesión para contactar");
      return;
    }

    if (!inquiry.message.trim()) {
      toast.error("Escribe un mensaje");
      return;
    }

    try {
      const res = await fetch("/api/marketplace/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          ...inquiry,
        }),
      });
      if (!res.ok) throw new Error("Error");
      setInquirySent(true);
      toast.success("Consulta enviada");
    } catch {
      toast.error("Error al enviar consulta");
    }
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <Button variant="ghost" onClick={onBack} className="mb-6">
            <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
            Volver al Marketplace
          </Button>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Product Image */}
            <Card className="border-0 shadow-lg overflow-hidden">
              <div 
                className="h-80 flex items-center justify-center"
                style={{ backgroundColor: product.category.color || "#6B7280" }}
              >
                <span className="text-8xl opacity-50">{product.category.icon}</span>
              </div>
            </Card>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="capitalize">
                    {product.condition}
                  </Badge>
                  <Badge variant="secondary">
                    {product.category.name}
                  </Badge>
                </div>
                <h1 className="text-3xl font-bold mb-2">{product.title}</h1>
                <p className="text-muted-foreground">{product.description}</p>
              </div>

              <div className="bg-muted rounded-lg p-4">
                <span className="text-4xl font-bold text-purple-600">
                  {product.currency === 'CLP' ? '$' : product.currency} {product.price.toLocaleString('es-CL')}
                </span>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>{product.location || "Sin ubicación"}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <UserIcon className="w-4 h-4" />
                  <span>Vendedor: {product.seller.name}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MessageCircle className="w-4 h-4" />
                  <span>{product._count.inquiries} consultas</span>
                </div>
              </div>

              <Separator />

              {/* Contact Form */}
              {user ? (
                !inquirySent ? (
                  <div className="space-y-4">
                    <h3 className="font-semibold">Contactar al vendedor</h3>
                    <Textarea
                      placeholder="Escribe tu consulta..."
                      value={inquiry.message}
                      onChange={(e) => setInquiry({ ...inquiry, message: e.target.value })}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        placeholder="Tu teléfono"
                        value={inquiry.phone}
                        onChange={(e) => setInquiry({ ...inquiry, phone: e.target.value })}
                      />
                      <Input
                        placeholder="Tu email"
                        type="email"
                        value={inquiry.email}
                        onChange={(e) => setInquiry({ ...inquiry, email: e.target.value })}
                      />
                    </div>
                    <Button 
                      onClick={handleSendInquiry}
                      className="w-full bg-gradient-to-r from-purple-500 to-violet-600"
                    >
                      Enviar Consulta
                    </Button>
                  </div>
                ) : (
                  <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6 text-center">
                    <CheckCircle2 className="w-12 h-12 text-purple-500 mx-auto mb-3" />
                    <p className="font-medium">¡Consulta enviada!</p>
                    <p className="text-sm text-muted-foreground">El vendedor te contactará pronto.</p>
                  </div>
                )
              ) : (
                <div className="bg-muted rounded-lg p-6 text-center">
                  <p className="text-muted-foreground mb-4">
                    Inicia sesión para contactar al vendedor
                  </p>
                </div>
              )}

              {/* Direct Contact */}
              {(product.contactPhone || product.contactEmail) && (
                <div className="bg-muted rounded-lg p-4 space-y-2">
                  <p className="text-sm font-medium">Contacto directo:</p>
                  {product.contactPhone && (
                    <p className="text-sm flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      {product.contactPhone}
                    </p>
                  )}
                  {product.contactEmail && (
                    <p className="text-sm flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      {product.contactEmail}
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// Interviews Section
function InterviewsSection() {
  const [interviews, setInterviews] = useState<Array<{
    id: string;
    title: string;
    slug: string;
    excerpt: string | null;
    content: string;
    intervieweeName: string;
    intervieweeRole: string | null;
    intervieweePhoto: string | null;
    videoUrl: string | null;
    audioUrl: string | null;
    featuredImage: string | null;
    category: string;
    duration: number | null;
    views: number;
    isFeatured: boolean;
    publishedAt: string | null;
    createdAt: string;
    author: { id: string; name: string; avatar: string | null };
    _count: { comments: number };
  }>>([]);
  const [selectedInterview, setSelectedInterview] = useState<typeof interviews[0] | null>(null);
  const [filterCategory, setFilterCategory] = useState<string | null>(null);

  useEffect(() => {
    const fetchInterviews = async () => {
      try {
        const res = await fetch("/api/interviews?limit=20");
        const data = await res.json();
        setInterviews(data.interviews || []);
      } catch (error) {
        console.error("Error fetching interviews:", error);
      }
    };
    fetchInterviews();
  }, []);

  const categories = [
    { value: "experto", label: "Expertos", color: "bg-purple-500" },
    { value: "copropietario", label: "Copropietarios", color: "bg-purple-500" },
    { value: "autoridad", label: "Autoridades", color: "bg-blue-500" },
    { value: "profesional", label: "Profesionales", color: "bg-amber-500" },
  ];

  const filteredInterviews = filterCategory
    ? interviews.filter((i) => i.category === filterCategory)
    : interviews;

  const featuredInterviews = filteredInterviews.filter((i) => i.isFeatured);
  const regularInterviews = filteredInterviews.filter((i) => !i.isFeatured);

  if (selectedInterview) {
    return (
      <InterviewDetailView
        interview={selectedInterview}
        onBack={() => setSelectedInterview(null)}
      />
    );
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4">
              <Mic className="w-3 h-3 mr-1" />
              Entrevistas
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Voces de la Comunidad
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Entrevistas con expertos, autoridades y copropietarios sobre la vida en comunidad
              y la Ley de Copropiedad Inmobiliaria.
            </p>
          </div>

          {/* Category Filters */}
          <div className="flex gap-2 overflow-x-auto pb-4 mb-8 justify-center flex-wrap">
            <button
              onClick={() => setFilterCategory(null)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                !filterCategory
                  ? "bg-gradient-to-r from-purple-500 to-violet-600 text-white"
                  : "bg-muted hover:bg-muted/80"
              }`}
            >
              Todas
            </button>
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setFilterCategory(cat.value)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                  filterCategory === cat.value
                    ? "bg-gradient-to-r from-purple-500 to-violet-600 text-white"
                    : "bg-muted hover:bg-muted/80"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Featured Interviews */}
          {featuredInterviews.length > 0 && (
            <div className="mb-12">
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                Destacadas
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                {featuredInterviews.map((interview, i) => (
                  <motion.div
                    key={interview.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card
                      className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 border-0 overflow-hidden"
                      onClick={() => setSelectedInterview(interview)}
                    >
                      <div className="h-48 bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                        {interview.videoUrl ? (
                          <Video className="w-16 h-16 text-white/50" />
                        ) : (
                          <Mic className="w-16 h-16 text-white/50" />
                        )}
                      </div>
                      <CardHeader>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary" className="capitalize">
                            {categories.find((c) => c.value === interview.category)?.label || interview.category}
                          </Badge>
                          {interview.duration && (
                            <Badge variant="outline">
                              {interview.duration} min
                            </Badge>
                          )}
                          {interview.isFeatured && (
                            <Badge className="bg-amber-100 text-amber-700">
                              <Star className="w-3 h-3 mr-1" />
                              Destacada
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="line-clamp-2">{interview.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {interview.excerpt}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white font-medium">
                            {interview.intervieweeName.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{interview.intervieweeName}</p>
                            {interview.intervieweeRole && (
                              <p className="text-sm text-muted-foreground truncate">
                                {interview.intervieweeRole}
                              </p>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground text-right">
                            <div className="flex items-center gap-1">
                              <Eye className="w-3 h-3" />
                              {interview.views}
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageCircle className="w-3 h-3" />
                              {interview._count.comments}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Regular Interviews */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Todas las Entrevistas</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {regularInterviews.map((interview, i) => (
                <motion.div
                  key={interview.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Card
                    className="h-full cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
                    onClick={() => setSelectedInterview(interview)}
                  >
                    <CardHeader>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary" className="capitalize">
                          {categories.find((c) => c.value === interview.category)?.label || interview.category}
                        </Badge>
                        {interview.videoUrl && (
                          <Badge variant="outline" className="gap-1">
                            <Video className="w-3 h-3" />
                            Video
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="line-clamp-2 text-lg">{interview.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {interview.excerpt}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white text-sm font-medium">
                          {interview.intervieweeName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{interview.intervieweeName}</p>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(interview.createdAt).toLocaleDateString("es-CL")}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {interviews.length === 0 && (
            <div className="text-center py-12">
              <Mic className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No hay entrevistas disponibles</p>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

function InterviewDetailView({ interview, onBack }: { 
  interview: NonNullable<ReturnType<typeof InterviewsSection> extends (props: infer P) => unknown ? P extends { interviews: infer S } ? S[0] : never : never>; 
  onBack: () => void 
}) {
  const [content, setContent] = useState(interview.content);
  const [comments, setComments] = useState<Array<{ id: string; content: string; createdAt: string; user: { id: string; name: string; avatar: string | null } }>>([]);
  const [newComment, setNewComment] = useState("");
  const { user } = useAppStore();

  useEffect(() => {
    const fetchInterview = async () => {
      try {
        const res = await fetch(`/api/interviews/${interview.id}`);
        const data = await res.json();
        setContent(data.interview.content);
        setComments(data.interview.comments || []);
      } catch (error) {
        console.error("Error fetching interview:", error);
      }
    };
    fetchInterview();
  }, [interview.id]);

  const handleSubmitComment = async () => {
    if (!user || !newComment.trim()) return;

    try {
      const res = await fetch("/api/interviews/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ interviewId: interview.id, content: newComment }),
      });
      const data = await res.json();
      setComments([data.comment, ...comments]);
      setNewComment("");
      toast.success("Comentario agregado");
    } catch (error) {
      toast.error("Error al agregar comentario");
    }
  };

  const categories = [
    { value: "experto", label: "Expertos", color: "bg-purple-500" },
    { value: "copropietario", label: "Copropietarios", color: "bg-purple-500" },
    { value: "autoridad", label: "Autoridades", color: "bg-blue-500" },
    { value: "profesional", label: "Profesionales", color: "bg-amber-500" },
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <Button variant="ghost" onClick={onBack} className="mb-6">
            <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
            Volver a Entrevistas
          </Button>

          <Card className="border-0 shadow-lg overflow-hidden">
            <div className="h-64 bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
              {interview.videoUrl ? (
                <Video className="w-20 h-20 text-white/30" />
              ) : (
                <Mic className="w-20 h-20 text-white/30" />
              )}
            </div>
            <CardHeader>
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="secondary" className="capitalize">
                  {categories.find((c) => c.value === interview.category)?.label || interview.category}
                </Badge>
                {interview.duration && (
                  <Badge variant="outline">
                    {interview.duration} minutos
                  </Badge>
                )}
                {interview.videoUrl && (
                  <Badge variant="outline" className="gap-1">
                    <Video className="w-3 h-3" />
                    Video
                  </Badge>
                )}
                {interview.audioUrl && (
                  <Badge variant="outline" className="gap-1">
                    <Mic className="w-3 h-3" />
                    Audio
                  </Badge>
                )}
              </div>
              <CardTitle className="text-3xl">{interview.title}</CardTitle>
              
              {/* Interviewee Info */}
              <div className="flex items-center gap-4 mt-6 p-4 bg-muted rounded-lg">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white text-2xl font-medium">
                  {interview.intervieweeName.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-lg">{interview.intervieweeName}</p>
                  {interview.intervieweeRole && (
                    <p className="text-muted-foreground">{interview.intervieweeRole}</p>
                  )}
                </div>
              </div>

              {/* Media Links */}
              {(interview.videoUrl || interview.audioUrl) && (
                <div className="flex gap-3 mt-4">
                  {interview.videoUrl && (
                    <Button asChild className="bg-gradient-to-r from-purple-500 to-pink-600">
                      <a href={interview.videoUrl} target="_blank" rel="noopener noreferrer">
                        <Video className="w-4 h-4 mr-2" />
                        Ver Video
                      </a>
                    </Button>
                  )}
                  {interview.audioUrl && (
                    <Button asChild variant="outline">
                      <a href={interview.audioUrl} target="_blank" rel="noopener noreferrer">
                        <Mic className="w-4 h-4 mr-2" />
                        Escuchar Audio
                      </a>
                    </Button>
                  )}
                </div>
              )}

              {/* Meta Info */}
              <div className="flex items-center gap-4 text-muted-foreground mt-4 text-sm">
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {new Date(interview.createdAt).toLocaleDateString("es-CL")}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {interview.views} vistas
                </span>
                <span className="flex items-center gap-1">
                  <MessageCircle className="w-4 h-4" />
                  {comments.length} comentarios
                </span>
              </div>
            </CardHeader>
            <CardContent>
              {/* Content */}
              <div className="prose dark:prose-invert max-w-none mb-8">
                {content.split("\n").map((line, i) => {
                  if (line.startsWith("# ")) {
                    return (
                      <h1 key={i} className="text-3xl font-bold mt-6 mb-4">
                        {line.slice(2)}
                      </h1>
                    );
                  }
                  if (line.startsWith("## ")) {
                    return (
                      <h2 key={i} className="text-2xl font-semibold mt-6 mb-3">
                        {line.slice(3)}
                      </h2>
                    );
                  }
                  if (line.startsWith("**") && line.endsWith("**")) {
                    return (
                      <p key={i} className="font-semibold mb-4">
                        {line.slice(2, -2)}
                      </p>
                    );
                  }
                  if (line.startsWith("- ")) {
                    return (
                      <li key={i} className="ml-4">
                        {line.slice(2)}
                      </li>
                    );
                  }
                  if (line.trim()) {
                    return (
                      <p key={i} className="mb-4 text-muted-foreground">
                        {line}
                      </p>
                    );
                  }
                  return null;
                })}
              </div>

              {/* Comments */}
              <div className="border-t pt-6">
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Comentarios ({comments.length})
                </h3>

                {user ? (
                  <div className="mb-6">
                    <Textarea
                      placeholder="Escribe un comentario..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="mb-2"
                    />
                    <Button onClick={handleSubmitComment} disabled={!newComment.trim()}>
                      Comentar
                    </Button>
                  </div>
                ) : (
                  <p className="text-muted-foreground mb-6">
                    Inicia sesión para comentar
                  </p>
                )}

                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center text-white text-sm">
                        {comment.user.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{comment.user.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(comment.createdAt).toLocaleDateString("es-CL")}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

function AboutSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4">
              <Users className="w-3 h-3 mr-1" />
              Sobre Nosotros
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Nuestra Misión
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-white mb-4">
                  <Scale className="w-6 h-6" />
                </div>
                <CardTitle>Información Legal</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Proporcionamos información clara y actualizada sobre la Ley de Copropiedad
                  Inmobiliaria 21.442 y otras normativas relevantes para la vida en comunidad.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white mb-4">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <CardTitle>Empoderamiento</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Ayudamos a los copropietarios a conocer sus derechos y deberes,
                  fomentando la participación activa y la mejora continua de las comunidades.
                </CardDescription>
              </CardContent>
            </Card>
          </div>

          <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-500 to-violet-600 text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">¿Preguntas?</h3>
              <p className="mb-6 text-white/90">
                Estamos aquí para ayudarte a entender mejor tus derechos como copropietario.
              </p>
              <Button variant="secondary" size="lg">
                Contáctanos
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

// Admin Section - Reorganized with separate Content and Diagnostic sections
function AdminSection() {
  const { user } = useAppStore();
  const [mainTab, setMainTab] = useState("contenido");
  
  // Diagnostic state
  const [diagnosticCategories, setDiagnosticCategories] = useState<Array<{ id: string; name: string; description: string; icon: string | null; color: string | null; order: number; _count: { items: number } }>>([]);
  const [diagnosticItems, setDiagnosticItems] = useState<Array<{ id: string; question: string; description: string | null; category: { id: string; name: string }; weight: number; order: number; lawSource: string | null; lawArticle: string | null }>>([]);
  const [editingCategory, setEditingCategory] = useState<typeof diagnosticCategories[0] | null>(null);
  const [editingItem, setEditingItem] = useState<typeof diagnosticItems[0] | null>(null);
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false);
  const [isItemDialogOpen, setIsItemDialogOpen] = useState(false);
  
  // Content state (Articles, Studies, Interviews)
  const [contentFilter, setContentFilter] = useState<string>("all");
  const [users, setUsers] = useState<Array<{ id: string; email: string; name: string; role: string; createdAt: string; _count: { posts: number; comments: number; diagnostics: number } }>>([]);
  const [posts, setPosts] = useState<Array<{ id: string; title: string; slug: string; excerpt: string | null; content: string; blocks: string | null; category: string | null; tags: string | null; isPublished: boolean; isFeatured: boolean; publishedAt: string | null; createdAt: string; author: { id: string; name: string }; _count: { comments: number; ratings: number } }>>([]);
  const [editingPost, setEditingPost] = useState<typeof posts[0] | null>(null);
  const [isPostDialogOpen, setIsPostDialogOpen] = useState(false);
  const [postForm, setPostForm] = useState({
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    blocks: [] as ContentBlock[],
    category: "articulo",
    tags: "",
    isPublished: false,
    isFeatured: false,
  });
  const [saving, setSaving] = useState(false);
  const [contentMode, setContentMode] = useState<"simple" | "blocks">("blocks");
  
  // Category/Item forms
  const [categoryForm, setCategoryForm] = useState({
    name: "",
    description: "",
    icon: "",
    color: "#10B981",
    order: 0,
  });
  const [itemForm, setItemForm] = useState({
    question: "",
    description: "",
    categoryId: "",
    weight: 1.0,
    order: 0,
    lawSource: "",
    lawArticle: "",
    lawText: "",
    riskText: "",
    adviceText: "",
    helpText: "",
  });

  const fetchData = useCallback(async () => {
    try {
      const [catRes, itemsRes, usersRes, postsRes] = await Promise.all([
        fetch("/api/admin/categories"),
        fetch("/api/admin/items"),
        fetch("/api/admin/users"),
        fetch("/api/admin/posts"),
      ]);
      const catData = await catRes.json();
      const itemsData = await itemsRes.json();
      const usersData = await usersRes.json();
      const postsData = await postsRes.json();
      setDiagnosticCategories(catData.categories || []);
      setDiagnosticItems(itemsData.items || []);
      setUsers(usersData.users || []);
      setPosts(postsData.posts || []);
    } catch (error) {
      console.error("Error fetching admin data:", error);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleEditPost = (post: typeof posts[0]) => {
    setEditingPost(post);
    const parsedBlocks = post.blocks ? JSON.parse(post.blocks) : [];
    setPostForm({
      title: post.title,
      slug: post.slug,
      excerpt: post.excerpt || "",
      content: post.content,
      blocks: parsedBlocks,
      category: post.category || "articulo",
      tags: post.tags ? JSON.parse(post.tags).join(", ") : "",
      isPublished: post.isPublished,
      isFeatured: post.isFeatured,
    });
    setContentMode(parsedBlocks.length > 0 ? "blocks" : "simple");
    setIsPostDialogOpen(true);
  };

  const handleNewPost = () => {
    setEditingPost(null);
    setPostForm({
      title: "",
      slug: "",
      excerpt: "",
      content: "",
      blocks: [],
      category: "articulo",
      tags: "",
      isPublished: false,
      isFeatured: false,
    });
    setContentMode("blocks");
    setIsPostDialogOpen(true);
  };

  const handleGenerateSlug = () => {
    const slug = postForm.title
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
    setPostForm({ ...postForm, slug });
  };

  const handleSavePost = async () => {
    if (!postForm.title || !postForm.slug) {
      toast.error("Título y slug son requeridos");
      return;
    }

    if (contentMode === "simple" && !postForm.content) {
      toast.error("El contenido es requerido");
      return;
    }

    if (contentMode === "blocks" && postForm.blocks.length === 0) {
      toast.error("Agrega al menos un bloque de contenido");
      return;
    }

    setSaving(true);
    try {
      const tagsArray = postForm.tags
        .split(",")
        .map((t) => t.trim())
        .filter((t) => t);

      const payload = {
        ...postForm,
        tags: JSON.stringify(tagsArray),
        blocks: contentMode === "blocks" ? JSON.stringify(postForm.blocks) : null,
        content: contentMode === "simple" ? postForm.content : "",
      };

      if (editingPost) {
        // Update existing post
        const res = await fetch(`/api/admin/posts/${editingPost.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (!res.ok) throw new Error("Error al actualizar");
        toast.success("Artículo actualizado");
      } else {
        // Create new post
        const res = await fetch("/api/admin/posts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (!res.ok) throw new Error("Error al crear");
        toast.success("Artículo creado");
      }
      setIsPostDialogOpen(false);
      fetchData();
    } catch {
      toast.error("Error al guardar artículo");
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm("¿Estás seguro de eliminar este artículo?")) return;

    try {
      const res = await fetch(`/api/admin/posts/${postId}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Error al eliminar");
      toast.success("Artículo eliminado");
      fetchData();
    } catch {
      toast.error("Error al eliminar artículo");
    }
  };

  if (!user || user.role !== "admin") {
    return (
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold">Acceso Denegado</h2>
          <p className="text-muted-foreground">No tienes permisos de administrador.</p>
        </div>
      </section>
    );
  }

  // Filter posts by category for content section
  const filteredPosts = contentFilter === "all" 
    ? posts 
    : posts.filter(p => p.category === contentFilter);

  const handleNewCategory = () => {
    setEditingCategory(null);
    setCategoryForm({ name: "", description: "", icon: "", color: "#10B981", order: 0 });
    setIsCategoryDialogOpen(true);
  };

  const handleEditCategory = (cat: typeof diagnosticCategories[0]) => {
    setEditingCategory(cat);
    setCategoryForm({
      name: cat.name,
      description: cat.description,
      icon: cat.icon || "",
      color: cat.color || "#10B981",
      order: cat.order,
    });
    setIsCategoryDialogOpen(true);
  };

  const handleSaveCategory = async () => {
    if (!categoryForm.name) {
      toast.error("El nombre es requerido");
      return;
    }
    setSaving(true);
    try {
      if (editingCategory) {
        const res = await fetch(`/api/admin/categories/${editingCategory.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(categoryForm),
        });
        if (!res.ok) throw new Error("Error al actualizar");
        toast.success("Categoría actualizada");
      } else {
        const res = await fetch("/api/admin/categories", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...categoryForm, id: `cat-${Date.now()}` }),
        });
        if (!res.ok) throw new Error("Error al crear");
        toast.success("Categoría creada");
      }
      setIsCategoryDialogOpen(false);
      fetchData();
    } catch {
      toast.error("Error al guardar categoría");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    if (!confirm("¿Estás seguro? Se eliminarán todos los ítems de esta categoría.")) return;
    try {
      const res = await fetch(`/api/admin/categories/${catId}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Error");
      toast.success("Categoría eliminada");
      fetchData();
    } catch {
      toast.error("Error al eliminar categoría");
    }
  };

  const handleNewItem = () => {
    setEditingItem(null);
    setItemForm({
      question: "",
      description: "",
      categoryId: diagnosticCategories[0]?.id || "",
      weight: 1.0,
      order: 0,
      lawSource: "",
      lawArticle: "",
      lawText: "",
      riskText: "",
      adviceText: "",
      helpText: "",
    });
    setIsItemDialogOpen(true);
  };

  const handleEditItem = (item: typeof diagnosticItems[0]) => {
    setEditingItem(item);
    setItemForm({
      question: item.question,
      description: item.description || "",
      categoryId: item.category.id,
      weight: item.weight,
      order: item.order,
      lawSource: item.lawSource || "",
      lawArticle: item.lawArticle || "",
      lawText: "",
      riskText: "",
      adviceText: "",
      helpText: "",
    });
    setIsItemDialogOpen(true);
  };

  const handleSaveItem = async () => {
    if (!itemForm.question || !itemForm.categoryId) {
      toast.error("La pregunta y categoría son requeridas");
      return;
    }
    setSaving(true);
    try {
      if (editingItem) {
        const res = await fetch(`/api/admin/items/${editingItem.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(itemForm),
        });
        if (!res.ok) throw new Error("Error al actualizar");
        toast.success("Ítem actualizado");
      } else {
        const res = await fetch("/api/admin/items", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...itemForm, id: `item-${Date.now()}` }),
        });
        if (!res.ok) throw new Error("Error al crear");
        toast.success("Ítem creado");
      }
      setIsItemDialogOpen(false);
      fetchData();
    } catch {
      toast.error("Error al guardar ítem");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!confirm("¿Estás seguro de eliminar este ítem?")) return;
    try {
      const res = await fetch(`/api/admin/items/${itemId}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Error");
      toast.success("Ítem eliminado");
      fetchData();
    } catch {
      toast.error("Error al eliminar ítem");
    }
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-6xl mx-auto"
        >
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-white">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-3xl font-bold">Panel de Administración</h2>
              <p className="text-muted-foreground">Gestiona el contenido y el diagnóstico del portal</p>
            </div>
          </div>

          {/* Main Tabs - Separated sections */}
          <Tabs value={mainTab} onValueChange={setMainTab}>
            <TabsList className="grid w-full grid-cols-3 mb-8 h-12">
              <TabsTrigger value="contenido" className="text-base">
                <FileText className="w-4 h-4 mr-2" />
                Contenido
              </TabsTrigger>
              <TabsTrigger value="diagnostico" className="text-base">
                <FileQuestion className="w-4 h-4 mr-2" />
                Diagnóstico
              </TabsTrigger>
              <TabsTrigger value="usuarios" className="text-base">
                <Users className="w-4 h-4 mr-2" />
                Usuarios
              </TabsTrigger>
            </TabsList>

            {/* ==================== CONTENIDO TAB ==================== */}
            <TabsContent value="contenido">
              <div className="space-y-6">
                {/* Info Banner */}
                <Card className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-800">
                  <CardContent className="p-4">
                    <p className="text-sm text-muted-foreground">
                      <strong>Artículos, Estudios y Entrevistas</strong> comparten la misma estructura. 
                      Difieren solo en su categoría. Usa el filtro para gestionar cada tipo por separado.
                    </p>
                  </CardContent>
                </Card>

                {/* Content Filter */}
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium">Filtrar por tipo:</span>
                  <div className="flex gap-2">
                    {[
                      { value: "all", label: "Todos" },
                      { value: "articulo", label: "Artículos" },
                      { value: "estudio", label: "Estudios" },
                      { value: "entrevista", label: "Entrevistas" },
                    ].map((filter) => (
                      <Button
                        key={filter.value}
                        variant={contentFilter === filter.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setContentFilter(filter.value)}
                        className={contentFilter === filter.value ? "bg-gradient-to-r from-purple-500 to-violet-600" : ""}
                      >
                        {filter.label}
                      </Button>
                    ))}
                  </div>
                  <div className="ml-auto">
                    <Button size="sm" onClick={handleNewPost}>
                      <Plus className="w-4 h-4 mr-2" />
                      Nuevo Contenido
                    </Button>
                  </div>
                </div>

                {/* Content List */}
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {contentFilter === "all" ? "Todo el Contenido" : 
                       contentFilter === "articulo" ? "Artículos" :
                       contentFilter === "estudio" ? "Estudios" : "Entrevistas"}
                      {" "}({filteredPosts.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[400px]">
                      <div className="space-y-2">
                        {filteredPosts.map((post) => (
                          <div
                            key={post.id}
                            className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors"
                          >
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className="capitalize shrink-0">
                                  {post.category || "articulo"}
                                </Badge>
                                <p className="font-medium truncate">{post.title}</p>
                                {post.isFeatured && (
                                  <Badge className="bg-amber-100 text-amber-700 shrink-0">
                                    <Star className="w-3 h-3 mr-1" />
                                    Destacado
                                  </Badge>
                                )}
                                {!post.isPublished && (
                                  <Badge variant="secondary" className="shrink-0">
                                    Borrador
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Eye className="w-3 h-3" />
                                  {post._count.ratings} valoraciones
                                </span>
                                <span className="flex items-center gap-1">
                                  <MessageCircle className="w-3 h-3" />
                                  {post._count.comments} comentarios
                                </span>
                                <span>{new Date(post.createdAt).toLocaleDateString("es-CL")}</span>
                              </div>
                            </div>
                            <div className="flex gap-2 shrink-0 ml-4">
                              <Button variant="outline" size="sm" onClick={() => handleEditPost(post)}>
                                <Edit className="w-4 h-4 mr-1" /> Editar
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeletePost(post.id)}
                                className="text-red-500 hover:text-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                        {filteredPosts.length === 0 && (
                          <div className="text-center py-8 text-muted-foreground">
                            No hay contenido. Crea el primero.
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* ==================== DIAGNÓSTICO TAB ==================== */}
            <TabsContent value="diagnostico">
              <div className="space-y-6">
                {/* Info Banner */}
                <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-800">
                  <CardContent className="p-4">
                    <p className="text-sm text-muted-foreground">
                      <strong>Sección independiente</strong> - Gestiona las categorías e ítems del sistema de diagnóstico. 
                      Cada categoría contiene preguntas que evalúan diferentes aspectos de la comunidad.
                    </p>
                  </CardContent>
                </Card>

                {/* Two Column Layout - Items card wider than Categories */}
                <div className="grid md:grid-cols-[1fr_2fr] gap-6">
                  {/* Categories */}
                  <Card className="flex flex-col">
                    <CardHeader className="flex flex-row items-center justify-between py-4">
                      <CardTitle className="flex items-center gap-2">
                        <BarChart3 className="w-5 h-5" />
                        Categorías
                      </CardTitle>
                      <Button size="sm" onClick={handleNewCategory}>
                        <Plus className="w-4 h-4 mr-2" /> Nueva
                      </Button>
                    </CardHeader>
                    <CardContent className="flex-1 overflow-hidden pt-0">
                      <ScrollArea className="h-full max-h-[500px]">
                        <div className="space-y-2 pr-2">
                          {diagnosticCategories.map((cat) => (
                            <div
                              key={cat.id}
                              className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors"
                            >
                              <div className="flex items-center gap-3 min-w-0 flex-1">
                                <div
                                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm shrink-0"
                                  style={{ backgroundColor: cat.color || "#10B981" }}
                                >
                                  {cat.icon || "📊"}
                                </div>
                                <div className="min-w-0">
                                  <p className="font-medium truncate">{cat.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {cat._count.items} ítems • Orden: {cat.order}
                                  </p>
                                </div>
                              </div>
                              <div className="flex gap-1 shrink-0">
                                <Button variant="ghost" size="sm" onClick={() => handleEditCategory(cat)}>
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => handleDeleteCategory(cat.id)}>
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </div>
                          ))}
                          {diagnosticCategories.length === 0 && (
                            <div className="text-center py-8 text-muted-foreground">
                              No hay categorías. Crea la primera.
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  {/* Items */}
                  <Card className="flex flex-col">
                    <CardHeader className="flex flex-row items-center justify-between py-4">
                      <CardTitle className="flex items-center gap-2">
                        <FileQuestion className="w-5 h-5" />
                        Ítems / Preguntas
                      </CardTitle>
                      <Button size="sm" onClick={handleNewItem}>
                        <Plus className="w-4 h-4 mr-2" /> Nuevo
                      </Button>
                    </CardHeader>
                    <CardContent className="flex-1 overflow-hidden pt-0">
                      <ScrollArea className="h-full max-h-[500px]">
                        <div className="space-y-2 pr-2">
                          {diagnosticItems.map((item) => (
                            <div
                              key={item.id}
                              className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors"
                            >
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm truncate">{item.question}</p>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 flex-wrap">
                                  <Badge variant="outline" className="text-xs py-0 shrink-0">
                                    {item.category.name}
                                  </Badge>
                                  <span className="shrink-0">Peso: {item.weight}</span>
                                  {item.lawSource && (
                                    <span className="flex items-center gap-1 truncate max-w-[150px]" title={item.lawSource}>
                                      <Scale className="w-3 h-3 shrink-0" />
                                      <span className="truncate">{item.lawSource}</span>
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex gap-1 shrink-0 ml-2">
                                <Button variant="ghost" size="sm" onClick={() => handleEditItem(item)}>
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => handleDeleteItem(item.id)}>
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </div>
                          ))}
                          {diagnosticItems.length === 0 && (
                            <div className="text-center py-8 text-muted-foreground">
                              No hay ítems. Crea el primero.
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* ==================== USUARIOS TAB ==================== */}
            <TabsContent value="usuarios">
              <Card>
                <CardHeader>
                  <CardTitle>Usuarios Registrados</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-2">
                      {users.map((u) => (
                        <div
                          key={u.id}
                          className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center text-white text-lg font-medium">
                              {u.name.charAt(0)}
                            </div>
                            <div>
                              <p className="font-medium">{u.name}</p>
                              <p className="text-sm text-muted-foreground">{u.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right text-sm text-muted-foreground">
                              <p>{u._count.posts} posts</p>
                              <p>{u._count.diagnostics} diagnósticos</p>
                            </div>
                            <Badge variant={u.role === "admin" ? "default" : "secondary"}>
                              {u.role === "admin" ? "Administrador" : "Usuario"}
                            </Badge>
                          </div>
                        </div>
                      ))}
                      {users.length === 0 && (
                        <div className="text-center py-8 text-muted-foreground">
                          No hay usuarios registrados.
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>

      {/* Post Edit Dialog */}
      <Dialog open={isPostDialogOpen} onOpenChange={setIsPostDialogOpen}>
        <DialogContent className="sm:max-w-3xl md:max-w-4xl lg:max-w-5xl xl:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingPost ? "Editar Contenido" : "Nuevo Contenido"}
            </DialogTitle>
            <DialogDescription>
              Completa los campos para {editingPost ? "actualizar el" : "crear nuevo"} contenido.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título *</Label>
                <Input
                  id="title"
                  value={postForm.title}
                  onChange={(e) => setPostForm({ ...postForm, title: e.target.value })}
                  placeholder="Título del contenido"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slug">Slug (URL) *</Label>
                <div className="flex gap-2">
                  <Input
                    id="slug"
                    value={postForm.slug}
                    onChange={(e) => setPostForm({ ...postForm, slug: e.target.value })}
                    placeholder="titulo-del-contenido"
                  />
                  <Button variant="outline" onClick={handleGenerateSlug}>
                    Generar
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="excerpt">Extracto</Label>
              <Input
                id="excerpt"
                value={postForm.excerpt}
                onChange={(e) => setPostForm({ ...postForm, excerpt: e.target.value })}
                placeholder="Breve descripción"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Tipo de Contenido</Label>
                <select
                  id="category"
                  value={postForm.category}
                  onChange={(e) => setPostForm({ ...postForm, category: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md bg-background"
                >
                  <option value="articulo">Artículo</option>
                  <option value="estudio">Estudio</option>
                  <option value="entrevista">Entrevista</option>
                  <option value="noticia">Noticia</option>
                  <option value="guia">Guía</option>
                  <option value="ley">Ley</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="tags">Etiquetas (separadas por coma)</Label>
                <Input
                  id="tags"
                  value={postForm.tags}
                  onChange={(e) => setPostForm({ ...postForm, tags: e.target.value })}
                  placeholder="copropiedad, ley, asamblea"
                />
              </div>
            </div>

            {/* Content Editor */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant={contentMode === "blocks" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setContentMode("blocks")}
                  className={contentMode === "blocks" ? "bg-gradient-to-r from-purple-500 to-violet-600" : ""}
                >
                  <Layout className="w-4 h-4 mr-2" />
                  Editor de Bloques
                </Button>
                <Button
                  type="button"
                  variant={contentMode === "simple" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setContentMode("simple")}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Texto Simple
                </Button>
              </div>

              {contentMode === "simple" ? (
                <div className="space-y-2">
                  <Label htmlFor="content">Contenido (Markdown)</Label>
                  <Textarea
                    id="content"
                    value={postForm.content}
                    onChange={(e) => setPostForm({ ...postForm, content: e.target.value })}
                    placeholder="# Título del artículo&#10;&#10;Escribe el contenido aquí..."
                    className="min-h-[300px] font-mono text-sm"
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Bloques de Contenido</Label>
                  <div className="border rounded-lg p-4 bg-muted/30 max-h-[400px] overflow-y-auto">
                    <BlockEditor
                      blocks={postForm.blocks}
                      onChange={(blocks) => setPostForm({ ...postForm, blocks })}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isPublished"
                  checked={postForm.isPublished}
                  onChange={(e) => setPostForm({ ...postForm, isPublished: e.target.checked })}
                  className="w-4 h-4"
                />
                <Label htmlFor="isPublished">Publicado</Label>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isFeatured"
                  checked={postForm.isFeatured}
                  onChange={(e) => setPostForm({ ...postForm, isFeatured: e.target.checked })}
                  className="w-4 h-4"
                />
                <Label htmlFor="isFeatured">Destacado</Label>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsPostDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleSavePost}
              disabled={saving}
              className="bg-gradient-to-r from-purple-500 to-violet-600"
            >
              {saving ? "Guardando..." : editingPost ? "Actualizar" : "Crear Contenido"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Category Edit Dialog */}
      <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
        <DialogContent className="sm:max-w-md md:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingCategory ? "Editar Categoría" : "Nueva Categoría de Diagnóstico"}</DialogTitle>
            <DialogDescription>
              Las categorías agrupan las preguntas del diagnóstico por temas.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="catName">Nombre *</Label>
              <Input
                id="catName"
                value={categoryForm.name}
                onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                placeholder="Nombre de la categoría"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="catDesc">Descripción</Label>
              <Textarea
                id="catDesc"
                value={categoryForm.description}
                onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                placeholder="Descripción breve"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="catIcon">Icono (emoji)</Label>
                <Input
                  id="catIcon"
                  value={categoryForm.icon}
                  onChange={(e) => setCategoryForm({ ...categoryForm, icon: e.target.value })}
                  placeholder="📊"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="catColor">Color</Label>
                <Input
                  id="catColor"
                  type="color"
                  value={categoryForm.color}
                  onChange={(e) => setCategoryForm({ ...categoryForm, color: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="catOrder">Orden</Label>
                <Input
                  id="catOrder"
                  type="number"
                  value={categoryForm.order}
                  onChange={(e) => setCategoryForm({ ...categoryForm, order: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsCategoryDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSaveCategory} disabled={saving} className="bg-gradient-to-r from-purple-500 to-violet-600">
              {saving ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Item Edit Dialog */}
      <Dialog open={isItemDialogOpen} onOpenChange={setIsItemDialogOpen}>
        <DialogContent className="sm:max-w-2xl md:max-w-3xl lg:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Editar Ítem" : "Nuevo Ítem de Diagnóstico"}</DialogTitle>
            <DialogDescription>
              Cada ítem es una pregunta que evalúa un aspecto específico de la comunidad.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="itemQuestion">Pregunta *</Label>
              <Textarea
                id="itemQuestion"
                value={itemForm.question}
                onChange={(e) => setItemForm({ ...itemForm, question: e.target.value })}
                placeholder="¿La comunidad tiene un reglamento actualizado?"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="itemDesc">Descripción / Ayuda</Label>
              <Textarea
                id="itemDesc"
                value={itemForm.description}
                onChange={(e) => setItemForm({ ...itemForm, description: e.target.value })}
                placeholder="Texto de ayuda para entender la pregunta"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="itemCategory">Categoría *</Label>
                <select
                  id="itemCategory"
                  value={itemForm.categoryId}
                  onChange={(e) => setItemForm({ ...itemForm, categoryId: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md bg-background"
                >
                  {diagnosticCategories.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="itemWeight">Peso</Label>
                <Input
                  id="itemWeight"
                  type="number"
                  step="0.1"
                  value={itemForm.weight}
                  onChange={(e) => setItemForm({ ...itemForm, weight: parseFloat(e.target.value) || 1 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="itemOrder">Orden</Label>
                <Input
                  id="itemOrder"
                  type="number"
                  value={itemForm.order}
                  onChange={(e) => setItemForm({ ...itemForm, order: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
            
            <Separator className="my-4" />
            <p className="text-sm font-medium text-muted-foreground">Información Legal (opcional)</p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="lawSource">Fuente Legal</Label>
                <Input
                  id="lawSource"
                  value={itemForm.lawSource}
                  onChange={(e) => setItemForm({ ...itemForm, lawSource: e.target.value })}
                  placeholder="Ley 21.442"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lawArticle">Artículo</Label>
                <Input
                  id="lawArticle"
                  value={itemForm.lawArticle}
                  onChange={(e) => setItemForm({ ...itemForm, lawArticle: e.target.value })}
                  placeholder="Art. 12"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="lawText">Texto Legal</Label>
              <Textarea
                id="lawText"
                value={itemForm.lawText}
                onChange={(e) => setItemForm({ ...itemForm, lawText: e.target.value })}
                placeholder="Cita textual de la ley..."
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="riskText">Texto de Riesgo</Label>
                <Textarea
                  id="riskText"
                  value={itemForm.riskText}
                  onChange={(e) => setItemForm({ ...itemForm, riskText: e.target.value })}
                  placeholder="Qué riesgos implica no cumplir..."
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="adviceText">Consejo</Label>
                <Textarea
                  id="adviceText"
                  value={itemForm.adviceText}
                  onChange={(e) => setItemForm({ ...itemForm, adviceText: e.target.value })}
                  placeholder="Recomendación..."
                />
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsItemDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSaveItem} disabled={saving} className="bg-gradient-to-r from-purple-500 to-violet-600">
              {saving ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

// Main App Component
function MainContent() {
  const { activeSection } = useAppStore();

  return (
    <main className="min-h-screen">
      <AnimatePresence mode="wait">
        {activeSection === "home" && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <HeroSection />
            <FeaturesSection />
          </motion.div>
        )}
        {activeSection === "diagnostic" && (
          <motion.div
            key="diagnostic"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <DiagnosticSection />
          </motion.div>
        )}
        {activeSection === "posts" && (
          <motion.div
            key="posts"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <PostsSection />
          </motion.div>
        )}
        {activeSection === "studies" && (
          <motion.div
            key="studies"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <StudiesSection />
          </motion.div>
        )}
        {activeSection === "marketplace" && (
          <motion.div
            key="marketplace"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <MarketplaceSection />
          </motion.div>
        )}
        {activeSection === "interviews" && (
          <motion.div
            key="interviews"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <InterviewsSection />
          </motion.div>
        )}
        {activeSection === "about" && (
          <motion.div
            key="about"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AboutSection />
          </motion.div>
        )}
        {activeSection === "admin" && (
          <motion.div
            key="admin"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AdminSection />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

// Export default Page
export default function Page() {
  const { setUser, setLoading } = useAppStore();

  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await fetch("/api/auth/me");
        const data = await res.json();
        setUser(data.user);
      } catch {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    checkSession();
  }, [setUser]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <MainContent />
      <Footer />
    </div>
  );
}
