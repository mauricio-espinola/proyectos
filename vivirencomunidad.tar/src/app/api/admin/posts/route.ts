import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

async function checkAdmin() {
  const cookieStore = await cookies();
  const session = cookieStore.get('session');
  if (!session) return null;
  const user = JSON.parse(session.value);
  if (user.role !== 'admin') return null;
  return user;
}

export async function GET() {
  try {
    const admin = await checkAdmin();
    if (!admin) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const posts = await db.post.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        author: { select: { id: true, name: true } },
        _count: { select: { comments: true, ratings: true } },
      },
    });

    return NextResponse.json({ posts });
  } catch (error) {
    console.error('Error fetching admin posts:', error);
    return NextResponse.json({ error: 'Error al obtener artículos' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const admin = await checkAdmin();
    if (!admin) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { title, slug, excerpt, content, blocks, featuredImage, category, tags, isPublished, isFeatured } = body;

    const post = await db.post.create({
      data: {
        authorId: admin.id,
        title,
        slug,
        excerpt,
        content: content || "",
        blocks,
        featuredImage,
        category,
        tags,
        isPublished: isPublished ?? false,
        isFeatured: isFeatured ?? false,
        publishedAt: isPublished ? new Date() : null,
      },
    });

    return NextResponse.json({ post });
  } catch (error) {
    console.error('Error creating post:', error);
    return NextResponse.json({ error: 'Error al crear artículo' }, { status: 500 });
  }
}
