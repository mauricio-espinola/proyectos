import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

async function checkAdmin() {
  const cookieStore = await cookies();
  const session = cookieStore.get('session');
  if (!session) return null;
  const user = JSON.parse(session.value);
  if (user.role !== 'admin') return null;
  return user;
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await checkAdmin();
    if (!admin) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();
    const {
      categoryId,
      question,
      description,
      order,
      weight,
      lawSource,
      lawArticle,
      lawText,
      riskText,
      adviceText,
      helpText,
    } = body;

    const item = await db.diagnosticItem.update({
      where: { id },
      data: {
        categoryId,
        question,
        description,
        order,
        weight,
        lawSource,
        lawArticle,
        lawText,
        riskText,
        adviceText,
        helpText,
        updatedAt: new Date(),
      },
      include: { category: true },
    });

    return NextResponse.json({ item });
  } catch (error) {
    console.error('Error updating item:', error);
    return NextResponse.json({ error: 'Error al actualizar ítem' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await checkAdmin();
    if (!admin) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = await params;

    await db.diagnosticItem.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting item:', error);
    return NextResponse.json({ error: 'Error al eliminar ítem' }, { status: 500 });
  }
}
