import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

async function checkAdmin() {
  const cookieStore = await cookies();
  const session = cookieStore.get('session');
  if (!session) return null;
  const user = JSON.parse(session.value);
  if (user.role !== 'admin') return null;
  return user;
}

export async function GET(request: NextRequest) {
  try {
    const admin = await checkAdmin();
    if (!admin) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const categoryId = searchParams.get('categoryId');

    const where = categoryId ? { categoryId } : {};

    const items = await db.diagnosticItem.findMany({
      where,
      orderBy: [{ categoryId: 'asc' }, { order: 'asc' }],
      include: { category: true },
    });

    return NextResponse.json({ items });
  } catch (error) {
    console.error('Error fetching admin items:', error);
    return NextResponse.json({ error: 'Error al obtener ítems' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const admin = await checkAdmin();
    if (!admin) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const {
      categoryId,
      question,
      description,
      order,
      weight,
      lawSource,
      lawArticle,
      lawText,
      riskText,
      adviceText,
      helpText,
    } = body;

    const item = await db.diagnosticItem.create({
      data: {
        categoryId,
        question,
        description,
        order: order || 0,
        weight: weight || 1.0,
        lawSource,
        lawArticle,
        lawText,
        riskText,
        adviceText,
        helpText,
      },
      include: { category: true },
    });

    return NextResponse.json({ item });
  } catch (error) {
    console.error('Error creating item:', error);
    return NextResponse.json({ error: 'Error al crear ítem' }, { status: 500 });
  }
}
