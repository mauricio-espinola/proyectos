import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const session = cookieStore.get('session');

    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = JSON.parse(session.value);
    const body = await request.json();
    const { productId, message, phone, email } = body;

    if (!productId || !message) {
      return NextResponse.json(
        { error: 'Producto y mensaje son requeridos' },
        { status: 400 }
      );
    }

    const inquiry = await db.marketplaceInquiry.create({
      data: {
        productId,
        userId: user.id,
        message,
        phone: phone || null,
        email: email || null,
      },
      include: {
        product: { select: { id: true, title: true } },
        user: { select: { id: true, name: true, email: true } },
      },
    });

    return NextResponse.json({ inquiry });
  } catch (error) {
    console.error('Error creating inquiry:', error);
    return NextResponse.json(
      { error: 'Error al enviar consulta' },
      { status: 500 }
    );
  }
}
