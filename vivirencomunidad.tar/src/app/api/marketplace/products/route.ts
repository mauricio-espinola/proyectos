import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const featured = searchParams.get('featured');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    const search = searchParams.get('search');

    const where: Record<string, unknown> = { isAvailable: true };
    
    if (category) {
      where.categoryId = category;
    }
    
    if (featured === 'true') {
      where.isFeatured = true;
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const products = await db.marketplaceProduct.findMany({
      where,
      orderBy: [{ isFeatured: 'desc' }, { createdAt: 'desc' }],
      take: limit,
      skip: offset,
      include: {
        seller: {
          select: { id: true, name: true, avatar: true },
        },
        category: true,
        _count: {
          select: { inquiries: true },
        },
      },
    });

    const total = await db.marketplaceProduct.count({ where });

    return NextResponse.json({ products, total });
  } catch (error) {
    console.error('Error fetching products:', error);
    return NextResponse.json(
      { error: 'Error al obtener productos' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const session = cookieStore.get('session');

    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = JSON.parse(session.value);
    const body = await request.json();
    const { 
      categoryId, title, slug, description, price, currency, 
      condition, images, location, contactPhone, contactEmail, isFeatured 
    } = body;

    if (!categoryId || !title || !slug || !description || price === undefined) {
      return NextResponse.json(
        { error: 'Categoría, título, slug, descripción y precio son requeridos' },
        { status: 400 }
      );
    }

    const product = await db.marketplaceProduct.create({
      data: {
        sellerId: user.id,
        categoryId,
        title,
        slug,
        description,
        price: parseFloat(price),
        currency: currency || 'CLP',
        condition: condition || 'nuevo',
        images: images || null,
        location: location || null,
        contactPhone: contactPhone || null,
        contactEmail: contactEmail || null,
        isFeatured: isFeatured || false,
      },
      include: {
        seller: { select: { id: true, name: true } },
        category: true,
      },
    });

    return NextResponse.json({ product });
  } catch (error) {
    console.error('Error creating product:', error);
    return NextResponse.json(
      { error: 'Error al crear producto' },
      { status: 500 }
    );
  }
}
