import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const post = await db.post.findUnique({
      where: { id },
      include: {
        author: {
          select: { id: true, name: true, avatar: true },
        },
        comments: {
          include: {
            user: {
              select: { id: true, name: true, avatar: true },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        ratings: {
          select: { value: true },
        },
      },
    });

    if (!post) {
      return NextResponse.json({ error: 'Artículo no encontrado' }, { status: 404 });
    }

    // Increment views
    await db.post.update({
      where: { id },
      data: { views: { increment: 1 } },
    });

    const avgRating = post.ratings.length > 0
      ? post.ratings.reduce((sum, r) => sum + r.value, 0) / post.ratings.length
      : 0;

    return NextResponse.json({ 
      post: { 
        ...post, 
        avgRating,
        ratingCount: post.ratings.length,
      } 
    });
  } catch (error) {
    console.error('Error fetching post:', error);
    return NextResponse.json(
      { error: 'Error al obtener artículo' },
      { status: 500 }
    );
  }
}
