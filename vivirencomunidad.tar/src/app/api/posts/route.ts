import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const featured = searchParams.get('featured');
    const category = searchParams.get('category');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = { isPublished: true };
    
    if (featured === 'true') {
      where.isFeatured = true;
    }
    
    if (category) {
      where.category = category;
    }

    const posts = await db.post.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      take: limit,
      skip: offset,
      include: {
        author: {
          select: { id: true, name: true, avatar: true },
        },
        _count: {
          select: { comments: true, ratings: true },
        },
      },
    });

    const total = await db.post.count({ where });

    // Calculate average rating for each post
    const postsWithRating = await Promise.all(
      posts.map(async (post) => {
        const ratings = await db.rating.findMany({
          where: { postId: post.id },
          select: { value: true },
        });
        
        const avgRating = ratings.length > 0
          ? ratings.reduce((sum, r) => sum + r.value, 0) / ratings.length
          : 0;

        return {
          ...post,
          avgRating,
          ratingCount: ratings.length,
        };
      })
    );

    return NextResponse.json({ posts: postsWithRating, total });
  } catch (error) {
    console.error('Error fetching posts:', error);
    return NextResponse.json(
      { error: 'Error al obtener artículos' },
      { status: 500 }
    );
  }
}
