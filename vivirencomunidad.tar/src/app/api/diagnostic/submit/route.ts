import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const session = cookieStore.get('session');

    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = JSON.parse(session.value);
    const body = await request.json();
    const { evaluations } = body;

    // Get all items with their weights and categories
    const items = await db.diagnosticItem.findMany({
      where: { isActive: true },
      include: { category: true },
    });

    const itemMap = new Map(items.map(item => [item.id, item]));

    // Calculate global scores
    let totalScore = 0;
    let maxPossibleScore = 0;

    // Calculate per-category scores
    const categoryScores = new Map<string, {
      categoryId: string;
      categoryName: string;
      categoryColor: string | null;
      categoryIcon: string | null;
      score: number;
      maxScore: number;
      itemCount: number;
    }>();

    // Initialize category scores
    for (const item of items) {
      if (!categoryScores.has(item.categoryId)) {
        categoryScores.set(item.categoryId, {
          categoryId: item.categoryId,
          categoryName: item.category.name,
          categoryColor: item.category.color,
          categoryIcon: item.category.icon,
          score: 0,
          maxScore: 0,
          itemCount: 0,
        });
      }
    }

    // Calculate max possible score globally and per category
    for (const item of items) {
      maxPossibleScore += 2 * item.weight; // Max score per item is 2
      const catScore = categoryScores.get(item.categoryId)!;
      catScore.maxScore += 2 * item.weight;
      catScore.itemCount++;
    }

    // Calculate actual score globally and per category
    const criticalAlerts: Array<{
      question: string;
      category: string;
      lawSource: string | null;
      riskText: string | null;
    }> = [];

    for (const evaluation of evaluations) {
      const item = itemMap.get(evaluation.itemId);
      if (item) {
        totalScore += evaluation.score * item.weight;
        
        // Update category score
        const catScore = categoryScores.get(item.categoryId)!;
        catScore.score += evaluation.score * item.weight;

        // Check for critical items with score 0
        if (evaluation.score === 0 && item.weight >= 1.3) {
          criticalAlerts.push({
            question: item.question,
            category: item.category.name,
            lawSource: item.lawSource,
            riskText: item.riskText,
          });
        }
      }
    }

    const percentage = maxPossibleScore > 0 ? (totalScore / maxPossibleScore) * 100 : 0;

    // Calculate category percentages and determine levels
    const categoryResults = Array.from(categoryScores.values()).map(cat => {
      const catPercentage = cat.maxScore > 0 ? (cat.score / cat.maxScore) * 100 : 0;
      
      // Determine level: critico, bajo, medio, alto
      let level: 'critico' | 'bajo' | 'medio' | 'alto';
      if (catPercentage < 35) level = 'critico';
      else if (catPercentage < 50) level = 'bajo';
      else if (catPercentage < 75) level = 'medio';
      else level = 'alto';

      return {
        ...cat,
        percentage: Math.round(catPercentage * 10) / 10, // One decimal
        level,
      };
    });

    // Sort categories by percentage (worst first for prioritization)
    categoryResults.sort((a, b) => a.percentage - b.percentage);

    // Identify strengths (top 2) and weaknesses (bottom 2)
    const strengths = categoryResults.filter(c => c.level === 'alto').slice(0, 2);
    const weaknesses = categoryResults.filter(c => c.level === 'critico' || c.level === 'bajo').slice(0, 3);

    // Create diagnostic result
    const result = await db.diagnosticResult.create({
      data: {
        userId: user.id,
        totalScore,
        maxScore: maxPossibleScore,
        percentage,
      },
    });

    // Create individual evaluations
    for (const evaluation of evaluations) {
      await db.diagnosticEvaluation.create({
        data: {
          resultId: result.id,
          itemId: evaluation.itemId,
          userId: user.id,
          score: evaluation.score,
          notes: evaluation.notes || null,
        },
      });
    }

    // Get copropietario type based on score (using floor for stability)
    const normalizedPercentage = Math.floor(percentage);
    const copropietarioType = await db.copropietarioType.findFirst({
      where: {
        minScore: { lte: normalizedPercentage },
        maxScore: { gte: normalizedPercentage },
      },
    });

    // Get the evaluations with item and category data
    const savedEvaluations = await db.diagnosticEvaluation.findMany({
      where: { resultId: result.id },
      include: {
        item: {
          include: { category: true },
        },
      },
    });

    return NextResponse.json({
      result: {
        ...result,
        copropietarioType,
        evaluations: savedEvaluations,
        // Enhanced results
        categoryResults,
        strengths,
        weaknesses,
        criticalAlerts,
        summary: {
          totalItems: items.length,
          answeredItems: evaluations.length,
          globalPercentage: Math.round(percentage * 10) / 10,
          profileLevel: copropietarioType?.name || 'Sin clasificar',
        },
      },
    });
  } catch (error) {
    console.error('Error submitting diagnostic:', error);
    return NextResponse.json(
      { error: 'Error al guardar diagnóstico' },
      { status: 500 }
    );
  }
}
