import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const session = cookieStore.get('session');

    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = JSON.parse(session.value);

    const results = await db.diagnosticResult.findMany({
      where: { userId: user.id },
      orderBy: { completedAt: 'desc' },
      include: {
        evaluations: {
          include: {
            item: {
              include: { category: true },
            },
          },
        },
      },
    });

    // Get copropietario type for each result
    const resultsWithType = await Promise.all(
      results.map(async (result) => {
        const copropietarioType = await db.copropietarioType.findFirst({
          where: {
            minScore: { lte: Math.round(result.percentage) },
            maxScore: { gte: Math.round(result.percentage) },
          },
        });
        return { ...result, copropietarioType };
      })
    );

    return NextResponse.json({ results: resultsWithType });
  } catch (error) {
    console.error('Error fetching results:', error);
    return NextResponse.json(
      { error: 'Error al obtener resultados' },
      { status: 500 }
    );
  }
}
