import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cookies } from "next/headers";

// GET - Get poll results
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const pollId = searchParams.get("pollId");

    if (!pollId) {
      return NextResponse.json({ error: "pollId requerido" }, { status: 400 });
    }

    const poll = await db.poll.findUnique({
      where: { id: pollId },
      include: {
        responses: true,
      },
    });

    if (!poll) {
      return NextResponse.json({ error: "Encuesta no encontrada" }, { status: 404 });
    }

    // Calculate votes per option
    const options = JSON.parse(poll.options) as string[];
    const votes: Record<number, number> = {};
    options.forEach((_, index) => {
      votes[index] = 0;
    });

    poll.responses.forEach((response) => {
      const optionIndex = parseInt(response.option);
      if (!isNaN(optionIndex)) {
        votes[optionIndex] = (votes[optionIndex] || 0) + 1;
      }
    });

    return NextResponse.json({
      poll: {
        id: poll.id,
        question: poll.question,
        options,
        votes,
        totalVotes: poll.responses.length,
        isActive: poll.isActive,
        allowMultiple: poll.allowMultiple,
        endsAt: poll.endsAt,
      },
    });
  } catch (error) {
    console.error("Error fetching poll:", error);
    return NextResponse.json(
      { error: "Error al obtener encuesta" },
      { status: 500 }
    );
  }
}

// POST - Create poll
export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "No autorizado" }, { status: 403 });
    }

    const data = await request.json();
    const { question, options, postId, studyId, interviewId, allowMultiple, endsAt } = data;

    if (!question || !options || options.length < 2) {
      return NextResponse.json(
        { error: "Pregunta y al menos 2 opciones son requeridas" },
        { status: 400 }
      );
    }

    const poll = await db.poll.create({
      data: {
        question,
        options: JSON.stringify(options),
        votes: JSON.stringify({}),
        postId: postId || null,
        studyId: studyId || null,
        interviewId: interviewId || null,
        allowMultiple: allowMultiple || false,
        endsAt: endsAt ? new Date(endsAt) : null,
      },
    });

    return NextResponse.json({ poll });
  } catch (error) {
    console.error("Error creating poll:", error);
    return NextResponse.json(
      { error: "Error al crear encuesta" },
      { status: 500 }
    );
  }
}
