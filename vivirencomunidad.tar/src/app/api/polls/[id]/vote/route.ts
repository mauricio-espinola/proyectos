import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cookies } from "next/headers";

// POST - Vote on a poll
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    const { option } = data;

    if (option === undefined || option === null) {
      return NextResponse.json(
        { error: "Opción requerida" },
        { status: 400 }
      );
    }

    const poll = await db.poll.findUnique({
      where: { id },
    });

    if (!poll) {
      return NextResponse.json(
        { error: "Encuesta no encontrada" },
        { status: 404 }
      );
    }

    if (!poll.isActive) {
      return NextResponse.json(
        { error: "Encuesta cerrada" },
        { status: 400 }
      );
    }

    if (poll.endsAt && new Date() > new Date(poll.endsAt)) {
      return NextResponse.json(
        { error: "Encuesta finalizada" },
        { status: 400 }
      );
    }

    // Get user ID or session ID
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;
    const sessionId = cookieStore.get("sessionId")?.value || 
      `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Check if user already voted (if not allowMultiple)
    if (!poll.allowMultiple && userId) {
      const existingVote = await db.pollResponse.findFirst({
        where: { pollId: id, userId },
      });
      if (existingVote) {
        return NextResponse.json(
          { error: "Ya has votado en esta encuesta" },
          { status: 400 }
        );
      }
    }

    // Create response
    const response = await db.pollResponse.create({
      data: {
        pollId: id,
        userId: userId || null,
        sessionId: userId ? null : sessionId,
        option: String(option),
      },
    });

    // Get updated results
    const allResponses = await db.pollResponse.findMany({
      where: { pollId: id },
    });

    const options = JSON.parse(poll.options) as string[];
    const votes: Record<number, number> = {};
    options.forEach((_, index) => {
      votes[index] = 0;
    });

    allResponses.forEach((r) => {
      const optionIndex = parseInt(r.option);
      if (!isNaN(optionIndex)) {
        votes[optionIndex] = (votes[optionIndex] || 0) + 1;
      }
    });

    // Set session cookie if not logged in
    const headers = new Headers();
    if (!userId) {
      headers.append(
        "Set-Cookie",
        `sessionId=${sessionId}; Path=/; Max-Age=31536000; SameSite=Lax`
      );
    }

    return NextResponse.json(
      {
        success: true,
        response,
        results: {
          options,
          votes,
          totalVotes: allResponses.length,
        },
      },
      { headers }
    );
  } catch (error) {
    console.error("Error voting:", error);
    return NextResponse.json(
      { error: "Error al votar" },
      { status: 500 }
    );
  }
}
