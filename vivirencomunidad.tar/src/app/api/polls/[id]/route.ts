import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cookies } from "next/headers";

// GET - Get single poll
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const poll = await db.poll.findUnique({
      where: { id },
      include: {
        responses: true,
      },
    });

    if (!poll) {
      return NextResponse.json({ error: "Encuesta no encontrada" }, { status: 404 });
    }

    // Calculate votes per option
    const options = JSON.parse(poll.options) as string[];
    const votes: Record<number, number> = {};
    options.forEach((_, index) => {
      votes[index] = 0;
    });

    poll.responses.forEach((response) => {
      const optionIndex = parseInt(response.option);
      if (!isNaN(optionIndex)) {
        votes[optionIndex] = (votes[optionIndex] || 0) + 1;
      }
    });

    return NextResponse.json({
      poll: {
        id: poll.id,
        question: poll.question,
        options,
        votes,
        totalVotes: poll.responses.length,
        isActive: poll.isActive,
        allowMultiple: poll.allowMultiple,
        endsAt: poll.endsAt,
      },
    });
  } catch (error) {
    console.error("Error fetching poll:", error);
    return NextResponse.json(
      { error: "Error al obtener encuesta" },
      { status: 500 }
    );
  }
}

// PUT - Update poll
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "No autorizado" }, { status: 403 });
    }

    const { id } = await params;
    const data = await request.json();

    const poll = await db.poll.update({
      where: { id },
      data: {
        question: data.question,
        options: JSON.stringify(data.options),
        isActive: data.isActive,
        allowMultiple: data.allowMultiple,
        endsAt: data.endsAt ? new Date(data.endsAt) : null,
      },
    });

    return NextResponse.json({ poll });
  } catch (error) {
    console.error("Error updating poll:", error);
    return NextResponse.json(
      { error: "Error al actualizar encuesta" },
      { status: 500 }
    );
  }
}

// DELETE - Delete poll
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "No autorizado" }, { status: 403 });
    }

    const { id } = await params;

    await db.poll.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting poll:", error);
    return NextResponse.json(
      { error: "Error al eliminar encuesta" },
      { status: 500 }
    );
  }
}
