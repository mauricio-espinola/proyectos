import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cookies } from "next/headers";

// GET - Get single interview
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const interview = await db.interview.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        comments: {
          where: { isActive: true },
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
          orderBy: { createdAt: "desc" },
        },
      },
    });

    if (!interview) {
      return NextResponse.json(
        { error: "Entrevista no encontrada" },
        { status: 404 }
      );
    }

    // Increment views
    await db.interview.update({
      where: { id },
      data: { views: { increment: 1 } },
    });

    return NextResponse.json({ interview });
  } catch (error) {
    console.error("Error fetching interview:", error);
    return NextResponse.json(
      { error: "Error al obtener entrevista" },
      { status: 500 }
    );
  }
}

// PUT - Update interview (admin only)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "No autorizado" }, { status: 403 });
    }

    const { id } = await params;
    const data = await request.json();

    const interview = await db.interview.update({
      where: { id },
      data: {
        title: data.title,
        excerpt: data.excerpt,
        content: data.content,
        intervieweeName: data.intervieweeName,
        intervieweeRole: data.intervieweeRole,
        intervieweePhoto: data.intervieweePhoto,
        videoUrl: data.videoUrl,
        audioUrl: data.audioUrl,
        featuredImage: data.featuredImage,
        category: data.category,
        tags: data.tags,
        duration: data.duration ? parseInt(data.duration) : null,
        isFeatured: data.isFeatured,
      },
    });

    return NextResponse.json({ interview });
  } catch (error) {
    console.error("Error updating interview:", error);
    return NextResponse.json(
      { error: "Error al actualizar entrevista" },
      { status: 500 }
    );
  }
}

// DELETE - Delete interview (admin only)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "No autorizado" }, { status: 403 });
    }

    const { id } = await params;

    await db.interview.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting interview:", error);
    return NextResponse.json(
      { error: "Error al eliminar entrevista" },
      { status: 500 }
    );
  }
}
