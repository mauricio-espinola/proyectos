import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cookies } from "next/headers";

// GET - List interviews
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get("limit") || "20");
    const category = searchParams.get("category");
    const featured = searchParams.get("featured");

    const where: Record<string, unknown> = {
      isPublished: true,
    };

    if (category) {
      where.category = category;
    }

    if (featured === "true") {
      where.isFeatured = true;
    }

    // Check if interview model exists
    if (!db.interview) {
      console.warn("Interview model not available - returning empty array");
      return NextResponse.json({ interviews: [] });
    }

    const interviews = await db.interview.findMany({
      where,
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            comments: true,
          },
        },
      },
      orderBy: [
        { isFeatured: "desc" },
        { publishedAt: "desc" },
      ],
      take: limit,
    });

    return NextResponse.json({ interviews });
  } catch (error) {
    console.error("Error fetching interviews:", error);
    return NextResponse.json(
      { interviews: [] },
      { status: 200 }
    );
  }
}

// POST - Create interview (admin only)
export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "No autorizado" }, { status: 403 });
    }

    const data = await request.json();
    const {
      title,
      excerpt,
      content,
      intervieweeName,
      intervieweeRole,
      intervieweePhoto,
      videoUrl,
      audioUrl,
      featuredImage,
      category,
      tags,
      duration,
      isFeatured,
    } = data;

    // Generate slug
    const slug = title
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

    const interview = await db.interview.create({
      data: {
        authorId: userId,
        title,
        slug,
        excerpt,
        content: content || "",
        intervieweeName,
        intervieweeRole,
        intervieweePhoto,
        videoUrl,
        audioUrl,
        featuredImage,
        category: category || "experto",
        tags,
        duration: duration ? parseInt(duration) : null,
        isPublished: true,
        isFeatured: isFeatured || false,
        publishedAt: new Date(),
      },
    });

    return NextResponse.json({ interview });
  } catch (error) {
    console.error("Error creating interview:", error);
    return NextResponse.json(
      { error: "Error al crear entrevista" },
      { status: 500 }
    );
  }
}
