import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const featured = searchParams.get('featured');
    const category = searchParams.get('category');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = { isPublished: true };
    
    if (featured === 'true') {
      where.isFeatured = true;
    }
    
    if (category) {
      where.category = category;
    }

    const studies = await db.study.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      take: limit,
      skip: offset,
      include: {
        author: {
          select: { id: true, name: true, avatar: true },
        },
        _count: {
          select: { comments: true },
        },
      },
    });

    const total = await db.study.count({ where });

    return NextResponse.json({ studies, total });
  } catch (error) {
    console.error('Error fetching studies:', error);
    return NextResponse.json(
      { error: 'Error al obtener estudios' },
      { status: 500 }
    );
  }
}
