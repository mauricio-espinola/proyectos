import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';

// Seed the database with sample data
export async function POST() {
  try {
    // Create test users
    const adminPassword = await hashPassword('admin123');
    const userPassword = await hashPassword('user123');

    const users = await Promise.all([
      db.user.upsert({
        where: { email: 'admin@condominio.cl' },
        update: {},
        create: {
          email: 'admin@condominio.cl',
          password: adminPassword,
          name: 'Administrador Portal',
          role: 'admin',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
        },
      }),
      db.user.upsert({
        where: { email: 'usuario@condominio.cl' },
        update: {},
        create: {
          email: 'usuario@condominio.cl',
          password: userPassword,
          name: 'Juan Copropietario',
          role: 'user',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=juan',
        },
      }),
      db.user.upsert({
        where: { email: 'maria@condominio.cl' },
        update: {},
        create: {
          email: 'maria@condominio.cl',
          password: userPassword,
          name: 'María García',
          role: 'user',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=maria',
        },
      }),
      db.user.upsert({
        where: { email: 'carlos@condominio.cl' },
        update: {},
        create: {
          email: 'carlos@condominio.cl',
          password: userPassword,
          name: 'Carlos Pérez',
          role: 'user',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=carlos',
        },
      }),
    ]);

    // Create copropietario types with improved descriptions
    const types = await Promise.all([
      db.copropietarioType.upsert({
        where: { id: 'type-1' },
        update: {
          description: 'Participación baja o comprensión insuficiente de aspectos clave de la copropiedad.',
          advice: 'Tu comunidad necesita tu participación activa. Infórmate sobre tus derechos y deberes como copropietario. Revisa las áreas con puntaje más bajo.',
        },
        create: {
          id: 'type-1',
          name: 'El Confiado',
          description: 'Participación baja o comprensión insuficiente de aspectos clave de la copropiedad.',
          minScore: 0,
          maxScore: 25,
          icon: '😌',
          color: '#EF4444',
          advice: 'Tu comunidad necesita tu participación activa. Infórmate sobre tus derechos y deberes como copropietario. Revisa las áreas con puntaje más bajo.',
        },
      }),
      db.copropietarioType.upsert({
        where: { id: 'type-2' },
        update: {
          description: 'Tiene nociones básicas, pero aún necesita apoyo para comprender mejor su rol y sus responsabilidades.',
          advice: 'Vas por buen camino. Continúa informándote y participando en las asambleas. Prioriza mejorar en las categorías con menor puntaje.',
        },
        create: {
          id: 'type-2',
          name: 'El Novato',
          description: 'Tiene nociones básicas, pero aún necesita apoyo para comprender mejor su rol y sus responsabilidades.',
          minScore: 26,
          maxScore: 45,
          icon: '🌱',
          color: '#F97316',
          advice: 'Vas por buen camino. Continúa informándote y participando en las asambleas. Prioriza mejorar en las categorías con menor puntaje.',
        },
      }),
      db.copropietarioType.upsert({
        where: { id: 'type-3' },
        update: {
          description: 'Muestra involucramiento y comprensión intermedia de la vida en copropiedad.',
          advice: 'Excelente progreso. Sigue participando y considera colaborar con el comité de administración. Revisa las áreas que necesitan más atención.',
        },
        create: {
          id: 'type-3',
          name: 'El Participativo',
          description: 'Muestra involucramiento y comprensión intermedia de la vida en copropiedad.',
          minScore: 46,
          maxScore: 65,
          icon: '👍',
          color: '#EAB308',
          advice: 'Excelente progreso. Sigue participando y considera colaborar con el comité de administración. Revisa las áreas que necesitan más atención.',
        },
      }),
      db.copropietarioType.upsert({
        where: { id: 'type-4' },
        update: {
          description: 'Tiene buen dominio práctico de los principales temas de copropiedad y participación.',
          advice: '¡Excelente! Tienes buen dominio de los temas clave. Comparte tus conocimientos con otros vecinos y apoya en las áreas más débiles.',
        },
        create: {
          id: 'type-4',
          name: 'El Experto',
          description: 'Tiene buen dominio práctico de los principales temas de copropiedad y participación.',
          minScore: 66,
          maxScore: 85,
          icon: '⭐',
          color: '#22C55E',
          advice: '¡Excelente! Tienes buen dominio de los temas clave. Comparte tus conocimientos con otros vecinos y apoya en las áreas más débiles.',
        },
      }),
      db.copropietarioType.upsert({
        where: { id: 'type-5' },
        update: {
          description: 'Presenta un nivel sobresaliente de comprensión, involucramiento y criterio en materias de copropiedad.',
          advice: '¡Felicidades! Tu compromiso es ejemplar. Tu comunidad te valora. Considera postularte para el comité de administración.',
        },
        create: {
          id: 'type-5',
          name: 'El Súper Vecino',
          description: 'Presenta un nivel sobresaliente de comprensión, involucramiento y criterio en materias de copropiedad.',
          minScore: 86,
          maxScore: 100,
          icon: '🏆',
          color: '#3B82F6',
          advice: '¡Felicidades! Tu compromiso es ejemplar. Tu comunidad te valora. Considera postularte para el comité de administración.',
        },
      }),
    ]);

    // Create diagnostic categories based on Ley 21.442
    const categories = await Promise.all([
      db.diagnosticCategory.upsert({
        where: { id: 'cat-1' },
        update: {},
        create: {
          id: 'cat-1',
          name: 'Mantención de Bienes Comunes',
          description: 'Evalúa el estado y mantenimiento de los espacios y bienes de uso común del condominio.',
          order: 1,
          icon: '🔧',
          color: '#3B82F6',
          lawReference: 'Ley 21.442, Arts. 13-15, 32-35',
        },
      }),
      db.diagnosticCategory.upsert({
        where: { id: 'cat-2' },
        update: {},
        create: {
          id: 'cat-2',
          name: 'Asambleas y Participación',
          description: 'Evalúa la realización y participación en asambleas de copropietarios.',
          order: 2,
          icon: '👥',
          color: '#10B981',
          lawReference: 'Ley 21.442, Arts. 16-28',
        },
      }),
      db.diagnosticCategory.upsert({
        where: { id: 'cat-3' },
        update: {},
        create: {
          id: 'cat-3',
          name: 'Administración y Finanzas',
          description: 'Evalúa la gestión administrativa y financiera del condominio.',
          order: 3,
          icon: '💰',
          color: '#F59E0B',
          lawReference: 'Ley 21.442, Arts. 29-40',
        },
      }),
      db.diagnosticCategory.upsert({
        where: { id: 'cat-4' },
        update: {},
        create: {
          id: 'cat-4',
          name: 'Reglamento de Copropiedad',
          description: 'Evalúa el conocimiento y aplicación del reglamento de copropiedad.',
          order: 4,
          icon: '📜',
          color: '#8B5CF6',
          lawReference: 'Ley 21.442, Arts. 1-8',
        },
      }),
      db.diagnosticCategory.upsert({
        where: { id: 'cat-5' },
        update: {},
        create: {
          id: 'cat-5',
          name: 'Seguridad y Emergencias',
          description: 'Evalúa los planes de seguridad y protocolos de emergencia.',
          order: 5,
          icon: '🚨',
          color: '#EF4444',
          lawReference: 'Ley 21.442, Art. 36; Normas ISL',
        },
      }),
      db.diagnosticCategory.upsert({
        where: { id: 'cat-6' },
        update: {},
        create: {
          id: 'cat-6',
          name: 'Relaciones Laborales',
          description: 'Evalúa el cumplimiento de normativas laborales para personal del condominio.',
          order: 6,
          icon: '👷',
          color: '#6366F1',
          lawReference: 'Código del Trabajo; Dirección del Trabajo',
        },
      }),
      db.diagnosticCategory.upsert({
        where: { id: 'cat-7' },
        update: {},
        create: {
          id: 'cat-7',
          name: 'Medio Ambiente',
          description: 'Evalúa prácticas ambientales y gestión de residuos.',
          order: 7,
          icon: '🌿',
          color: '#14B8A6',
          lawReference: 'Ley 21.442; Normas Ambientales',
        },
      }),
    ]);

    // Create diagnostic items for each category
    const items = [
      // Category 1: Mantención de Bienes Comunes
      { id: 'item-1-1', categoryId: 'cat-1', question: '¿Los pasillos y áreas comunes están limpios y bien iluminados?', order: 1, weight: 1.0, lawSource: 'Ley 21.442', lawArticle: 'Art. 13', lawText: 'Los copropietarios tienen derecho a usar los bienes comunes en la forma que indique el reglamento.', riskText: 'Áreas mal mantenidas pueden generar accidentes y devaluación de propiedades.', adviceText: 'Solicita inspecciones periódicas y reporta deficiencias al administrador.' },
      { id: 'item-1-2', categoryId: 'cat-1', question: '¿El ascensor funciona correctamente y tiene mantención al día?', order: 2, weight: 1.5, lawSource: 'Ley 21.442', lawArticle: 'Art. 14', lawText: 'Los bienes comunes deben mantenerse en buen estado de funcionamiento.', riskText: 'Ascensores sin mantención representan riesgo de accidentes graves y multas.', adviceText: 'Verifica que exista contrato de mantención vigente y certificaciones SEC.' },
      { id: 'item-1-3', categoryId: 'cat-1', question: '¿Las áreas verdes y jardines están bien mantenidos?', order: 3, weight: 0.8, lawSource: 'Ley 21.442', lawArticle: 'Art. 15', lawText: 'Los espacios comunes deben conservarse adecuadamente.', riskText: 'Jardines descuidados afectan la imagen del condominio y el valor de las propiedades.', adviceText: 'Propone un plan de mantención de áreas verdes en la próxima asamblea.' },
      { id: 'item-1-4', categoryId: 'cat-1', question: '¿El estacionamiento visitante está bien señalizado y controlado?', order: 4, weight: 0.8, lawSource: 'Reglamento de Copropiedad', lawText: 'El uso de estacionamientos de visitantes debe estar regulado.', riskText: 'Mal control genera conflictos entre vecinos y uso indebido.', adviceText: 'Revisa el reglamento sobre uso de estacionamientos y propone mejoras.' },
      { id: 'item-1-5', categoryId: 'cat-1', question: '¿Las instalaciones deportivas y recreativas están en buen estado?', order: 5, weight: 0.9, lawSource: 'Ley 21.442', lawArticle: 'Art. 13', lawText: 'Los bienes comunes deben estar disponibles y en condiciones de uso.', riskText: 'Instalaciones en mal estado pueden causar accidentes y generar responsabilidad.', adviceText: 'Reporta deterioros y solicita reparaciones en asamblea.' },

      // Category 2: Asambleas y Participación
      { id: 'item-2-1', categoryId: 'cat-2', question: '¿Se realizan asambleas ordinarias al menos una vez al año?', order: 1, weight: 1.5, lawSource: 'Ley 21.442', lawArticle: 'Art. 16', lawText: 'La asamblea ordinaria se realizará al menos una vez al año dentro de los primeros tres meses.', riskText: 'No realizar asambleas impide la toma de decisiones democráticas y el control de gestión.', adviceText: 'Exige la convocatoria a asamblea si no se ha realizado. Es tu derecho.', helpText: 'La asamblea ordinaria es donde se aprueban cuentas, se elige administración y se toman decisiones importantes.' },
      { id: 'item-2-2', categoryId: 'cat-2', question: '¿Recibes citación a asamblea con la anticipación legal requerida?', order: 2, weight: 1.2, lawSource: 'Ley 21.442', lawArticle: 'Art. 17', lawText: 'La citación debe hacerse mediante carta certificada, correo electrónico o personalmente con al menos 5 días de anticipación.', riskText: 'Citaciones tardías o inexistentes vulneran tu derecho a participar.', adviceText: 'Verifica que tus datos de contacto estén actualizados en el registro de copropietarios.' },
      { id: 'item-2-3', categoryId: 'cat-2', question: '¿Participas activamente en las asambleas votando?', order: 3, weight: 1.0, lawSource: 'Ley 21.442', lawArticle: 'Art. 18-20', lawText: 'Todo copropietario tiene derecho a voto en las asambleas.', riskText: 'No participar te excluye de decisiones que afectan tu patrimonio y calidad de vida.', adviceText: 'Asiste y vota. Tu voz importa. Si no puedes, otorga poder a otro copropietario.' },
      { id: 'item-2-4', categoryId: 'cat-2', question: '¿Conoces los acuerdos tomados en las últimas asambleas?', order: 4, weight: 1.0, lawSource: 'Ley 21.442', lawArticle: 'Art. 24', lawText: 'Los acuerdos deben constar en actas y ser notificados a los copropietarios.', riskText: 'Desconocer los acuerdos te impide ejercer tus derechos y cumplir obligaciones.', adviceText: 'Solicita copia de las actas al administrador. Tienes derecho a acceder a ellas.' },
      { id: 'item-2-5', categoryId: 'cat-2', question: '¿Existe un comité de administración funcionando?', order: 5, weight: 1.3, lawSource: 'Ley 21.442', lawArticle: 'Art. 29-31', lawText: 'El comité de administración representa a los copropietarios y fiscaliza al administrador.', riskText: 'Sin comité, no hay fiscalización real de la gestión del administrador.', adviceText: 'Participa en la elección del comité o postúlate como miembro.' },

      // Category 3: Administración y Finanzas
      { id: 'item-3-1', categoryId: 'cat-3', question: '¿Recibes rendición de cuentas del administrador?', order: 1, weight: 1.5, lawSource: 'Ley 21.442', lawArticle: 'Art. 38', lawText: 'El administrador debe rendir cuenta documentada de su gestión al menos anualmente.', riskText: 'Sin rendición, no hay transparencia sobre el uso de los fondos comunes.', adviceText: 'Exige rendición de cuentas detallada en la asamblea ordinaria.' },
      { id: 'item-3-2', categoryId: 'cat-3', question: '¿Existe un presupuesto anual aprobado?', order: 2, weight: 1.3, lawSource: 'Ley 21.442', lawArticle: 'Art. 33', lawText: 'La asamblea debe aprobar anualmente el presupuesto de gastos comunes.', riskText: 'Sin presupuesto, no hay control de gastos ni planificación.', adviceText: 'Propone la discusión del presupuesto en asamblea y solicita explicaciones sobre gastos.' },
      { id: 'item-3-3', categoryId: 'cat-3', question: '¿Los gastos comunes están bien detallados en los cobros?', order: 3, weight: 1.2, lawSource: 'Ley 21.442', lawArticle: 'Art. 34-35', lawText: 'Los gastos comunes deben prorratearse según los porcentajes del reglamento.', riskText: 'Cobros mal detallados pueden ocultar gastos injustificados.', adviceText: 'Revisa que tu cobro incluya desglose de gastos ordinarios y extraordinarios.' },
      { id: 'item-3-4', categoryId: 'cat-3', question: '¿Existe un fondo de reserva para emergencias?', order: 4, weight: 1.0, lawSource: 'Ley 21.442', lawArticle: 'Art. 37', lawText: 'Se debe constituir un fondo de reserva para gastos urgentes.', riskText: 'Sin fondo de reserva, emergencias pueden generar cuotas extraordinarias sorpresivas.', adviceText: 'Verifica que exista y proponga un monto mínimo de reserva en asamblea.' },
      { id: 'item-3-5', categoryId: 'cat-3', question: '¿El administrador está registrado oficialmente?', order: 5, weight: 1.2, lawSource: 'Ley 21.442', lawArticle: 'Art. 40', lawText: 'Los administradores deben inscribirse en el registro del Ministerio de Vivienda.', riskText: 'Administradores no registrados no pueden certificar documentos oficiales.', adviceText: 'Verifica el registro del administrador en el sitio del Minvu.' },

      // Category 4: Reglamento de Copropiedad
      { id: 'item-4-1', categoryId: 'cat-4', question: '¿Tienes copia del reglamento de copropiedad?', order: 1, weight: 1.3, lawSource: 'Ley 21.442', lawArticle: 'Art. 1-5', lawText: 'Todo condominio debe tener reglamento de copropiedad.', riskText: 'Sin conocer el reglamento, no conoces tus derechos y obligaciones.', adviceText: 'Solicita copia al administrador. Es tu derecho fundamental.' },
      { id: 'item-4-2', categoryId: 'cat-4', question: '¿El reglamento se respeta y aplica?', order: 2, weight: 1.2, lawSource: 'Ley 21.442', lawArticle: 'Art. 6', lawText: 'El reglamento obliga a todos los copropietarios.', riskText: 'Reglamento sin aplicación genera anarquía y conflictos.', adviceText: 'Reporta incumplimientos al comité y propón sanciones en asamblea.' },
      { id: 'item-4-3', categoryId: 'cat-4', question: '¿Conoces los horarios de uso de bienes comunes?', order: 3, weight: 0.8, lawSource: 'Reglamento de Copropiedad', lawText: 'Los reglamentos deben establecer horarios y normas de uso.', riskText: 'Desconocer horarios genera conflictos con vecinos.', adviceText: 'Lee el reglamento y respeta las normas de convivencia.' },
      { id: 'item-4-4', categoryId: 'cat-4', question: '¿Sabes qué modificaciones requieren autorización?', order: 4, weight: 1.0, lawSource: 'Ley 21.442', lawArticle: 'Art. 7', lawText: 'Las modificaciones en bienes comunes o que afecten la estructura requieren acuerdo.', riskText: 'Modificaciones sin autorización pueden generar multas y obligación de restituir.', adviceText: 'Consulta siempre antes de hacer modificaciones en tu unidad.' },
      { id: 'item-4-5', categoryId: 'cat-4', question: '¿Conoces las sanciones por incumplimiento del reglamento?', order: 5, weight: 0.9, lawSource: 'Ley 21.442', lawArticle: 'Art. 8', lawText: 'Los incumplimientos pueden ser sancionados con multas.', riskText: 'Desconocer las sanciones no te exime de ellas.', adviceText: 'Infórmate sobre las multas y procédate según el reglamento.' },

      // Category 5: Seguridad y Emergencias
      { id: 'item-5-1', categoryId: 'cat-5', question: '¿Existe un plan de emergencia conocido por todos?', order: 1, weight: 1.5, lawSource: 'Ley 21.442, Normas ISL', lawArticle: 'Art. 36', lawText: 'Los edificios deben contar con planes de emergencia.', riskText: 'Sin plan, la respuesta ante emergencias es caótica y peligrosa.', adviceText: 'Propón la creación o actualización del plan de emergencia.' },
      { id: 'item-5-2', categoryId: 'cat-5', question: '¿Los extintores están vigentes y accesibles?', order: 2, weight: 1.3, lawSource: 'Normas ISL', lawText: 'Los extintores deben tener mantención vigente y estar señalizados.', riskText: 'Extintores vencidos o inaccesibles son inútiles en emergencia.', adviceText: 'Verifica fechas de recarga y solicita reposición si es necesario.' },
      { id: 'item-5-3', categoryId: 'cat-5', question: '¿Las salidas de emergencia están despejadas y señalizadas?', order: 3, weight: 1.4, lawSource: 'Ordenanza General de Urbanismo y Construcciones', lawText: 'Las vías de evacuación deben mantenerse libres.', riskText: 'Salidas bloqueadas pueden causar tragedias en emergencias.', adviceText: 'Reporta inmediatamente cualquier obstrucción de vías de evacuación.' },
      { id: 'item-5-4', categoryId: 'cat-5', question: '¿Existe alumbrado de emergencia funcional?', order: 4, weight: 1.1, lawSource: 'Normas SEC', lawText: 'Los edificios deben tener iluminación de emergencia.', riskText: 'Sin iluminación de emergencia, la evacuación nocturna es peligrosa.', adviceText: 'Solicita pruebas periódicas del sistema de emergencia.' },
      { id: 'item-5-5', categoryId: 'cat-5', question: '¿Se realizan simulacros de emergencia?', order: 5, weight: 1.0, lawSource: 'Normas ISL', lawText: 'Se recomienda realizar simulacros periódicos.', riskText: 'Sin práctica, la respuesta ante emergencia será inadecuada.', adviceText: 'Propón simulacros al menos semestrales con todos los residentes.' },

      // Category 6: Relaciones Laborales
      { id: 'item-6-1', categoryId: 'cat-6', question: '¿El personal tiene contratos laborales vigentes?', order: 1, weight: 1.5, lawSource: 'Código del Trabajo', lawText: 'Todo trabajador debe tener contrato escrito.', riskText: 'Trabajadores sin contrato generan multas y problemas legales.', adviceText: 'Verifica que existan contratos de trabajo para todo el personal.' },
      { id: 'item-6-2', categoryId: 'cat-6', question: '¿Se pagan las cotizaciones previsionales al día?', order: 2, weight: 1.4, lawSource: 'Código del Trabajo, AFP', lawText: 'Las cotizaciones deben pagarse dentro de los plazos legales.', riskText: 'Cotizaciones impagas generan reajustes, intereses y multas.', adviceText: 'Solicita certificados de pago de cotizaciones al administrador.' },
      { id: 'item-6-3', categoryId: 'cat-6', question: '¿El personal tiene sus seguros de accidentes vigentes?', order: 3, weight: 1.2, lawSource: 'Ley 16.744 (Accidentes del Trabajo)', lawText: 'Todo empleador debe tener seguro contra riesgos de accidentes.', riskText: 'Sin seguro, el condominio debe asumir costos de accidentes laborales.', adviceText: 'Verifica que el personal esté afiliado a una mutualidad.' },
      { id: 'item-6-4', categoryId: 'cat-6', question: '¿Se respetan los horarios y descansos del personal?', order: 4, weight: 1.0, lawSource: 'Código del Trabajo', lawText: 'Los trabajadores tienen derecho a jornada máxima y descansos.', riskText: 'Incumplimientos generan denuncias y multas de la Dirección del Trabajo.', adviceText: 'Asegúrate de que existan registros de asistencia y control de jornada.' },
      { id: 'item-6-5', categoryId: 'cat-6', question: '¿Existe reglamento interno de orden, higiene y seguridad?', order: 5, weight: 0.9, lawSource: 'Código del Trabajo, Art. 153', lawText: 'Empresas con más de 10 trabajadores deben tener reglamento interno.', riskText: 'Sin reglamento, no hay claridad sobre obligaciones y derechos laborales.', adviceText: 'Propón la creación del reglamento si no existe.' },

      // Category 7: Medio Ambiente
      { id: 'item-7-1', categoryId: 'cat-7', question: '¿Existe sistema de reciclaje en el condominio?', order: 1, weight: 1.0, lawSource: 'Ley REP', lawText: 'Se promueve el reciclaje y gestión responsable de residuos.', riskText: 'Sin reciclaje, contribuyes a la contaminación y desperdicio.', adviceText: 'Propón puntos de reciclaje y capacitación a los residentes.' },
      { id: 'item-7-2', categoryId: 'cat-7', question: '¿Hay control del consumo de agua y energía?', order: 2, weight: 1.0, lawSource: 'Normas de Eficiencia Energética', lawText: 'Se recomienda implementar medidas de ahorro.', riskText: 'Consumo excesivo aumenta gastos comunes y daño ambiental.', adviceText: 'Propone medidores individuales y campañas de ahorro.' },
      { id: 'item-7-3', categoryId: 'cat-7', question: '¿Los residuos peligrosos se gestionan correctamente?', order: 3, weight: 1.2, lawSource: 'Ley sobre Residuos Peligrosos', lawText: 'Los residuos peligrosos requieren manejo especial.', riskText: 'Residuos mal gestionados pueden causar contaminación y multas.', adviceText: 'Verifica que aceites, baterías y otros residuos tengan disposición correcta.' },
      { id: 'item-7-4', categoryId: 'cat-7', question: '¿Se realizan actividades de concientización ambiental?', order: 4, weight: 0.8, lawSource: 'Ley de Medio Ambiente', lawText: 'Se promueve la educación ambiental.', riskText: 'Falta de concientización perpetúa malos hábitos.', adviceText: 'Propone charlas y actividades ambientales para residentes.' },
      { id: 'item-7-5', categoryId: 'cat-7', question: '¿Existe iluminación eficiente en áreas comunes?', order: 5, weight: 0.9, lawSource: 'Normas SEC de Eficiencia', lawText: 'Se recomienda uso de tecnología eficiente.', riskText: 'Iluminación ineficiente aumenta costos y huella de carbono.', adviceText: 'Propone cambio a LED y sensores de movimiento.' },
    ];

    for (const item of items) {
      await db.diagnosticItem.upsert({
        where: { id: item.id },
        update: {},
        create: item,
      });
    }

    // Create sample posts
    const posts = [
      {
        id: 'post-1',
        authorId: users[0].id,
        title: 'Nueva Ley de Copropiedad: Lo que debes saber',
        slug: 'nueva-ley-copropiedad-lo-que-debes-saber',
        excerpt: 'Conoce los principales cambios de la Ley 21.442 y cómo afectan tu vida en comunidad.',
        content: `# Nueva Ley de Copropiedad: Lo que debes saber

La Ley 21.442, promulgada en abril de 2022, moderniza el régimen de copropiedad inmobiliaria en Chile. Estos son los cambios más importantes:

## Principales novedades

### 1. Registro de Administradores
Ahora los administradores de condominios deben inscribirse en un registro público del Ministerio de Vivienda. Esto garantiza transparencia y profesionalismo.

### 2. Asambleas Electrónicas
Se permite la realización de asambleas virtuales, facilitando la participación de copropietarios.

### 3. Fondo de Reserva
Es obligatorio constituir un fondo de reserva para emergencias, evitando cuotas sorpresivas.

### 4. Mayor transparencia
Los administradores deben rendir cuentas documentadas y los copropietarios tienen derecho a acceder a la información.

## ¿Cómo te afecta?

Como copropietario, tienes más herramientas para fiscalizar y participar en la gestión de tu comunidad. ¡Infórmate y participa!`,
        category: 'ley',
        tags: JSON.stringify(['ley', 'copropiedad', 'normativa']),
        isPublished: true,
        isFeatured: true,
        publishedAt: new Date(),
      },
      {
        id: 'post-2',
        authorId: users[0].id,
        title: 'Guía: Cómo participar activamente en tu asamblea',
        slug: 'guia-como-participar-asamblea',
        excerpt: 'Aprende a ejercer tus derechos en las asambleas de copropietarios.',
        content: `# Guía: Cómo participar activamente en tu asamblea

Las asambleas son el órgano máximo de decisión en un condominio. Tu participación es fundamental.

## Antes de la asamblea

1. Revisa la citación y el orden del día
2. Infórmate sobre los temas a tratar
3. Prepara tus preguntas y propuestas

## Durante la asamblea

1. Llega puntual o conecta a tiempo
2. Escucha activamente las exposiciones
3. Formula tus preguntas claramente
4. Vota informado

## Después de la asamblea

1. Revisa el acta de acuerdos
2. Cumple los compromisos adquiridos
3. Fiscaliza el cumplimiento de los acuerdos`,
        category: 'guia',
        tags: JSON.stringify(['asamblea', 'participación', 'consejos']),
        isPublished: true,
        isFeatured: true,
        publishedAt: new Date(Date.now() - 86400000),
      },
      {
        id: 'post-3',
        authorId: users[0].id,
        title: 'Gastos comunes: ¿Cómo se calculan y qué incluyen?',
        slug: 'gastos-comunes-calculo-inclusion',
        excerpt: 'Entiende cómo se determinan los gastos comunes y qué elementos deben considerarse.',
        content: `# Gastos comunes: ¿Cómo se calculan y qué incluyen?

Los gastos comunes son las obligaciones económicas que todos los copropietarios deben cubrir para el funcionamiento del condominio.

## Tipos de gastos comunes

### Gastos Ordinarios
Son los regulares y previsibles:
- Mantención de áreas comunes
- Sueldos del personal
- Servicios básicos (luz, agua, gas)
- Seguros obligatorios

### Gastos Extraordinarios
Son eventuales o de mayor envergadura:
- Reparaciones mayores
- Mejoras estructurales
- Litigios legales

## ¿Cómo se prorratean?

El prorrateo se hace según los porcentajes establecidos en el reglamento de copropiedad, generalmente basados en la superficie de cada unidad.`,
        category: 'articulo',
        tags: JSON.stringify(['gastos', 'finanzas', 'administración']),
        isPublished: true,
        isFeatured: false,
        publishedAt: new Date(Date.now() - 172800000),
      },
    ];

    for (const post of posts) {
      await db.post.upsert({
        where: { id: post.id },
        update: {},
        create: post,
      });
    }

    // Create law sources
    const lawSources = [
      { name: 'Ley 21.442 - Copropiedad Inmobiliaria', description: 'Nueva ley que regula los condominios en Chile', url: 'https://www.bcn.cl/leychile/navegar?idNorma=1174663', type: 'ley' },
      { name: 'Código del Trabajo', description: 'Normativa laboral aplicable a personal de condominios', url: 'https://www.bcn.cl/leychile/navegar?idNorma=207436', type: 'ley' },
      { name: 'Ley 16.744 - Accidentes del Trabajo', description: 'Seguro contra riesgos de accidentes laborales', url: 'https://www.bcn.cl/leychile/navegar?idNorma=28650', type: 'ley' },
      { name: 'Normas ISL', description: 'Instituto de Seguridad Laboral - Normas de seguridad', url: 'https://www.isl.gob.cl', type: 'norma' },
      { name: 'Dirección del Trabajo', description: 'Entidad fiscalizadora de normas laborales', url: 'https://www.dt.gob.cl', type: 'oficial' },
    ];

    for (const source of lawSources) {
      await db.lawSource.upsert({
        where: { id: source.name.toLowerCase().replace(/\s+/g, '-') },
        update: {},
        create: { id: source.name.toLowerCase().replace(/\s+/g, '-'), ...source },
      });
    }

    // Skip marketplace and studies for now - models not available yet
    // These will be seeded separately after server restart
    
    // Create sample interviews
    const interviews = [
      {
        id: 'interview-1',
        authorId: users[0].id,
        title: 'El rol del administrador en la nueva Ley de Copropiedad',
        slug: 'rol-administrador-nueva-ley-copropiedad',
        excerpt: 'Conversamos con un experto en administración de condominios sobre los cambios que trae la Ley 21.442.',
        content: `# El rol del administrador en la nueva Ley de Copropiedad

## Entrevista con Roberto Sánchez, Administrador Certificado

**P: ¿Cuáles son los principales cambios que trae la nueva ley para los administradores?**

R: La Ley 21.442 establece requisitos más estrictos para los administradores. Ahora es obligatorio llevar registros actualizados, rendir cuentas periódicamente y mantener transparencia en la gestión.

**P: ¿Qué documentos debe mantener el administrador?**

R: Los documentos esenciales son:
- Registro de copropietarios actualizado
- Actas de asambleas
- Estados financieros mensuales
- Contratos vigentes
- Pólizas de seguro

**P: ¿Con qué frecuencia se deben rendir cuentas?**

R: La ley establece que se debe rendir cuentas al menos una vez al año en asamblea ordinaria, pero lo recomendable es hacerlo semestralmente.

**P: ¿Qué sucede si el administrador no cumple sus obligaciones?**

R: Los copropietarios pueden solicitar su remoción en asamblea extraordinaria. Además, puede enfrentar sanciones legales si se determina negligencia o mal uso de fondos.`,
        intervieweeName: 'Roberto Sánchez',
        intervieweeRole: 'Administrador de Condominios Certificado - 15 años de experiencia',
        category: 'experto',
        duration: 25,
        isPublished: true,
        isFeatured: true,
        publishedAt: new Date(Date.now() - 86400000),
      },
      {
        id: 'interview-2',
        authorId: users[0].id,
        title: 'Mi experiencia como presidente del comité de administración',
        slug: 'experiencia-presidente-comite-administracion',
        excerpt: 'María nos cuenta cómo transformó su condominio a través de la participación activa.',
        content: `# Mi experiencia como presidente del comité de administración

## Conversación con María López, Copropietaria

**P: ¿Cómo decidiste postularte al comité?**

R: Todo empezó cuando noté que no sabíamos en qué se gastaba nuestro dinero. Los gastos comunes subían cada mes y nadie explicaba por qué. Decidí que tenía que hacer algo.

**P: ¿Qué cambios implementaron?**

R: Lo primero fue transparencia. Implementamos:
- Envío mensual de estados de cuenta por email
- Reuniones trimestrales abiertas
- Un grupo de WhatsApp para comunicaciones oficiales
- Presupuesto participativo anual

**P: ¿Fue difícil lograr el quórum en las asambleas?**

R: Al principio sí, pero cuando la gente vio que sus opiniones importaban, empezaron a participar más. Pasamos de 20% de asistencia a más del 60%.

**P: ¿Qué consejo darías a otros copropietarios?**

R: Que no esperen a que los problemas se acumulen. La participación es clave. Un copropietario informado es un mejor vecino.`,
        intervieweeName: 'María López',
        intervieweeRole: 'Presidenta del Comité de Administración - Edificio Los Alerces',
        category: 'copropietario',
        duration: 18,
        isPublished: true,
        isFeatured: true,
        publishedAt: new Date(Date.now() - 172800000),
      },
      {
        id: 'interview-3',
        authorId: users[0].id,
        title: 'Derechos laborales del personal de condominios',
        slug: 'derechos-laborales-personal-condominios',
        excerpt: 'Una abogada laboral nos explica las obligaciones de los condominios como empleadores.',
        content: `# Derechos laborales del personal de condominios

## Entrevista con Dra. Carolina Muñoz, Abogada Laboralista

**P: ¿Qué normas aplican al personal de condominios?**

R: El personal de condominios está protegido por el Código del Trabajo y la Ley 16.744 sobre accidentes laborales. Los condominios son empleadores y deben cumplir todas las obligaciones que eso implica.

**P: ¿Cuáles son las obligaciones principales?**

R: Las obligaciones fundamentales incluyen:
- Contrato de trabajo escrito
- Cotizaciones previsionales y de salud
- Seguro de accidentes del trabajo
- Vacaciones anuales
- Aguinaldos obligatorios

**P: ¿Qué pasa con los conserjes que viven en el edificio?**

R: Es un tema complejo. Si el conserje vive en el edificio, se considera "trabajador de casa particular" y tiene derecho a una habitación digna, además de sus remuneraciones.

**P: ¿Qué riesgos legales enfrenta un condominio que no cumple?**

R: Puede enfrentar multas de la Dirección del Trabajo, demandas laborales y responsabilidad solidaria. Es fundamental tener asesoría legal adecuada.`,
        intervieweeName: 'Dra. Carolina Muñoz',
        intervieweeRole: 'Abogada Laboralista - Especialista en derecho inmobiliario',
        category: 'profesional',
        duration: 30,
        isPublished: true,
        isFeatured: false,
        publishedAt: new Date(Date.now() - 259200000),
      },
    ];

    for (const interview of interviews) {
      await db.interview.upsert({
        where: { id: interview.id },
        update: {},
        create: interview,
      });
    }
    
    return NextResponse.json({
      success: true,
      message: 'Base de datos poblada exitosamente. Reinicia el servidor para activar nuevas tablas.',
      data: {
        users: users.length,
        types: types.length,
        categories: categories.length,
        items: items.length,
        posts: posts.length,
        lawSources: lawSources.length,
        marketplaceCategories: 0,
        products: 0,
        studies: 0,
        interviews: interviews.length,
      },
      credentials: {
        admin: { email: 'admin@condominio.cl', password: 'admin123' },
        user: { email: 'usuario@condominio.cl', password: 'user123' },
      },
    });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json(
      { error: 'Error al poblar base de datos', details: String(error) },
      { status: 500 }
    );
  }
}
