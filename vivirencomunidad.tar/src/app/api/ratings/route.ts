import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const session = cookieStore.get('session');

    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = JSON.parse(session.value);
    const body = await request.json();
    const { postId, value } = body;

    if (!postId || value === undefined) {
      return NextResponse.json(
        { error: 'Post ID y valor son requeridos' },
        { status: 400 }
      );
    }

    // Check if user already rated
    const existingRating = await db.rating.findUnique({
      where: {
        postId_userId: { postId, userId: user.id },
      },
    });

    if (existingRating) {
      const rating = await db.rating.update({
        where: { id: existingRating.id },
        data: { value },
      });
      return NextResponse.json({ rating });
    }

    const rating = await db.rating.create({
      data: {
        postId,
        userId: user.id,
        value,
      },
    });

    return NextResponse.json({ rating });
  } catch (error) {
    console.error('Error creating rating:', error);
    return NextResponse.json(
      { error: 'Error al crear valoración' },
      { status: 500 }
    );
  }
}
