"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import {
  ExternalLink,
  Play,
  Pause,
  CheckCircle2,
  AlertCircle,
  Info,
  AlertTriangle,
  Lightbulb,
  Quote as QuoteIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  BarChart3,
  Link as LinkIcon,
} from "lucide-react";
import type { ContentBlock } from "@/types/blocks";

// Helper function to safely render HTML content
function sanitizeHtml(html: string): string {
  if (!html) return '';
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)[^]*)*<\/script>/gi, '') // Remove scripts
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+="[^"]*"/gi, '') // Remove event handlers
    .replace(/on\w+=/gi, ''); // Remove event handlers without quotes
}

// Quote Block Renderer
function QuoteBlockRenderer({ block }: { block: ContentBlock & { type: 'quote' } }) {
  const styles = {
    default: "border-l-4 border-purple-500 bg-purple-50 dark:bg-purple-900/20",
    highlighted: "bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-200 dark:border-purple-800 rounded-xl",
    minimal: "bg-muted/50",
  };

  return (
    <blockquote className={`p-6 my-6 ${styles[block.style || 'default']}`}>
      <QuoteIcon className="w-8 h-8 text-purple-400 mb-4" />
      <p className="text-lg italic mb-4">{block.content}</p>
      {(block.author || block.source) && (
        <footer className="flex items-center gap-2 text-sm text-muted-foreground">
          {block.author && <cite className="font-medium not-italic">— {block.author}</cite>}
          {block.source && <span>, {block.source}</span>}
        </footer>
      )}
    </blockquote>
  );
}

// Table Block Renderer
function TableBlockRenderer({ block }: { block: ContentBlock & { type: 'table' } }) {
  return (
    <div className="my-6 overflow-x-auto">
      {block.caption && <p className="text-sm text-muted-foreground mb-2">{block.caption}</p>}
      <table className={`w-full ${block.bordered ? 'border' : ''}`}>
        <thead>
          <tr className="bg-muted/50">
            {block.headers.map((header, i) => (
              <th key={i} className="p-3 text-left font-medium border-b">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {block.rows.map((row, rowIndex) => (
            <tr key={rowIndex} className={block.striped && rowIndex % 2 === 1 ? 'bg-muted/30' : ''}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} className="p-3 border-b">
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Timeline Block Renderer
function TimelineBlockRenderer({ block }: { block: ContentBlock & { type: 'timeline' } }) {
  const isVertical = block.style !== 'horizontal';

  return (
    <div className="my-8">
      <div className={isVertical ? "space-y-6" : "flex gap-6 overflow-x-auto pb-4"}>
        {block.events.map((event, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: isVertical ? -20 : 0, y: isVertical ? 0 : 20 }}
            whileInView={{ opacity: 1, x: 0, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className={isVertical ? "flex gap-4" : "flex-shrink-0 w-64"}
          >
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                {event.icon || index + 1}
              </div>
              {index < block.events.length - 1 && isVertical && (
                <div className="w-0.5 h-full bg-gradient-to-b from-purple-500 to-transparent min-h-[40px]" />
              )}
            </div>
            <div className="flex-1 pb-6">
              <Badge variant="outline" className="mb-2">
                <Clock className="w-3 h-3 mr-1" />
                {event.date}
              </Badge>
              <h4 className="font-semibold mb-1">{event.title}</h4>
              {event.description && (
                <p className="text-sm text-muted-foreground">{event.description}</p>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Poll Block Renderer
function PollBlockRenderer({ block }: { block: ContentBlock & { type: 'poll' } }) {
  const [votes, setVotes] = useState<Record<number, number>>({});
  const [totalVotes, setTotalVotes] = useState(0);
  const [hasVoted, setHasVoted] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (block.pollId) {
      fetch(`/api/polls/${block.pollId}`)
        .then(res => res.json())
        .then(data => {
          if (data.poll) {
            setVotes(data.poll.votes);
            setTotalVotes(data.poll.totalVotes);
          }
        })
        .catch(console.error);
    }
  }, [block.pollId]);

  const handleVote = async (optionIndex: number) => {
    if (hasVoted && !block.allowMultiple) return;
    
    setLoading(true);
    try {
      const res = await fetch(`/api/polls/${block.pollId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ option: optionIndex }),
      });
      const data = await res.json();
      if (data.success) {
        setVotes(data.results.votes);
        setTotalVotes(data.results.totalVotes);
        setHasVoted(true);
        toast.success("¡Voto registrado!");
      }
    } catch {
      toast.error("Error al votar");
    } finally {
      setLoading(false);
    }
  };

  const getPercentage = (index: number) => {
    if (totalVotes === 0) return 0;
    return Math.round(((votes[index] || 0) / totalVotes) * 100);
  };

  return (
    <Card className="my-6">
      <CardHeader>
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-purple-500" />
          <h3 className="font-semibold">{block.question}</h3>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {block.options.map((option, index) => (
          <div key={index}>
            <button
              onClick={() => handleVote(index)}
              disabled={loading || (hasVoted && !block.allowMultiple)}
              className={`w-full text-left p-4 rounded-lg border transition-all ${
                hasVoted ? 'bg-muted' : 'hover:bg-muted/50 hover:border-purple-300'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <span>{option}</span>
                {hasVoted && (
                  <Badge variant="secondary">
                    {getPercentage(index)}%
                  </Badge>
                )}
              </div>
              {hasVoted && (
                <Progress value={getPercentage(index)} className="h-2" />
              )}
            </button>
          </div>
        ))}
        <p className="text-sm text-muted-foreground text-center">
          {totalVotes} voto{totalVotes !== 1 ? 's' : ''}
        </p>
      </CardContent>
    </Card>
  );
}

// Link Block Renderer
function LinkBlockRenderer({ block }: { block: ContentBlock & { type: 'link' } }) {
  if (block.style === 'button') {
    return (
      <div className="my-6">
        <Button asChild className="bg-gradient-to-r from-purple-500 to-pink-500">
          <a href={block.url} target="_blank" rel="noopener noreferrer">
            <LinkIcon className="w-4 h-4 mr-2" />
            {block.title}
          </a>
        </Button>
      </div>
    );
  }

  if (block.style === 'inline') {
    return (
      <a
        href={block.url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-purple-600 dark:text-purple-400 hover:underline"
      >
        {block.title}
      </a>
    );
  }

  // Card style
  return (
    <Card className="my-6 overflow-hidden hover:shadow-lg transition-shadow">
      <a href={block.url} target="_blank" rel="noopener noreferrer" className="block">
        {block.imageUrl && (
          <div className="h-40 bg-gradient-to-br from-purple-500/20 to-pink-500/20 relative">
            <img src={block.imageUrl} alt="" className="w-full h-full object-cover" />
          </div>
        )}
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/30">
              <ExternalLink className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h4 className="font-semibold mb-1">{block.title}</h4>
              {block.description && (
                <p className="text-sm text-muted-foreground">{block.description}</p>
              )}
              <p className="text-xs text-muted-foreground mt-2 truncate">
                {new URL(block.url).hostname}
              </p>
            </div>
          </div>
        </CardContent>
      </a>
    </Card>
  );
}

// List Block Renderer
function ListBlockRenderer({ block }: { block: ContentBlock & { type: 'list' } }) {
  const ListTag = block.ordered ? 'ol' : 'ul';
  
  const listStyles = {
    default: block.ordered ? 'list-decimal' : 'list-disc',
    checklist: 'list-none',
    steps: 'list-none space-y-4',
  };

  if (block.style === 'checklist') {
    return (
      <ul className="my-6 space-y-2">
        {block.items.map((item, index) => (
          <li key={index} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50">
            <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
            <span dangerouslySetInnerHTML={{ __html: sanitizeHtml(item) }} />
          </li>
        ))}
      </ul>
    );
  }

  if (block.style === 'steps') {
    return (
      <div className="my-6 space-y-4">
        {block.items.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="flex gap-4"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-sm shrink-0">
              {index + 1}
            </div>
            <div className="flex-1 pt-1" dangerouslySetInnerHTML={{ __html: sanitizeHtml(item) }} />
          </motion.div>
        ))}
      </div>
    );
  }

  return (
    <ListTag className={`my-6 ml-6 ${listStyles[block.style || 'default']} space-y-2`}>
      {block.items.map((item, index) => (
        <li key={index} dangerouslySetInnerHTML={{ __html: sanitizeHtml(item) }} />
      ))}
    </ListTag>
  );
}

// Code Block Renderer
function CodeBlockRenderer({ block }: { block: ContentBlock & { type: 'code' } }) {
  return (
    <div className="my-6">
      {block.filename && (
        <div className="bg-muted rounded-t-lg px-4 py-2 text-sm font-mono border-b">
          {block.filename}
        </div>
      )}
      <pre className={`bg-gray-900 text-gray-100 p-4 overflow-x-auto ${block.filename ? 'rounded-t-none' : 'rounded-lg'}`}>
        {block.showLineNumbers ? (
          <code>
            {block.code.split('\n').map((line, i) => (
              <div key={i} className="table-row">
                <span className="table-cell text-gray-500 select-none pr-4 text-right">
                  {i + 1}
                </span>
                <span className="table-cell">{line}</span>
              </div>
            ))}
          </code>
        ) : (
          <code>{block.code}</code>
        )}
      </pre>
    </div>
  );
}

// Divider Block Renderer
function DividerBlockRenderer({ block }: { block: ContentBlock & { type: 'divider' } }) {
  const styles = {
    line: <hr className="my-8 border-t" />,
    dots: (
      <div className="my-8 flex justify-center gap-2">
        <span className="w-2 h-2 rounded-full bg-muted-foreground/30" />
        <span className="w-2 h-2 rounded-full bg-muted-foreground/30" />
        <span className="w-2 h-2 rounded-full bg-muted-foreground/30" />
      </div>
    ),
    gradient: (
      <div className="my-8 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent" />
    ),
  };

  return styles[block.style || 'line'];
}

// Callout Block Renderer
function CalloutBlockRenderer({ block }: { block: ContentBlock & { type: 'callout' } }) {
  const variants = {
    info: { icon: Info, color: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-200' },
    warning: { icon: AlertTriangle, color: 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200' },
    success: { icon: CheckCircle2, color: 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-800 dark:text-green-200' },
    error: { icon: AlertCircle, color: 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200' },
    tip: { icon: Lightbulb, color: 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800 text-purple-800 dark:text-purple-200' },
  };

  const variant = variants[block.variant || 'info'];
  const Icon = variant.icon;

  return (
    <div className={`my-6 p-4 rounded-lg border flex gap-3 ${variant.color}`}>
      <Icon className="w-5 h-5 shrink-0 mt-0.5" />
      <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(block.content) }} />
    </div>
  );
}

// Video Block Renderer
function VideoBlockRenderer({ block }: { block: ContentBlock & { type: 'video' } }) {
  const getEmbedUrl = () => {
    if (block.platform === 'youtube') {
      const videoId = block.url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]+)/)?.[1];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    if (block.platform === 'vimeo') {
      const videoId = block.url.match(/vimeo\.com\/(\d+)/)?.[1];
      return `https://player.vimeo.com/video/${videoId}`;
    }
    return block.url;
  };

  return (
    <div className="my-6">
      <div className="aspect-video rounded-lg overflow-hidden bg-muted">
        <iframe
          src={getEmbedUrl()}
          className="w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
      {block.caption && (
        <p className="text-sm text-muted-foreground text-center mt-2">{block.caption}</p>
      )}
    </div>
  );
}

// Image Block Renderer
function ImageBlockRenderer({ block }: { block: ContentBlock & { type: 'image' } }) {
  return (
    <figure className="my-6">
      <img
        src={block.url}
        alt={block.alt}
        className="rounded-lg w-full"
      />
      {block.caption && (
        <figcaption className="text-sm text-muted-foreground text-center mt-2">
          {block.caption}
        </figcaption>
      )}
    </figure>
  );
}

// Gallery Block Renderer
function GalleryBlockRenderer({ block }: { block: ContentBlock & { type: 'gallery' } }) {
  const cols = block.columns || 3;

  return (
    <div className="my-6 grid gap-4" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
      {block.images.map((img, index) => (
        <figure key={index}>
          <img
            src={img.url}
            alt={img.alt}
            className="rounded-lg w-full h-48 object-cover"
          />
          {img.caption && (
            <figcaption className="text-xs text-muted-foreground text-center mt-1">
              {img.caption}
            </figcaption>
          )}
        </figure>
      ))}
    </div>
  );
}

// Carousel Block Renderer
function CarouselBlockRenderer({ block }: { block: ContentBlock & { type: 'carousel' } }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(block.autoPlay);

  useEffect(() => {
    if (!isPlaying || block.images.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % block.images.length);
    }, block.interval || 5000);
    return () => clearInterval(interval);
  }, [isPlaying, block.images.length, block.interval]);

  const nextSlide = () => setCurrentIndex((prev) => (prev + 1) % block.images.length);
  const prevSlide = () => setCurrentIndex((prev) => (prev - 1 + block.images.length) % block.images.length);

  return (
    <div className="my-6 relative">
      <div className="aspect-video rounded-lg overflow-hidden bg-muted">
        <img
          src={block.images[currentIndex]?.url}
          alt={block.images[currentIndex]?.alt}
          className="w-full h-full object-cover transition-opacity duration-500"
        />
        {block.images[currentIndex]?.caption && (
          <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
            {block.images[currentIndex].caption}
          </div>
        )}
      </div>

      {/* Navigation */}
      {block.images.length > 1 && (
        <>
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Dots */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {block.images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentIndex ? 'bg-white w-4' : 'bg-white/50'
                }`}
              />
            ))}
          </div>

          {/* Play/Pause */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
        </>
      )}
    </div>
  );
}

// Embed Block Renderer
function EmbedBlockRenderer({ block }: { block: ContentBlock & { type: 'embed' } }) {
  return (
    <div className="my-6">
      {block.embedType === 'iframe' ? (
        <iframe
          src={block.url}
          width={block.width || '100%'}
          height={block.height || 400}
          className="rounded-lg border"
        />
      ) : (
        <div className="p-4 border rounded-lg bg-muted">
          <p className="text-sm text-muted-foreground mb-2">
            Contenido externo de {block.embedType}
          </p>
          <a
            href={block.url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-purple-600 hover:underline"
          >
            Ver contenido
          </a>
        </div>
      )}
    </div>
  );
}

// Main Block Renderer
export default function BlockRenderer({ blocks }: { blocks: ContentBlock[] }) {
  if (!blocks || blocks.length === 0) return null;

  return (
    <div className="block-content">
      {blocks.map((block) => {
        switch (block.type) {
          case 'paragraph':
            return (
              <p 
                key={block.id} 
                className="mb-4 leading-relaxed prose-content"
                dangerouslySetInnerHTML={{ __html: sanitizeHtml(block.content) }}
              />
            );
          case 'heading1':
            return (
              <h1 key={block.id} className="text-3xl font-bold mt-8 mb-4">
                {block.content}
              </h1>
            );
          case 'heading2':
            return (
              <h2 key={block.id} className="text-2xl font-semibold mt-6 mb-3">
                {block.content}
              </h2>
            );
          case 'heading3':
            return (
              <h3 key={block.id} className="text-xl font-medium mt-4 mb-2">
                {block.content}
              </h3>
            );
          case 'image':
            return <ImageBlockRenderer key={block.id} block={block} />;
          case 'gallery':
            return <GalleryBlockRenderer key={block.id} block={block} />;
          case 'carousel':
            return <CarouselBlockRenderer key={block.id} block={block} />;
          case 'video':
            return <VideoBlockRenderer key={block.id} block={block} />;
          case 'quote':
            return <QuoteBlockRenderer key={block.id} block={block} />;
          case 'table':
            return <TableBlockRenderer key={block.id} block={block} />;
          case 'timeline':
            return <TimelineBlockRenderer key={block.id} block={block} />;
          case 'poll':
            return <PollBlockRenderer key={block.id} block={block} />;
          case 'link':
            return <LinkBlockRenderer key={block.id} block={block} />;
          case 'list':
            return <ListBlockRenderer key={block.id} block={block} />;
          case 'code':
            return <CodeBlockRenderer key={block.id} block={block} />;
          case 'divider':
            return <DividerBlockRenderer key={block.id} block={block} />;
          case 'callout':
            return <CalloutBlockRenderer key={block.id} block={block} />;
          case 'embed':
            return <EmbedBlockRenderer key={block.id} block={block} />;
          default:
            return null;
        }
      })}
    </div>
  );
}
