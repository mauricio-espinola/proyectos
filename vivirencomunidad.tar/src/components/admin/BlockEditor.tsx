"use client";

import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Type,
  Heading1,
  Heading2,
  Heading3,
  Image as ImageIcon,
  Images,
  ImagePlus,
  Video,
  Music,
  Quote,
  Table,
  Clock,
  BarChart3,
  Link as LinkIcon,
  List,
  Code,
  Minus,
  AlertCircle,
  ExternalLink,
  Plus,
  GripVertical,
  Trash2,
  ChevronDown,
  MoveUp,
  MoveDown,
} from "lucide-react";
import type { ContentBlock, BlockType } from "@/types/blocks";
import { createBlock } from "@/types/blocks";

// Icon mapping
const blockIcons: Record<BlockType, React.ReactNode> = {
  paragraph: <Type className="w-4 h-4" />,
  heading1: <Heading1 className="w-4 h-4" />,
  heading2: <Heading2 className="w-4 h-4" />,
  heading3: <Heading3 className="w-4 h-4" />,
  image: <ImageIcon className="w-4 h-4" />,
  gallery: <Images className="w-4 h-4" />,
  carousel: <ImagePlus className="w-4 h-4" />,
  video: <Video className="w-4 h-4" />,
  audio: <Music className="w-4 h-4" />,
  quote: <Quote className="w-4 h-4" />,
  table: <Table className="w-4 h-4" />,
  timeline: <Clock className="w-4 h-4" />,
  poll: <BarChart3 className="w-4 h-4" />,
  link: <LinkIcon className="w-4 h-4" />,
  list: <List className="w-4 h-4" />,
  code: <Code className="w-4 h-4" />,
  divider: <Minus className="w-4 h-4" />,
  callout: <AlertCircle className="w-4 h-4" />,
  embed: <ExternalLink className="w-4 h-4" />,
};

// Block type configuration
const blockConfig: Record<BlockType, { label: string; description: string }> = {
  paragraph: { label: 'Párrafo', description: 'Texto simple' },
  heading1: { label: 'Título 1', description: 'Título principal' },
  heading2: { label: 'Título 2', description: 'Subtítulo' },
  heading3: { label: 'Título 3', description: 'Sub-subtítulo' },
  image: { label: 'Imagen', description: 'Imagen individual' },
  gallery: { label: 'Galería', description: 'Conjunto de imágenes' },
  carousel: { label: 'Carrusel', description: 'Imágenes en carrusel' },
  video: { label: 'Video', description: 'Video de YouTube/Vimeo' },
  audio: { label: 'Audio', description: 'Archivo de audio' },
  quote: { label: 'Cita', description: 'Cita destacada' },
  table: { label: 'Tabla', description: 'Tabla de datos' },
  timeline: { label: 'Timeline', description: 'Línea de tiempo' },
  poll: { label: 'Encuesta', description: 'Votación interactiva' },
  link: { label: 'Link', description: 'Enlace destacado' },
  list: { label: 'Lista', description: 'Lista de items' },
  code: { label: 'Código', description: 'Bloque de código' },
  divider: { label: 'Separador', description: 'Línea divisoria' },
  callout: { label: 'Destacado', description: 'Mensaje destacado' },
  embed: { label: 'Embed', description: 'Contenido externo' },
};

// Individual Block Editor
function BlockEditorItem({
  block,
  onUpdate,
  onDelete,
  onMoveUp,
  onMoveDown,
  isFirst,
  isLast,
}: {
  block: ContentBlock;
  onUpdate: (block: ContentBlock) => void;
  onDelete: () => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
  isFirst: boolean;
  isLast: boolean;
}) {
  const [isExpanded, setIsExpanded] = useState(true);

  const renderEditor = () => {
    switch (block.type) {
      case 'paragraph':
        return (
          <Textarea
            value={block.content}
            onChange={(e) => onUpdate({ ...block, content: e.target.value })}
            placeholder="Escribe el párrafo..."
            rows={3}
          />
        );

      case 'heading1':
      case 'heading2':
      case 'heading3':
        return (
          <Input
            value={block.content}
            onChange={(e) => onUpdate({ ...block, content: e.target.value })}
            placeholder="Escribe el título..."
          />
        );

      case 'image':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">URL de la imagen</Label>
              <Input
                value={block.url}
                onChange={(e) => onUpdate({ ...block, url: e.target.value })}
                placeholder="https://..."
              />
            </div>
            <div>
              <Label className="text-xs">Texto alternativo</Label>
              <Input
                value={block.alt}
                onChange={(e) => onUpdate({ ...block, alt: e.target.value })}
                placeholder="Descripción de la imagen"
              />
            </div>
            <div>
              <Label className="text-xs">Leyenda (opcional)</Label>
              <Input
                value={block.caption || ''}
                onChange={(e) => onUpdate({ ...block, caption: e.target.value })}
                placeholder="Texto debajo de la imagen"
              />
            </div>
          </div>
        );

      case 'quote':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Cita</Label>
              <Textarea
                value={block.content}
                onChange={(e) => onUpdate({ ...block, content: e.target.value })}
                placeholder="La cita textual..."
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Autor</Label>
                <Input
                  value={block.author || ''}
                  onChange={(e) => onUpdate({ ...block, author: e.target.value })}
                  placeholder="Nombre del autor"
                />
              </div>
              <div>
                <Label className="text-xs">Fuente</Label>
                <Input
                  value={block.source || ''}
                  onChange={(e) => onUpdate({ ...block, source: e.target.value })}
                  placeholder="Fuente original"
                />
              </div>
            </div>
          </div>
        );

      case 'table':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Encabezados (separados por coma)</Label>
              <Input
                value={block.headers.join(', ')}
                onChange={(e) => onUpdate({ ...block, headers: e.target.value.split(',').map(h => h.trim()) })}
                placeholder="Columna 1, Columna 2, Columna 3"
              />
            </div>
            <div>
              <Label className="text-xs">Filas (una por línea, valores separados por coma)</Label>
              <Textarea
                value={block.rows.map(r => r.join(', ')).join('\n')}
                onChange={(e) => onUpdate({
                  ...block,
                  rows: e.target.value.split('\n').map(line => line.split(',').map(cell => cell.trim()))
                })}
                placeholder="Fila 1 Col 1, Fila 1 Col 2&#10;Fila 2 Col 1, Fila 2 Col 2"
                rows={4}
              />
            </div>
            <div>
              <Label className="text-xs">Título de la tabla</Label>
              <Input
                value={block.caption || ''}
                onChange={(e) => onUpdate({ ...block, caption: e.target.value })}
                placeholder="Descripción de la tabla"
              />
            </div>
          </div>
        );

      case 'timeline':
        return (
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label className="text-xs">Eventos</Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUpdate({
                  ...block,
                  events: [...block.events, { date: '', title: '', description: '' }]
                })}
              >
                <Plus className="w-3 h-3 mr-1" /> Agregar
              </Button>
            </div>
            {block.events.map((event, index) => (
              <div key={index} className="border rounded-lg p-3 space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs font-medium">Evento {index + 1}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onUpdate({
                      ...block,
                      events: block.events.filter((_, i) => i !== index)
                    })}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    value={event.date}
                    onChange={(e) => onUpdate({
                      ...block,
                      events: block.events.map((ev, i) => i === index ? { ...ev, date: e.target.value } : ev)
                    })}
                    placeholder="Fecha"
                  />
                  <Input
                    value={event.title}
                    onChange={(e) => onUpdate({
                      ...block,
                      events: block.events.map((ev, i) => i === index ? { ...ev, title: e.target.value } : ev)
                    })}
                    placeholder="Título"
                  />
                </div>
                <Textarea
                  value={event.description || ''}
                  onChange={(e) => onUpdate({
                    ...block,
                    events: block.events.map((ev, i) => i === index ? { ...ev, description: e.target.value } : ev)
                  })}
                  placeholder="Descripción"
                  rows={2}
                />
              </div>
            ))}
          </div>
        );

      case 'poll':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Pregunta</Label>
              <Input
                value={block.question}
                onChange={(e) => onUpdate({ ...block, question: e.target.value })}
                placeholder="¿Cuál es tu opinión sobre...?"
              />
            </div>
            <div>
              <Label className="text-xs">Opciones (una por línea)</Label>
              <Textarea
                value={block.options.join('\n')}
                onChange={(e) => onUpdate({ ...block, options: e.target.value.split('\n').filter(o => o.trim()) })}
                placeholder="Opción 1&#10;Opción 2&#10;Opción 3"
                rows={4}
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={block.allowMultiple || false}
                onChange={(e) => onUpdate({ ...block, allowMultiple: e.target.checked })}
                className="rounded"
              />
              <Label className="text-xs">Permitir múltiples respuestas</Label>
            </div>
          </div>
        );

      case 'link':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">URL</Label>
              <Input
                value={block.url}
                onChange={(e) => onUpdate({ ...block, url: e.target.value })}
                placeholder="https://..."
              />
            </div>
            <div>
              <Label className="text-xs">Título</Label>
              <Input
                value={block.title}
                onChange={(e) => onUpdate({ ...block, title: e.target.value })}
                placeholder="Título del enlace"
              />
            </div>
            <div>
              <Label className="text-xs">Descripción</Label>
              <Textarea
                value={block.description || ''}
                onChange={(e) => onUpdate({ ...block, description: e.target.value })}
                placeholder="Descripción del contenido..."
                rows={2}
              />
            </div>
          </div>
        );

      case 'list':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Items (uno por línea)</Label>
              <Textarea
                value={block.items.join('\n')}
                onChange={(e) => onUpdate({ ...block, items: e.target.value.split('\n').filter(i => i.trim()) })}
                placeholder="Item 1&#10;Item 2&#10;Item 3"
                rows={4}
              />
            </div>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={block.ordered || false}
                  onChange={(e) => onUpdate({ ...block, ordered: e.target.checked })}
                  className="rounded"
                />
                <Label className="text-xs">Numerada</Label>
              </div>
            </div>
          </div>
        );

      case 'code':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Código</Label>
              <Textarea
                value={block.code}
                onChange={(e) => onUpdate({ ...block, code: e.target.value })}
                placeholder="Tu código aquí..."
                rows={6}
                className="font-mono text-sm"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Lenguaje</Label>
                <Select
                  value={block.language || 'javascript'}
                  onValueChange={(value) => onUpdate({ ...block, language: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="typescript">TypeScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="html">HTML</SelectItem>
                    <SelectItem value="css">CSS</SelectItem>
                    <SelectItem value="sql">SQL</SelectItem>
                    <SelectItem value="bash">Bash</SelectItem>
                    <SelectItem value="json">JSON</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Nombre archivo</Label>
                <Input
                  value={block.filename || ''}
                  onChange={(e) => onUpdate({ ...block, filename: e.target.value })}
                  placeholder="script.js"
                />
              </div>
            </div>
          </div>
        );

      case 'callout':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Contenido</Label>
              <Textarea
                value={block.content}
                onChange={(e) => onUpdate({ ...block, content: e.target.value })}
                placeholder="Mensaje destacado..."
                rows={3}
              />
            </div>
            <div>
              <Label className="text-xs">Tipo</Label>
              <Select
                value={block.variant || 'info'}
                onValueChange={(value: 'info' | 'warning' | 'success' | 'error' | 'tip') => onUpdate({ ...block, variant: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">Información</SelectItem>
                  <SelectItem value="warning">Advertencia</SelectItem>
                  <SelectItem value="success">Éxito</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="tip">Consejo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case 'video':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">URL del video</Label>
              <Input
                value={block.url}
                onChange={(e) => onUpdate({ ...block, url: e.target.value })}
                placeholder="https://youtube.com/watch?v=..."
              />
            </div>
            <div>
              <Label className="text-xs">Plataforma</Label>
              <Select
                value={block.platform}
                onValueChange={(value: 'youtube' | 'vimeo' | 'custom') => onUpdate({ ...block, platform: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="youtube">YouTube</SelectItem>
                  <SelectItem value="vimeo">Vimeo</SelectItem>
                  <SelectItem value="custom">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case 'divider':
        return (
          <div>
            <Label className="text-xs">Estilo</Label>
            <Select
              value={block.style || 'line'}
              onValueChange={(value: 'line' | 'dots' | 'gradient') => onUpdate({ ...block, style: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="line">Línea</SelectItem>
                <SelectItem value="dots">Puntos</SelectItem>
                <SelectItem value="gradient">Degradado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );

      case 'carousel':
      case 'gallery':
        return (
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label className="text-xs">Imágenes</Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUpdate({
                  ...block,
                  images: [...block.images, { url: '', alt: '', caption: '' }]
                })}
              >
                <Plus className="w-3 h-3 mr-1" /> Agregar
              </Button>
            </div>
            {block.images.map((img, index) => (
              <div key={index} className="border rounded-lg p-3 space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs font-medium">Imagen {index + 1}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onUpdate({
                      ...block,
                      images: block.images.filter((_, i) => i !== index)
                    })}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
                <Input
                  value={img.url}
                  onChange={(e) => onUpdate({
                    ...block,
                    images: block.images.map((im, i) => i === index ? { ...im, url: e.target.value } : im)
                  })}
                  placeholder="URL de la imagen"
                />
                <Input
                  value={img.alt}
                  onChange={(e) => onUpdate({
                    ...block,
                    images: block.images.map((im, i) => i === index ? { ...im, alt: e.target.value } : im)
                  })}
                  placeholder="Texto alternativo"
                />
              </div>
            ))}
          </div>
        );

      case 'embed':
        return (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">URL</Label>
              <Input
                value={block.url}
                onChange={(e) => onUpdate({ ...block, url: e.target.value })}
                placeholder="URL del contenido a incrustar"
              />
            </div>
            <div>
              <Label className="text-xs">Tipo</Label>
              <Select
                value={block.embedType}
                onValueChange={(value: 'twitter' | 'instagram' | 'facebook' | 'spotify' | 'maps' | 'iframe') => onUpdate({ ...block, embedType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="twitter">Twitter/X</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                  <SelectItem value="facebook">Facebook</SelectItem>
                  <SelectItem value="spotify">Spotify</SelectItem>
                  <SelectItem value="maps">Google Maps</SelectItem>
                  <SelectItem value="iframe">Iframe</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      default:
        return <p className="text-sm text-muted-foreground">Editor no disponible</p>;
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="border rounded-lg bg-background"
    >
      <div
        className="flex items-center gap-2 p-3 bg-muted/50 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
        <div className="flex items-center gap-2">
          {blockIcons[block.type]}
          <span className="font-medium text-sm">{blockConfig[block.type].label}</span>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={(e) => { e.stopPropagation(); onMoveUp(); }}
            disabled={isFirst}
          >
            <MoveUp className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={(e) => { e.stopPropagation(); onMoveDown(); }}
            disabled={isLast}
          >
            <MoveDown className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-destructive hover:text-destructive"
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
        <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
      </div>
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 border-t">
              {renderEditor()}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// Main Block Editor Component
export default function BlockEditor({ blocks, onChange }: {
  blocks: ContentBlock[];
  onChange: (blocks: ContentBlock[]) => void;
}) {
  const addBlock = useCallback((type: BlockType) => {
    const newBlock = createBlock(type, {});
    newBlock.order = blocks.length;
    onChange([...blocks, newBlock]);
  }, [blocks, onChange]);

  const updateBlock = useCallback((index: number, block: ContentBlock) => {
    const newBlocks = [...blocks];
    newBlocks[index] = block;
    onChange(newBlocks);
  }, [blocks, onChange]);

  const deleteBlock = useCallback((index: number) => {
    const newBlocks = blocks.filter((_, i) => i !== index);
    newBlocks.forEach((block, i) => {
      block.order = i;
    });
    onChange(newBlocks);
  }, [blocks, onChange]);

  const moveBlock = useCallback((index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= blocks.length) return;
    
    const newBlocks = [...blocks];
    [newBlocks[index], newBlocks[newIndex]] = [newBlocks[newIndex], newBlocks[index]];
    newBlocks.forEach((block, i) => {
      block.order = i;
    });
    onChange(newBlocks);
  }, [blocks, onChange]);

  const categories = {
    text: ['paragraph', 'heading1', 'heading2', 'heading3', 'quote', 'list', 'code', 'callout'],
    media: ['image', 'gallery', 'carousel', 'video', 'audio', 'embed'],
    interactive: ['poll', 'link'],
    layout: ['table', 'timeline', 'divider'],
  };

  return (
    <div className="space-y-4">
      {/* Add Block Button */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Agregar Bloque
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-64" align="start">
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              <Type className="w-4 h-4 mr-2" />
              Texto
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              {categories.text.map((type) => (
                <DropdownMenuItem key={type} onClick={() => addBlock(type as BlockType)}>
                  <div className="flex items-center gap-2">
                    {blockIcons[type as BlockType]}
                    <div>
                      <div className="font-medium">{blockConfig[type as BlockType].label}</div>
                      <div className="text-xs text-muted-foreground">{blockConfig[type as BlockType].description}</div>
                    </div>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuSubContent>
          </DropdownMenuSub>

          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              <ImageIcon className="w-4 h-4 mr-2" />
              Multimedia
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              {categories.media.map((type) => (
                <DropdownMenuItem key={type} onClick={() => addBlock(type as BlockType)}>
                  <div className="flex items-center gap-2">
                    {blockIcons[type as BlockType]}
                    <div>
                      <div className="font-medium">{blockConfig[type as BlockType].label}</div>
                      <div className="text-xs text-muted-foreground">{blockConfig[type as BlockType].description}</div>
                    </div>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuSubContent>
          </DropdownMenuSub>

          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              <BarChart3 className="w-4 h-4 mr-2" />
              Interactivo
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              {categories.interactive.map((type) => (
                <DropdownMenuItem key={type} onClick={() => addBlock(type as BlockType)}>
                  <div className="flex items-center gap-2">
                    {blockIcons[type as BlockType]}
                    <div>
                      <div className="font-medium">{blockConfig[type as BlockType].label}</div>
                      <div className="text-xs text-muted-foreground">{blockConfig[type as BlockType].description}</div>
                    </div>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuSubContent>
          </DropdownMenuSub>

          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              <Table className="w-4 h-4 mr-2" />
              Estructura
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              {categories.layout.map((type) => (
                <DropdownMenuItem key={type} onClick={() => addBlock(type as BlockType)}>
                  <div className="flex items-center gap-2">
                    {blockIcons[type as BlockType]}
                    <div>
                      <div className="font-medium">{blockConfig[type as BlockType].label}</div>
                      <div className="text-xs text-muted-foreground">{blockConfig[type as BlockType].description}</div>
                    </div>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuSubContent>
          </DropdownMenuSub>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Blocks List */}
      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {blocks.map((block, index) => (
            <BlockEditorItem
              key={block.id}
              block={block}
              onUpdate={(b) => updateBlock(index, b)}
              onDelete={() => deleteBlock(index)}
              onMoveUp={() => moveBlock(index, 'up')}
              onMoveDown={() => moveBlock(index, 'down')}
              isFirst={index === 0}
              isLast={index === blocks.length - 1}
            />
          ))}
        </AnimatePresence>
      </div>

      {blocks.length === 0 && (
        <div className="text-center py-8 border-2 border-dashed rounded-lg text-muted-foreground">
          <p className="text-sm">No hay bloques de contenido</p>
          <p className="text-xs mt-1">Haz clic en "Agregar Bloque" para comenzar</p>
        </div>
      )}
    </div>
  );
}
