'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TreeVisualization, 
  AlgorithmSteps,
  ResultsTable, 
  HeuristicsTable, 
  FormulaExplanation,
  OpenClosedLists,
  algorithmSteps,
  calculateAllNodes
} from '@/components/astar-exercise';
import { Play, RotateCcw, ChevronLeft, ChevronRight, CheckCircle } from 'lucide-react';

export default function Home() {
  const results = calculateAllNodes();
  const [currentStep, setCurrentStep] = useState(-1);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);

  // Get completed nodes from algorithm steps
  const completedNodes = new Set<string>();
  if (currentStep >= 0 && currentStep < algorithmSteps.length) {
    algorithmSteps[currentStep].closedList.forEach(id => completedNodes.add(id));
  }

  // Get active node (currently being expanded)
  const activeNode = currentStep >= 0 && currentStep < algorithmSteps.length 
    ? algorithmSteps[currentStep].expandedNode 
    : undefined;

  const totalSteps = algorithmSteps.length;

  const stopAutoPlay = useCallback(() => {
    if (autoPlayRef.current) {
      clearTimeout(autoPlayRef.current);
      autoPlayRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (isAutoPlaying && currentStep < totalSteps - 1) {
      autoPlayRef.current = setTimeout(() => {
        setCurrentStep(prev => {
          const next = prev + 1;
          if (next >= totalSteps - 1) {
            setIsAutoPlaying(false);
          }
          return next;
        });
      }, 2000);
      return () => stopAutoPlay();
    }
  }, [isAutoPlaying, currentStep, totalSteps, stopAutoPlay]);

  const handlePlay = () => {
    if (currentStep >= totalSteps - 1) {
      setCurrentStep(0);
    }
    setIsAutoPlaying(true);
  };

  const handlePause = () => {
    stopAutoPlay();
    setIsAutoPlaying(false);
  };

  const handleReset = () => {
    stopAutoPlay();
    setIsAutoPlaying(false);
    setCurrentStep(-1);
  };

  const handleNext = () => {
    stopAutoPlay();
    setIsAutoPlaying(false);
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    stopAutoPlay();
    setIsAutoPlaying(false);
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleStepClick = (step: number) => {
    stopAutoPlay();
    setIsAutoPlaying(false);
    setCurrentStep(step);
  };

  const isComplete = currentStep >= totalSteps - 1 && currentStep >= 0;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                Algoritmo A* - Ejercicio Interactivo
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Cálculo de f(n) = g(n) + h(n) paso a paso con listas abierta y cerrada
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={isComplete ? "default" : "outline"}>
                {currentStep + 1} / {totalSteps} pasos
              </Badge>
              {isComplete && (
                <Badge className="bg-emerald-500">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Completado
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column - Tree and Controls */}
          <div className="lg:col-span-7 space-y-6">
            {/* Formula Card */}
            <FormulaExplanation />

            {/* Tree Visualization */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Árbol de Búsqueda</CardTitle>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <div className="w-3 h-3 rounded-full bg-amber-500" />
                      Activo
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <div className="w-3 h-3 rounded-full bg-emerald-500" />
                      Completado
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <div className="w-3 h-3 rounded-full bg-green-500" />
                      Objetivo
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <TreeVisualization 
                  activeNode={activeNode} 
                  completedNodes={completedNodes} 
                />
              </CardContent>
            </Card>

            {/* Controls */}
            <Card className="border-border">
              <CardContent className="py-4">
                <div className="flex items-center justify-center gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleReset}
                    title="Reiniciar"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handlePrev}
                    disabled={currentStep <= 0}
                    title="Anterior"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  {isAutoPlaying ? (
                    <Button onClick={handlePause} className="px-8">
                      Pausar
                    </Button>
                  ) : (
                    <Button onClick={handlePlay} className="px-8">
                      <Play className="h-4 w-4 mr-2" />
                      {currentStep >= totalSteps - 1 ? 'Reiniciar' : 'Reproducir'}
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleNext}
                    disabled={currentStep >= totalSteps - 1}
                    title="Siguiente"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Results Table */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Tabla de Resultados</CardTitle>
              </CardHeader>
              <CardContent>
                <ResultsTable results={results} currentStep={currentStep} />
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Lists and Steps */}
          <div className="lg:col-span-5 space-y-6">
            {/* Open and Closed Lists */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Listas del Algoritmo</CardTitle>
              </CardHeader>
              <CardContent>
                <OpenClosedLists 
                  algorithmSteps={algorithmSteps}
                  currentStep={currentStep}
                />
              </CardContent>
            </Card>

            {/* Heuristics Table */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Valores Heurísticos h(n)</CardTitle>
              </CardHeader>
              <CardContent>
                <HeuristicsTable />
              </CardContent>
            </Card>

            {/* Algorithm Steps */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Pasos de Solución</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Haz clic en cualquier paso para ir directamente a él
                </p>
              </CardHeader>
              <CardContent className="max-h-[400px] overflow-y-auto">
                <AlgorithmSteps
                  algorithmSteps={algorithmSteps}
                  currentStep={currentStep}
                  onStepClick={handleStepClick}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30 mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="text-center text-sm text-muted-foreground">
            Ejercicio de Algoritmo A* - Búsqueda Informada con Listas Abierta y Cerrada
          </div>
        </div>
      </footer>
    </div>
  );
}
