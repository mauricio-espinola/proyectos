'use client';

import { heuristics } from './data';

export function HeuristicsTable() {
  const nodes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'Goal'];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            <th className="border border-border px-4 py-2 bg-muted/50 text-left font-medium">
              Estado
            </th>
            {nodes.map((node) => (
              <td
                key={node}
                className="border border-border px-4 py-2 text-center font-medium"
              >
                {node}
              </td>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-border px-4 py-2 bg-muted/50 font-medium">
              h(n)
            </td>
            {nodes.map((node) => (
              <td
                key={node}
                className="border border-border px-4 py-2 text-center"
              >
                {heuristics[node]}
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
