'use client';

import { cn } from '@/lib/utils';
import { NodeResult } from './types';

interface SolutionStepsProps {
  results: NodeResult[];
  currentStep: number;
  onStepClick: (step: number) => void;
}

export function SolutionSteps({ results, currentStep, onStepClick }: SolutionStepsProps) {
  return (
    <div className="space-y-3">
      {results.map((result, index) => (
        <SolutionStep
          key={result.id}
          result={result}
          stepNumber={index + 1}
          isActive={currentStep === index}
          isCompleted={currentStep > index}
          onClick={() => onStepClick(index)}
        />
      ))}
    </div>
  );
}

interface SolutionStepProps {
  result: NodeResult;
  stepNumber: number;
  isActive: boolean;
  isCompleted: boolean;
  onClick: () => void;
}

function SolutionStep({ result, stepNumber, isActive, isCompleted, onClick }: SolutionStepProps) {
  const pathStr = result.path.join(' → ');
  const pathCostStr = result.pathCosts.length > 0 
    ? result.pathCosts.join(' + ') + ' = ' + result.g 
    : '0';

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full text-left p-4 rounded-lg border transition-all duration-300',
        isActive && 'border-amber-500 bg-amber-50 dark:bg-amber-900/20 shadow-md',
        isCompleted && !isActive && 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20',
        !isActive && !isCompleted && 'border-border hover:border-muted-foreground/50 bg-background'
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            'flex items-center justify-center w-8 h-8 rounded-full text-sm font-semibold shrink-0',
            isActive && 'bg-amber-500 text-white',
            isCompleted && !isActive && 'bg-emerald-500 text-white',
            !isActive && !isCompleted && 'bg-muted text-muted-foreground'
          )}
        >
          {stepNumber}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-medium text-foreground mb-1">
            Nodo {result.label}
          </div>
          <div className="text-sm text-muted-foreground space-y-1">
            <div>
              <span className="font-medium">Camino:</span> {pathStr}
            </div>
            <div>
              <span className="font-medium">g({result.label})</span> = {pathCostStr}
            </div>
            <div>
              <span className="font-medium">h({result.label})</span> = {result.h}
            </div>
            <div className={cn(
              'font-semibold pt-1',
              isActive && 'text-amber-600 dark:text-amber-400',
              isCompleted && !isActive && 'text-emerald-600 dark:text-emerald-400'
            )}>
              f({result.label}) = g({result.label}) + h({result.label}) = {result.g} + {result.h} = <span className="text-lg">{result.f}</span>
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}
