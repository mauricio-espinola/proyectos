'use client';

import { cn } from '@/lib/utils';

interface TreeVisualizationProps {
  activeNode?: string;
  completedNodes?: Set<string>;
}

export function TreeVisualization({ activeNode, completedNodes = new Set() }: TreeVisualizationProps) {
  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[700px] flex justify-center py-4">
        <svg width="650" height="380" className="text-border">
          {/* Edges from A to Level 1 */}
          <line x1="325" y1="40" x2="125" y2="100" stroke="currentColor" strokeWidth="1.5" />
          <line x1="325" y1="40" x2="325" y2="100" stroke="currentColor" strokeWidth="1.5" />
          <line x1="325" y1="40" x2="525" y2="100" stroke="currentColor" strokeWidth="1.5" />
          
          {/* Edge labels Level 0 -> Level 1 */}
          <text x="210" y="65" className="text-xs fill-muted-foreground">4</text>
          <text x="335" y="65" className="text-xs fill-muted-foreground">2</text>
          <text x="440" y="65" className="text-xs fill-muted-foreground">8</text>

          {/* Edges from B1 to Level 2 */}
          <line x1="125" y1="140" x2="75" y2="200" stroke="currentColor" strokeWidth="1.5" />
          <line x1="125" y1="140" x2="175" y2="200" stroke="currentColor" strokeWidth="1.5" />
          
          {/* Edge labels B1 -> E, F */}
          <text x="85" y="165" className="text-xs fill-muted-foreground">2</text>
          <text x="160" y="165" className="text-xs fill-muted-foreground">4</text>

          {/* Edges from C to Level 2 */}
          <line x1="325" y1="140" x2="275" y2="200" stroke="currentColor" strokeWidth="1.5" />
          <line x1="325" y1="140" x2="375" y2="200" stroke="currentColor" strokeWidth="1.5" />
          
          {/* Edge labels C -> D2, B2 */}
          <text x="285" y="165" className="text-xs fill-muted-foreground">7</text>
          <text x="360" y="165" className="text-xs fill-muted-foreground">5</text>

          {/* Edges from D1 to Level 2 */}
          <line x1="525" y1="140" x2="475" y2="200" stroke="currentColor" strokeWidth="1.5" />
          <line x1="525" y1="140" x2="575" y2="200" stroke="currentColor" strokeWidth="1.5" />
          
          {/* Edge labels D1 -> G2, Goal2 */}
          <text x="485" y="165" className="text-xs fill-muted-foreground">3</text>
          <text x="560" y="165" className="text-xs fill-muted-foreground">4</text>

          {/* Edges from D2 to Level 3 */}
          <line x1="275" y1="240" x2="225" y2="300" stroke="currentColor" strokeWidth="1.5" />
          <line x1="275" y1="240" x2="325" y2="300" stroke="currentColor" strokeWidth="1.5" />
          
          {/* Edge labels D2 -> G1, Goal1 */}
          <text x="235" y="265" className="text-xs fill-muted-foreground">3</text>
          <text x="310" y="265" className="text-xs fill-muted-foreground">2</text>

          {/* Level 0 - Root A */}
          <g>
            <circle
              cx="325"
              cy="24"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'A' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('A') && activeNode !== 'A' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('A') && activeNode !== 'A' && 'stroke-border'
              )}
            />
            <text
              x="325"
              y="28"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'A' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('A') && activeNode !== 'A' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('A') && activeNode !== 'A' && 'fill-foreground'
              )}
            >
              A
            </text>
          </g>

          {/* Level 1 - B₁, C, D₁ */}
          {/* B₁ */}
          <g>
            <circle
              cx="125"
              cy="124"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'B1' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('B1') && activeNode !== 'B1' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('B1') && activeNode !== 'B1' && 'stroke-border'
              )}
            />
            <text
              x="125"
              y="128"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'B1' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('B1') && activeNode !== 'B1' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('B1') && activeNode !== 'B1' && 'fill-foreground'
              )}
            >
              B₁
            </text>
          </g>

          {/* C */}
          <g>
            <circle
              cx="325"
              cy="124"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'C' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('C') && activeNode !== 'C' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('C') && activeNode !== 'C' && 'stroke-border'
              )}
            />
            <text
              x="325"
              y="128"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'C' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('C') && activeNode !== 'C' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('C') && activeNode !== 'C' && 'fill-foreground'
              )}
            >
              C
            </text>
          </g>

          {/* D₁ */}
          <g>
            <circle
              cx="525"
              cy="124"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'D1' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('D1') && activeNode !== 'D1' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('D1') && activeNode !== 'D1' && 'stroke-border'
              )}
            />
            <text
              x="525"
              y="128"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'D1' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('D1') && activeNode !== 'D1' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('D1') && activeNode !== 'D1' && 'fill-foreground'
              )}
            >
              D₁
            </text>
          </g>

          {/* Level 2 - E, F, D₂, B₂, G₂, Goal₂ */}
          {/* E */}
          <g>
            <circle
              cx="75"
              cy="224"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'E' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('E') && activeNode !== 'E' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('E') && activeNode !== 'E' && 'stroke-border'
              )}
            />
            <text
              x="75"
              y="228"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'E' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('E') && activeNode !== 'E' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('E') && activeNode !== 'E' && 'fill-foreground'
              )}
            >
              E
            </text>
          </g>

          {/* F */}
          <g>
            <circle
              cx="175"
              cy="224"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'F' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('F') && activeNode !== 'F' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('F') && activeNode !== 'F' && 'stroke-border'
              )}
            />
            <text
              x="175"
              y="228"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'F' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('F') && activeNode !== 'F' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('F') && activeNode !== 'F' && 'fill-foreground'
              )}
            >
              F
            </text>
          </g>

          {/* D₂ */}
          <g>
            <circle
              cx="275"
              cy="224"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'D2' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('D2') && activeNode !== 'D2' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('D2') && activeNode !== 'D2' && 'stroke-border'
              )}
            />
            <text
              x="275"
              y="228"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'D2' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('D2') && activeNode !== 'D2' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('D2') && activeNode !== 'D2' && 'fill-foreground'
              )}
            >
              D₂
            </text>
          </g>

          {/* B₂ */}
          <g>
            <circle
              cx="375"
              cy="224"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'B2' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('B2') && activeNode !== 'B2' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('B2') && activeNode !== 'B2' && 'stroke-border'
              )}
            />
            <text
              x="375"
              y="228"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'B2' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('B2') && activeNode !== 'B2' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('B2') && activeNode !== 'B2' && 'fill-foreground'
              )}
            >
              B₂
            </text>
          </g>

          {/* G₂ */}
          <g>
            <circle
              cx="475"
              cy="224"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'G2' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('G2') && activeNode !== 'G2' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('G2') && activeNode !== 'G2' && 'stroke-border'
              )}
            />
            <text
              x="475"
              y="228"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'G2' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('G2') && activeNode !== 'G2' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('G2') && activeNode !== 'G2' && 'fill-foreground'
              )}
            >
              G₂
            </text>
          </g>

          {/* Goal₂ */}
          <g>
            <circle
              cx="575"
              cy="224"
              r="20"
              className="fill-green-100 dark:fill-green-900/30 stroke-green-500 stroke-2"
            />
            <text
              x="575"
              y="228"
              textAnchor="middle"
              className="text-xs font-medium fill-green-700 dark:fill-green-400"
            >
              Goal₂
            </text>
          </g>

          {/* Level 3 - G₁, Goal₁ */}
          {/* G₁ */}
          <g>
            <circle
              cx="225"
              cy="324"
              r="20"
              className={cn(
                'fill-background stroke-2 transition-all duration-300',
                activeNode === 'G1' && 'fill-amber-100 dark:fill-amber-900/30 stroke-amber-500',
                completedNodes.has('G1') && activeNode !== 'G1' && 'fill-emerald-100 dark:fill-emerald-900/30 stroke-emerald-500',
                !completedNodes.has('G1') && activeNode !== 'G1' && 'stroke-border'
              )}
            />
            <text
              x="225"
              y="328"
              textAnchor="middle"
              className={cn(
                'text-sm font-medium',
                activeNode === 'G1' && 'fill-amber-700 dark:fill-amber-400',
                completedNodes.has('G1') && activeNode !== 'G1' && 'fill-emerald-700 dark:fill-emerald-400',
                !completedNodes.has('G1') && activeNode !== 'G1' && 'fill-foreground'
              )}
            >
              G₁
            </text>
          </g>

          {/* Goal₁ */}
          <g>
            <circle
              cx="325"
              cy="324"
              r="20"
              className="fill-green-100 dark:fill-green-900/30 stroke-green-500 stroke-2"
            />
            <text
              x="325"
              y="328"
              textAnchor="middle"
              className="text-xs font-medium fill-green-700 dark:fill-green-400"
            >
              Goal₁
            </text>
          </g>
        </svg>
      </div>
    </div>
  );
}
