// Type definitions for A* Algorithm Exercise

export interface TreeNode {
  id: string;
  label: string;
  heuristic: number;
  children: TreeEdge[];
  isGoal?: boolean;
}

export interface TreeEdge {
  target: string;
  cost: number;
}

export interface NodeResult {
  id: string;
  label: string;
  g: number; // Costo real acumulado
  h: number; // Valor heurístico
  f: number; // g + h
  path: string[]; // Camino desde A
  pathCosts: number[]; // Costos de cada arista en el camino
}

export interface SolutionStep {
  step: number;
  nodeId: string;
  nodeLabel: string;
  description: string;
  calculation: string;
  result: NodeResult;
}

export interface TreeData {
  nodes: Map<string, TreeNode>;
  rootId: string;
}

// A* Algorithm state types
export interface OpenListNode {
  id: string;
  label: string;
  f: number;
  g: number;
  h: number;
}

export interface AlgorithmStep {
  step: number;
  expandedNode: string;
  expandedLabel: string;
  expandedG: number; // g value of expanded node
  expandedF: number; // f value of expanded node
  openList: OpenListNode[];
  closedList: string[];
  description: string;
  isGoal: boolean;
}
