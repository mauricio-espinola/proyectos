'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export function FormulaExplanation() {
  return (
    <Card className="border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Fórmula de Evaluación</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 rounded-lg p-4 text-center">
          <span className="text-2xl font-mono font-semibold">f(n) = g(n) + h(n)</span>
        </div>
        <div className="space-y-2 text-sm">
          <div className="flex gap-2">
            <span className="font-semibold text-primary min-w-[60px]">g(n)</span>
            <span className="text-muted-foreground">
              Costo real acumulado desde el nodo raíz A hasta el nodo n (suma de costos de aristas en el camino)
            </span>
          </div>
          <div className="flex gap-2">
            <span className="font-semibold text-primary min-w-[60px]">h(n)</span>
            <span className="text-muted-foreground">
              Valor heurístico del estado n (costo estimado hasta el objetivo, dado en la tabla)
            </span>
          </div>
          <div className="flex gap-2">
            <span className="font-semibold text-primary min-w-[60px]">f(n)</span>
            <span className="text-muted-foreground">
              Costo total estimado del camino que pasa por n hasta el objetivo
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
