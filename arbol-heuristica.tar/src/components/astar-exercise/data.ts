// Tree data for the A* Algorithm Exercise

import { TreeNode, TreeData, NodeResult, AlgorithmStep, OpenListNode } from './types';

// Heuristic values from the problem
export const heuristics: Record<string, number> = {
  A: 9,
  B: 4,
  C: 5,
  D: 1,
  E: 3,
  F: 2,
  G: 3,
  Goal: 0,
};

// Tree structure with nodes and edges
export const treeNodes: Record<string, TreeNode> = {
  A: {
    id: 'A',
    label: 'A',
    heuristic: heuristics.A,
    children: [
      { target: 'B1', cost: 4 },
      { target: 'C', cost: 2 },
      { target: 'D1', cost: 8 },
    ],
  },
  B1: {
    id: 'B1',
    label: 'B₁',
    heuristic: heuristics.B,
    children: [
      { target: 'E', cost: 2 },
      { target: 'F', cost: 4 },
    ],
  },
  C: {
    id: 'C',
    label: 'C',
    heuristic: heuristics.C,
    children: [
      { target: 'D2', cost: 7 },
      { target: 'B2', cost: 5 },
    ],
  },
  D1: {
    id: 'D1',
    label: 'D₁',
    heuristic: heuristics.D,
    children: [
      { target: 'G2', cost: 3 },
      { target: 'Goal2', cost: 4 },
    ],
  },
  E: {
    id: 'E',
    label: 'E',
    heuristic: heuristics.E,
    children: [],
  },
  F: {
    id: 'F',
    label: 'F',
    heuristic: heuristics.F,
    children: [],
  },
  D2: {
    id: 'D2',
    label: 'D₂',
    heuristic: heuristics.D,
    children: [
      { target: 'G1', cost: 3 },
      { target: 'Goal1', cost: 2 },
    ],
  },
  B2: {
    id: 'B2',
    label: 'B₂',
    heuristic: heuristics.B,
    children: [],
  },
  G2: {
    id: 'G2',
    label: 'G₂',
    heuristic: heuristics.G,
    children: [],
  },
  Goal2: {
    id: 'Goal2',
    label: 'Goal₂',
    heuristic: heuristics.Goal,
    children: [],
    isGoal: true,
  },
  G1: {
    id: 'G1',
    label: 'G₁',
    heuristic: heuristics.G,
    children: [],
  },
  Goal1: {
    id: 'Goal1',
    label: 'Goal₁',
    heuristic: heuristics.Goal,
    children: [],
    isGoal: true,
  },
};

// Create tree data structure
export const treeData: TreeData = {
  nodes: new Map(Object.entries(treeNodes)),
  rootId: 'A',
};

// Function to calculate f(n) for all nodes
export function calculateAllNodes(): NodeResult[] {
  const results: NodeResult[] = [];
  
  // Define all paths from A to each node
  const paths: { id: string; label: string; path: string[]; pathCosts: number[] }[] = [
    { id: 'A', label: 'A', path: ['A'], pathCosts: [] },
    { id: 'B1', label: 'B₁', path: ['A', 'B1'], pathCosts: [4] },
    { id: 'C', label: 'C', path: ['A', 'C'], pathCosts: [2] },
    { id: 'D1', label: 'D₁', path: ['A', 'D1'], pathCosts: [8] },
    { id: 'E', label: 'E', path: ['A', 'B1', 'E'], pathCosts: [4, 2] },
    { id: 'F', label: 'F', path: ['A', 'B1', 'F'], pathCosts: [4, 4] },
    { id: 'D2', label: 'D₂', path: ['A', 'C', 'D2'], pathCosts: [2, 7] },
    { id: 'B2', label: 'B₂', path: ['A', 'C', 'B2'], pathCosts: [2, 5] },
    { id: 'G2', label: 'G₂', path: ['A', 'D1', 'G2'], pathCosts: [8, 3] },
    { id: 'Goal2', label: 'Goal₂', path: ['A', 'D1', 'Goal2'], pathCosts: [8, 4] },
    { id: 'G1', label: 'G₁', path: ['A', 'C', 'D2', 'G1'], pathCosts: [2, 7, 3] },
    { id: 'Goal1', label: 'Goal₁', path: ['A', 'C', 'D2', 'Goal1'], pathCosts: [2, 7, 2] },
  ];

  for (const pathInfo of paths) {
    const g = pathInfo.pathCosts.reduce((sum, cost) => sum + cost, 0);
    const node = treeNodes[pathInfo.id];
    const h = node.heuristic;
    const f = g + h;

    results.push({
      id: pathInfo.id,
      label: pathInfo.label,
      g,
      h,
      f,
      path: pathInfo.path,
      pathCosts: pathInfo.pathCosts,
    });
  }

  return results;
}

// Get heuristic value for a base node (B, D, G, Goal)
export function getBaseNodeName(label: string): string {
  // Remove subscripts: B₁ -> B, D₁ -> D, etc.
  const baseName = label.replace(/[₁₂₃₄₅₆₇₈₉₀]/g, '');
  return baseName;
}

// Simulate A* algorithm step by step
export function simulateAStar(): AlgorithmStep[] {
  const steps: AlgorithmStep[] = [];
  const openList: OpenListNode[] = [];
  const closedList: string[] = [];
  const gValues: Record<string, number> = {};
  
  // Initialize with root node A
  gValues['A'] = 0;
  openList.push({
    id: 'A',
    label: 'A',
    f: 0 + heuristics.A,
    g: 0,
    h: heuristics.A
  });

  let step = 0;

  while (openList.length > 0) {
    // Sort open list by f value (ascending)
    // When f values are equal, prioritize goal nodes
    openList.sort((a, b) => {
      if (a.f !== b.f) {
        return a.f - b.f;
      }
      // If f values are equal, prioritize goal nodes
      const aIsGoal = treeNodes[a.id]?.isGoal || false;
      const bIsGoal = treeNodes[b.id]?.isGoal || false;
      if (aIsGoal && !bIsGoal) return -1;
      if (!aIsGoal && bIsGoal) return 1;
      return 0;
    });
    
    // Get node with lowest f value (or goal if tied)
    const current = openList.shift()!;
    const currentNode = treeNodes[current.id];
    
    // Add to closed list
    closedList.push(current.id);
    
    step++;
    const isGoal = currentNode.isGoal || false;
    
    steps.push({
      step,
      expandedNode: current.id,
      expandedLabel: current.label,
      expandedG: current.g,
      expandedF: current.f,
      openList: [...openList.map(n => ({ ...n }))],
      closedList: [...closedList],
      description: isGoal 
        ? `🎯 ¡OBJETIVO ENCONTRADO! El algoritmo termina al seleccionar ${current.label} con f=${current.f}`
        : `Expandiendo nodo ${current.label} con f=${current.f}`,
      isGoal
    });

    // IMPORTANT: In A*, the algorithm terminates when we SELECT a goal node from OPEN
    if (isGoal) {
      break;
    }

    // Add children to open list
    for (const child of currentNode.children) {
      const childNode = treeNodes[child.target];
      const childG = current.g + child.cost;
      
      // Check if already in closed list
      if (closedList.includes(child.target)) {
        continue;
      }
      
      // Check if already in open list with better path
      const existingIndex = openList.findIndex(n => n.id === child.target);
      if (existingIndex >= 0) {
        if (childG < openList[existingIndex].g) {
          // Found better path, update
          openList[existingIndex] = {
            id: child.target,
            label: childNode.label,
            f: childG + childNode.heuristic,
            g: childG,
            h: childNode.heuristic
          };
        }
      } else {
        // Add to open list
        gValues[child.target] = childG;
        openList.push({
          id: child.target,
          label: childNode.label,
          f: childG + childNode.heuristic,
          g: childG,
          h: childNode.heuristic
        });
      }
    }
  }

  return steps;
}

// Get the algorithm steps
export const algorithmSteps = simulateAStar();
