'use client';

import { NodeResult, AlgorithmStep } from './types';
import { cn } from '@/lib/utils';
import { algorithmSteps } from './data';

interface ResultsTableProps {
  results: NodeResult[];
  currentStep: number;
}

export function ResultsTable({ results, currentStep }: ResultsTableProps) {
  // Get the closed list (expanded nodes) up to current step
  const expandedNodes = new Set<string>();
  const activeNode = currentStep >= 0 && currentStep < algorithmSteps.length 
    ? algorithmSteps[currentStep].expandedNode 
    : null;

  // Add all nodes from closed list up to current step
  for (let i = 0; i <= currentStep && i < algorithmSteps.length; i++) {
    algorithmSteps[i].closedList.forEach(id => expandedNodes.add(id));
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr>
            <th className="border border-border px-3 py-2 bg-muted/50 text-left font-medium">
              Nodo
            </th>
            <th className="border border-border px-3 py-2 bg-muted/50 text-center font-medium">
              Camino
            </th>
            <th className="border border-border px-3 py-2 bg-muted/50 text-center font-medium">
              g(n)
            </th>
            <th className="border border-border px-3 py-2 bg-muted/50 text-center font-medium">
              h(n)
            </th>
            <th className="border border-border px-3 py-2 bg-muted/50 text-center font-medium">
              f(n)
            </th>
          </tr>
        </thead>
        <tbody>
          {results.map((result) => {
            const isExpanded = expandedNodes.has(result.id);
            const isActive = activeNode === result.id;
            const isGoal = result.id.includes('Goal');
            
            return (
              <tr
                key={result.id}
                className={cn(
                  'transition-colors duration-300',
                  isActive && 'bg-amber-50 dark:bg-amber-900/20',
                  isExpanded && !isActive && 'bg-emerald-50 dark:bg-emerald-900/10'
                )}
              >
                <td className="border border-border px-3 py-2 font-medium">
                  <span className={cn(
                    isGoal && 'text-green-600 dark:text-green-400'
                  )}>
                    {result.label}
                  </span>
                </td>
                <td className="border border-border px-3 py-2 text-center text-xs text-muted-foreground">
                  {result.path.join(' → ')}
                </td>
                <td className="border border-border px-3 py-2 text-center">
                  {result.g}
                </td>
                <td className="border border-border px-3 py-2 text-center">
                  {result.h}
                </td>
                <td
                  className={cn(
                    'border border-border px-3 py-2 text-center font-semibold',
                    isActive && 'text-amber-600 dark:text-amber-400',
                    isExpanded && !isActive && 'text-emerald-600 dark:text-emerald-400'
                  )}
                >
                  {result.f}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
