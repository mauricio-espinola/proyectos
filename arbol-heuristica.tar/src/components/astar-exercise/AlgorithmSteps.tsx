'use client';

import { cn } from '@/lib/utils';
import { AlgorithmStep } from './types';
import { calculateAllNodes, treeNodes } from './data';

interface AlgorithmStepsProps {
  algorithmSteps: AlgorithmStep[];
  currentStep: number;
  onStepClick: (step: number) => void;
}

// Get all node results for calculating g, h, f values
const allNodes = calculateAllNodes();
const nodeMap = new Map(allNodes.map(n => [n.id, n]));

export function AlgorithmSteps({ algorithmSteps, currentStep, onStepClick }: AlgorithmStepsProps) {
  return (
    <div className="space-y-3">
      {algorithmSteps.map((step, index) => {
        const nodeData = nodeMap.get(step.expandedNode);
        const isActive = currentStep === index;
        const isCompleted = currentStep > index;
        
        return (
          <AlgorithmStepItem
            key={step.step}
            step={step}
            nodeData={nodeData}
            isActive={isActive}
            isCompleted={isCompleted}
            onClick={() => onStepClick(index)}
          />
        );
      })}
    </div>
  );
}

interface AlgorithmStepItemProps {
  step: AlgorithmStep;
  nodeData: { g: number; h: number; f: number; path: string[]; pathCosts: number[]; label: string } | undefined;
  isActive: boolean;
  isCompleted: boolean;
  onClick: () => void;
}

function AlgorithmStepItem({ step, nodeData, isActive, isCompleted, onClick }: AlgorithmStepItemProps) {
  if (!nodeData) return null;

  const pathStr = nodeData.path.join(' → ');
  const pathCostStr = nodeData.pathCosts.length > 0 
    ? nodeData.pathCosts.join(' + ') + ' = ' + nodeData.g 
    : '0';

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full text-left p-3 rounded-lg border transition-all duration-300',
        step.isGoal && 'border-green-500 bg-green-50 dark:bg-green-900/20',
        isActive && !step.isGoal && 'border-amber-500 bg-amber-50 dark:bg-amber-900/20 shadow-md',
        isCompleted && !isActive && !step.isGoal && 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20',
        !isActive && !isCompleted && !step.isGoal && 'border-border hover:border-muted-foreground/50 bg-background'
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            'flex items-center justify-center w-7 h-7 rounded-full text-xs font-semibold shrink-0',
            step.isGoal && 'bg-green-500 text-white',
            isActive && !step.isGoal && 'bg-amber-500 text-white',
            isCompleted && !isActive && !step.isGoal && 'bg-emerald-500 text-white',
            !isActive && !isCompleted && !step.isGoal && 'bg-muted text-muted-foreground'
          )}
        >
          {step.step}
        </div>
        <div className="flex-1 min-w-0">
          <div className={cn(
            'font-medium mb-1',
            step.isGoal && 'text-green-700 dark:text-green-400'
          )}>
            {step.isGoal ? '🎯 ' : ''}Expandir nodo {nodeData.label}
          </div>
          <div className="text-xs text-muted-foreground space-y-0.5">
            <div>
              <span className="font-medium">Camino:</span> {pathStr}
            </div>
            <div>
              <span className="font-medium">g({nodeData.label})</span> = {pathCostStr}
            </div>
            <div>
              <span className="font-medium">h({nodeData.label})</span> = {nodeData.h}
            </div>
            <div className={cn(
              'font-semibold pt-0.5',
              step.isGoal && 'text-green-600 dark:text-green-400',
              isActive && !step.isGoal && 'text-amber-600 dark:text-amber-400',
              isCompleted && !isActive && !step.isGoal && 'text-emerald-600 dark:text-emerald-400'
            )}>
              f({nodeData.label}) = {nodeData.g} + {nodeData.h} = <span className="text-sm">{nodeData.f}</span>
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}
