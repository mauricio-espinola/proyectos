'use client';

import { cn } from '@/lib/utils';
import { AlgorithmStep, OpenListNode } from './types';
import { treeNodes } from './data';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertTriangle } from 'lucide-react';

interface OpenClosedListsProps {
  algorithmSteps: AlgorithmStep[];
  currentStep: number;
}

export function OpenClosedLists({ algorithmSteps, currentStep }: OpenClosedListsProps) {
  // If we haven't started, show initial state
  const stepData = currentStep >= 0 && currentStep < algorithmSteps.length 
    ? algorithmSteps[currentStep] 
    : null;

  return (
    <div className="space-y-4">
      {/* Explanation */}
      <div className="bg-muted/50 rounded-lg p-4 text-sm space-y-3">
        <div className="font-semibold text-foreground mb-2">¿Qué son estas listas?</div>
        <div className="space-y-2 text-muted-foreground">
          <p>
            <span className="font-semibold text-amber-600 dark:text-amber-400">Lista Abierta (OPEN)</span>: 
            Nodos descubiertos pero no expandidos. Se ordenan por <span className="font-mono">f(n)</span> ascendente.
          </p>
          <p>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">Lista Cerrada (CLOSED)</span>: 
            Nodos ya expandidos. No se vuelven a visitar.
          </p>
          <p className="text-xs border-t border-border pt-2 mt-2">
            <strong>Regla A*:</strong> El algoritmo termina cuando se <strong>selecciona</strong> un nodo objetivo de OPEN.
          </p>
        </div>
      </div>

      {/* Current Step Info */}
      {stepData && (
        <div className="space-y-3">
          {/* Current expansion */}
          <div className={cn(
            "rounded-lg p-3 border-2",
            stepData.isGoal 
              ? "bg-green-50 dark:bg-green-900/20 border-green-500" 
              : "bg-amber-50 dark:bg-amber-900/20 border-amber-500"
          )}>
            <div className="flex items-start gap-2">
              {stepData.isGoal && (
                <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 shrink-0 mt-0.5" />
              )}
              <div>
                <span className="text-sm font-medium">
                  Paso {stepData.step}:
                </span>
                <span className={cn(
                  "font-semibold ml-1",
                  stepData.isGoal 
                    ? "text-green-700 dark:text-green-400" 
                    : "text-amber-700 dark:text-amber-400"
                )}>
                  {stepData.description}
                </span>
                {stepData.isGoal && (
                  <div className="mt-2 text-sm text-green-700 dark:text-green-400 font-medium">
                    ✅ Camino óptimo encontrado con costo g = {stepData.expandedG}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Goal found warning if applicable */}
          {stepData.isGoal && stepData.openList.length > 0 && (
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3 text-sm">
              <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                <AlertTriangle className="w-4 h-4" />
                <span className="font-medium">El algoritmo ha terminado</span>
              </div>
              <p className="text-green-600 dark:text-green-500 mt-1 text-xs">
                Los nodos restantes en OPEN no se expanden porque ya se encontró el objetivo.
              </p>
            </div>
          )}

          {/* Open List */}
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="bg-amber-100 dark:bg-amber-900/30 px-4 py-2 border-b border-border">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-amber-700 dark:text-amber-400">
                  Lista Abierta (OPEN)
                </span>
                <Badge variant="outline" className="text-xs">
                  {stepData.openList.length} nodo{stepData.openList.length !== 1 ? 's' : ''}
                </Badge>
              </div>
            </div>
            <div className="p-3">
              {stepData.openList.length > 0 ? (
                <div className="space-y-2">
                  {stepData.openList
                    .slice()
                    .sort((a, b) => {
                      // Sort by f, then prioritize goals
                      if (a.f !== b.f) return a.f - b.f;
                      const aIsGoal = treeNodes[a.id]?.isGoal || false;
                      const bIsGoal = treeNodes[b.id]?.isGoal || false;
                      if (aIsGoal && !bIsGoal) return -1;
                      if (!aIsGoal && bIsGoal) return 1;
                      return 0;
                    })
                    .map((node, index) => {
                      const isGoal = treeNodes[node.id]?.isGoal || false;
                      return (
                        <OpenListNodeItem 
                          key={node.id} 
                          node={node} 
                          isNext={index === 0 && !stepData.isGoal}
                          isGoal={isGoal}
                        />
                      );
                    })}
                </div>
              ) : (
                <div className="text-center text-muted-foreground text-sm py-2">
                  {stepData.isGoal ? "Vacía (algoritmo terminado)" : "Lista vacía"}
                </div>
              )}
            </div>
          </div>

          {/* Closed List */}
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="bg-emerald-100 dark:bg-emerald-900/30 px-4 py-2 border-b border-border">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                  Lista Cerrada (CLOSED)
                </span>
                <Badge variant="outline" className="text-xs">
                  {stepData.closedList.length} nodo{stepData.closedList.length !== 1 ? 's' : ''}
                </Badge>
              </div>
            </div>
            <div className="p-3">
              <div className="flex flex-wrap gap-2">
                {stepData.closedList.map((nodeId) => {
                  const isGoal = nodeId.includes('Goal');
                  const label = treeNodes[nodeId]?.label || nodeId.replace('1', '₁').replace('2', '₂');
                  return (
                    <div
                      key={nodeId}
                      className={cn(
                        "px-3 py-1.5 rounded-full text-sm font-medium border",
                        isGoal
                          ? "bg-green-100 dark:bg-green-900/30 border-green-500 text-green-700 dark:text-green-400"
                          : "bg-emerald-100 dark:bg-emerald-900/30 border-emerald-500 text-emerald-700 dark:text-emerald-400"
                      )}
                    >
                      {isGoal && '🎯 '}{label}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Not started message */}
      {!stepData && (
        <div className="text-center text-muted-foreground py-8">
          Presiona &quot;Reproducir&quot; para iniciar la simulación del algoritmo A*
        </div>
      )}
    </div>
  );
}

interface OpenListNodeItemProps {
  node: OpenListNode;
  isNext: boolean;
  isGoal: boolean;
}

function OpenListNodeItem({ node, isNext, isGoal }: OpenListNodeItemProps) {
  return (
    <div
      className={cn(
        "flex items-center justify-between p-2 rounded-lg border",
        isGoal && "bg-green-50 dark:bg-green-900/20 border-green-300 dark:border-green-700",
        isNext && !isGoal && "bg-amber-50 dark:bg-amber-900/20 border-amber-300 dark:border-amber-700",
        !isNext && !isGoal && "bg-background border-border"
      )}
    >
      <div className="flex items-center gap-2">
        {isGoal && <span className="text-xs">🎯</span>}
        {isNext && !isGoal && (
          <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">
            → Próximo
          </span>
        )}
        <span className={cn(
          "font-medium",
          isGoal && "text-green-700 dark:text-green-400",
          isNext && !isGoal && "text-amber-700 dark:text-amber-400"
        )}>
          {node.label}
        </span>
      </div>
      <div className="flex items-center gap-3 text-xs font-mono">
        <span className="text-muted-foreground">
          g={node.g}
        </span>
        <span className="text-muted-foreground">
          h={node.h}
        </span>
        <span className={cn(
          "font-bold px-2 py-0.5 rounded",
          isGoal 
            ? "bg-green-200 dark:bg-green-800 text-green-800 dark:text-green-200"
            : isNext 
              ? "bg-amber-200 dark:bg-amber-800 text-amber-800 dark:text-amber-200"
              : "bg-muted"
        )}>
          f={node.f}
        </span>
      </div>
    </div>
  );
}
